<?php
require_once 'config.php';
// Already logged in? Redirect to dashboard
if (isset($_SESSION['user_id'])) {
  switch ($_SESSION['role']) {
    case 'admin':     header('Location: admin/dashboard.php');  exit;
    case 'organizer': header('Location: officer/dashboard.php'); exit;
    default:          header('Location: student/student.php');  exit;
  }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>CampusConnect - Login</title>

  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"/>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet"/>
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet"/>

  <link rel="stylesheet" href="css/login.css"/>
</head>
<body>

  <?php if (!empty($_GET['registered'])): ?>
  <script>
    window.addEventListener('DOMContentLoaded', () => {
      const toastEl = document.getElementById('appToast');
      document.getElementById('toast-msg').textContent = 'Account created! Please log in.';
      new bootstrap.Toast(toastEl, { delay: 4000 }).show();
    });
  </script>
  <?php endif; ?>

  <!-- ── TOAST ── -->
  <div class="toast-container position-fixed top-0 end-0 p-3">
    <div id="appToast" class="toast align-items-center text-white border-0" role="alert">
      <div class="d-flex">
        <div class="toast-body d-flex align-items-center gap-2">
          <i class="bi bi-check-circle-fill"></i>
          <span id="toast-msg">Success!</span>
        </div>
        <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast"></button>
      </div>
    </div>
  </div>

  <!-- ── LOGIN PAGE ── -->
  <div id="loginPage" class="main-card">
    <div class="row g-0">

      <!-- LEFT: FORMS (Login/Sign Up) -->
      <div class="col-12 col-md-6 panel-left">

        <!-- Logo -->
        <div class="d-flex align-items-center gap-2 mb-4">
          <div class="logo-circle">C</div>
          <span class="fw-semibold text-dark" style="font-size:14px;">CampusConnect</span>
        </div>

        <!-- ── LOGIN FORM ── -->
        <div id="loginForm">
          <h5 class="fw-semibold text-dark mb-1" style="font-size:17px;">Welcome Back</h5>
          <p class="text-muted mb-4" style="font-size:12px;">Log in to your account</p>

          <!-- Email -->
          <div class="mb-3">
            <div class="input-icon-wrap">
              <i class="bi bi-envelope input-icon"></i>
              <input type="email" id="login-email" class="form-control" placeholder="Email Address" autocomplete="email"/>
            </div>
            <div class="invalid-feedback d-block" id="login-email-error" style="display:none!important;"></div>
          </div>

          <!-- Password -->
          <div class="mb-3">
            <div class="input-icon-wrap">
              <i class="bi bi-lock input-icon"></i>
              <input type="password" id="login-password" class="form-control" placeholder="Password" style="padding-right:36px;" autocomplete="current-password"/>
              <button class="eye-toggle" onclick="togglePass('login-password','login-eye')">
                <i class="bi bi-eye" id="login-eye" style="font-size:14px;"></i>
              </button>
            </div>
            <div class="invalid-feedback d-block" id="login-pass-error" style="display:none!important;"></div>
          </div>

          <!-- Forgot -->
          <div class="text-end mb-4">
            <a href="#" class="link-crimson" style="font-size:12px;">Forgot password?</a>
          </div>

          <!-- Login Button -->
          <button class="btn-signup d-flex align-items-center justify-content-center gap-2 mb-3"
                  id="loginBtn" onclick="handleLogin()">
            <span class="spinner-border spinner-border-sm btn-spinner" id="login-spinner"></span>
            <span id="login-btn-text">Log In</span>
          </button>

          <!-- Switch to Sign Up -->
          <p class="text-center text-muted mb-0" style="font-size:12px;">
            Don't have an account?
            <span class="link-crimson" onclick="switchToSignUp()">Sign Up</span>
          </p>
        </div>

        <!-- ── SIGN UP FORM ── -->
        <div id="signupForm" style="display:none;">
          <h5 class="fw-semibold text-dark mb-1" style="font-size:17px;">Create your Account</h5>
          <p class="text-muted mb-4" style="font-size:12px;">Join the campus community today</p>

          <!-- Full Name -->
          <div class="mb-3">
            <div class="input-icon-wrap">
              <i class="bi bi-person input-icon"></i>
              <input type="text" id="reg-name" class="form-control" placeholder="Full Name" autocomplete="name"/>
            </div>
            <div class="invalid-feedback d-block" id="reg-name-error" style="display:none!important;"></div>
          </div>

          <!-- Email -->
          <div class="mb-3">
            <div class="input-icon-wrap">
              <i class="bi bi-envelope input-icon"></i>
              <input type="email" id="reg-email" class="form-control" placeholder="Email Address" autocomplete="email"/>
            </div>
            <div class="invalid-feedback d-block" id="reg-email-error" style="display:none!important;"></div>
          </div>

          <!-- Password -->
          <div class="mb-4">
            <div class="input-icon-wrap">
              <i class="bi bi-lock input-icon"></i>
              <input type="password" id="reg-password" class="form-control" placeholder="Password"
                     style="padding-right:36px;" autocomplete="new-password"/>
              <button class="eye-toggle" onclick="togglePass('reg-password','reg-eye')">
                <i class="bi bi-eye" id="reg-eye" style="font-size:14px;"></i>
              </button>
            </div>
            <div class="invalid-feedback d-block" id="reg-pass-error" style="display:none!important;"></div>
          </div>

          <!-- Sign Up Button -->
          <button class="btn-signup d-flex align-items-center justify-content-center gap-2 mb-3"
                  id="signupBtn" onclick="handleSignUp()">
            <span class="spinner-border spinner-border-sm btn-spinner" id="signup-spinner"></span>
            <span id="signup-btn-text">Sign Up</span>
          </button>

          <!-- Switch to Login -->
          <p class="text-center text-muted mb-0" style="font-size:12px;">
            Already have an account?
            <span class="link-crimson" onclick="switchToLogin()">Log In</span>
          </p>
        </div>

      </div>

      <!-- RIGHT: WELCOME MESSAGE -->
      <div class="col-12 col-md-6 panel-right">
        <div id="welcomeLogin">
          <h2 class="fw-bold text-white mb-3" style="font-size:32px;">Welcome Back!</h2>
          <p class="text-white mb-4" style="font-size:13px; opacity:0.65; line-height:1.7; max-width:260px;">
            New to CampusConnect? Click Sign Up in the form to create an account and join the campus community.
          </p>
          <a href="index.html" style="font-size:12px; color:rgba(255,255,255,0.5); text-decoration:none;">
            ← Back to home
          </a>
        </div>

        <div id="welcomeSignup" style="display:none;">
          <h2 class="fw-bold text-white mb-3" style="font-size:32px;">Join Us!</h2>
          <p class="text-white mb-4" style="font-size:13px; opacity:0.65; line-height:1.7; max-width:260px;">
            Already have an account? Click Log In to access your account and continue exploring campus events.
          </p>
          <a href="index.html" style="font-size:12px; color:rgba(255,255,255,0.5); text-decoration:none;">
            ← Back to home
          </a>
        </div>
      </div>

    </div>
  </div>

  <!-- Bootstrap 5 JS -->
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="login-script-db.js"></script>

</body>
</html>
