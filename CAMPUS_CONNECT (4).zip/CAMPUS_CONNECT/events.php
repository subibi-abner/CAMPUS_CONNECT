<?php
/**
 * events.php  — Public-facing events page for students
 *
 * FIXES:
 *  1. Uses PDO (config.php) instead of the old mysqli/db.php.
 *  2. Fetches all approved upcoming events via get_events_for_student().
 *  3. Computes can_register per event (college restriction + deadline + capacity).
 *  4. Register button is disabled/hidden in the UI for restricted students.
 *  5. Registration POST is forwarded to toggle_join.php which re-checks
 *     all rules server-side — bypassing the UI is impossible.
 *
 * Can be used as a standalone page OR included by student.php.
 */

session_start();
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/db_functions.php';

require_login('student');  // redirects non-students

$user_id = (int)$_SESSION['user_id'];

// ── Load student record (need department_id for restriction check) ──
$stmt = $pdo->prepare("
    SELECT u.*, d.name AS department_name, d.code AS dept_code
    FROM   users u
    LEFT JOIN departments d ON u.department_id = d.id
    WHERE  u.id = ?
");
$stmt->execute([$user_id]);
$student    = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$student) {
    session_destroy();
    header('Location: login.php');
    exit;
}

$studentDeptId   = (int)($student['department_id'] ?? 0);
$studentDeptName = $student['department_name'] ?? '';
$studentName     = $student['full_name'] ?? 'Student';

// ── Fetch all events with restriction flags ──────────────────
$events = get_events_for_student($pdo, $user_id, $studentDeptId);
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Events – CampusConnect</title>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css">
  <style>
    *, *::before, *::after { box-sizing: border-box; }
    body { font-family: 'Segoe UI', sans-serif; background: #f5f6fa; margin: 0; padding: 24px; color: #1a1a2e; }
    h1   { font-size: 1.5rem; margin-bottom: 4px; }
    .sub { color: #64748b; font-size: .9rem; margin-bottom: 24px; }

    /* ── Event card ── */
    .event-card {
      background: #fff;
      border-radius: 12px;
      border: 1.5px solid #e8eaed;
      padding: 18px 20px;
      margin-bottom: 14px;
      display: flex;
      gap: 16px;
      align-items: flex-start;
      transition: box-shadow .2s;
    }
    .event-card:hover { box-shadow: 0 4px 16px rgba(0,0,0,.08); }

    .event-info     { flex: 1; min-width: 0; }
    .event-title    { font-size: 1rem; font-weight: 700; margin-bottom: 4px; }
    .event-meta     { font-size: .82rem; color: #64748b; display: flex; flex-wrap: wrap; gap: 12px; margin-bottom: 8px; }
    .event-meta span { display: flex; align-items: center; gap: 4px; }
    .event-desc     { font-size: .85rem; color: #374151; line-height: 1.5; }

    /* ── Badges ── */
    .badge {
      display: inline-flex; align-items: center; gap: 4px;
      font-size: .72rem; font-weight: 600;
      padding: 3px 9px; border-radius: 99px; margin-bottom: 6px;
    }
    .badge-dept     { background: #fef3c7; color: #92400e; }
    .badge-open     { background: #dcfce7; color: #166534; }
    .badge-full     { background: #f1f5f9; color: #475569; }
    .badge-deadline { background: #fee2e2; color: #b91c1c; }
    .badge-category { background: #e0e7ff; color: #3730a3; }

    /* ── Restriction notice ── */
    .restrict-notice {
      background: #fffbeb;
      border: 1px solid #fcd34d;
      border-radius: 8px;
      padding: 8px 12px;
      font-size: .82rem;
      color: #78350f;
      display: flex; align-items: center; gap: 8px;
      margin-top: 8px;
    }

    /* ── Buttons ── */
    .btn {
      display: inline-flex; align-items: center; gap: 6px;
      padding: 8px 16px; border-radius: 8px; font-size: .85rem;
      font-weight: 600; border: none; cursor: pointer; transition: opacity .2s;
    }
    .btn-register  { background: #e63946; color: #fff; }
    .btn-register:hover:not(:disabled) { opacity: .85; }
    .btn-register:disabled {
      background: #e5e7eb; color: #9ca3af;
      cursor: not-allowed; opacity: 1;
    }
    .btn-registered { background: #dcfce7; color: #166534; cursor: default; }
    .btn-save   { background: #fff; border: 1.5px solid #e8eaed; color: #374151; }
    .btn-save:hover { background: #f9fafb; }
    .event-actions  { display: flex; flex-direction: column; gap: 8px; min-width: 130px; }

    /* ── Empty state ── */
    .empty { text-align: center; padding: 60px 20px; color: #94a3b8; }
    .empty i { font-size: 3rem; display: block; margin-bottom: 12px; }

    /* ── Toast ── */
    #toast {
      position: fixed; bottom: 24px; right: 24px; z-index: 9999;
      background: #1e293b; color: #fff; padding: 12px 20px; border-radius: 10px;
      font-size: .875rem; display: none; align-items: center; gap: 8px;
      box-shadow: 0 4px 16px rgba(0,0,0,.2);
    }
    #toast.show { display: flex; }
    #toast.success { background: #166534; }
    #toast.warning { background: #92400e; }
    #toast.error   { background: #b91c1c; }
  </style>
</head>
<body>

<h1>Upcoming Events</h1>
<p class="sub">
  Hello, <strong><?= htmlspecialchars($studentName) ?></strong>
  <?php if ($studentDeptName): ?>
    — <?= htmlspecialchars($studentDeptName) ?>
  <?php endif; ?>
</p>

<?php if (empty($events)): ?>
  <div class="empty">
    <i class="bi bi-calendar-x"></i>
    <strong>No upcoming events</strong>
    <p>Check back soon for new events.</p>
  </div>

<?php else: ?>
  <?php foreach ($events as $ev):
    $evDate  = new DateTime($ev['event_date']);
    $isJoined = (bool)$ev['is_joined'];
    $orgLabel = $ev['org_acronym'] ?: ($ev['org_name'] ?: 'WMSU');
    $category = htmlspecialchars($ev['category'] ?? 'General');
  ?>

  <div class="event-card" data-id="<?= (int)$ev['id'] ?>">

    <div class="event-info">
      <!-- Badges row -->
      <div style="margin-bottom:6px;display:flex;flex-wrap:wrap;gap:6px;">
        <span class="badge badge-category">
          <i class="bi bi-tag"></i> <?= $category ?>
        </span>

        <?php if ($ev['is_restricted']): ?>
          <!-- College-restricted event: student is NOT from that college -->
          <span class="badge badge-dept">
            <i class="bi bi-eye"></i>
            View Only · <?= htmlspecialchars($ev['restrict_label']) ?>
          </span>

        <?php elseif ($ev['deadline_passed']): ?>
          <span class="badge badge-deadline">
            <i class="bi bi-calendar-x"></i> Deadline Passed
          </span>

        <?php elseif ($ev['is_full']): ?>
          <span class="badge badge-full">
            <i class="bi bi-person-x"></i> Full
          </span>

        <?php else: ?>
          <span class="badge badge-open">
            <i class="bi bi-check-circle"></i> Open
          </span>
        <?php endif; ?>
      </div>

      <div class="event-title"><?= htmlspecialchars($ev['title']) ?></div>

      <div class="event-meta">
        <span><i class="bi bi-calendar3"></i> <?= $evDate->format('M j, Y') ?></span>
        <span><i class="bi bi-clock"></i> <?= $evDate->format('g:i A') ?></span>
        <span><i class="bi bi-geo-alt"></i> <?= htmlspecialchars($ev['location'] ?? '—') ?></span>
        <span><i class="bi bi-people"></i> <?= (int)$ev['attendee_count'] ?> attending</span>
        <span><i class="bi bi-building"></i> <?= htmlspecialchars($orgLabel) ?></span>
      </div>

      <?php if (!empty($ev['description'])): ?>
        <div class="event-desc"><?= nl2br(htmlspecialchars(substr($ev['description'], 0, 200))) ?>
          <?= strlen($ev['description']) > 200 ? '…' : '' ?>
        </div>
      <?php endif; ?>

      <?php if ($ev['is_restricted']): ?>
        <!-- Clear notice explaining WHY registration is blocked -->
        <div class="restrict-notice">
          <i class="bi bi-lock-fill" style="flex-shrink:0"></i>
          <span>
            Registration is only available for
            <strong><?= htmlspecialchars($ev['restrict_label']) ?></strong> students.
            You can view this event but cannot register.
          </span>
        </div>
      <?php endif; ?>

      <?php if (!empty($ev['registration_deadline']) && !$ev['deadline_passed']): ?>
        <div style="font-size:.8rem;color:#d97706;margin-top:6px;">
          <i class="bi bi-clock-history"></i>
          Registration closes <?= date('M j, Y', strtotime($ev['registration_deadline'])) ?>
        </div>
      <?php endif; ?>
    </div>

    <!-- Action buttons -->
    <div class="event-actions">
      <?php if ($isJoined): ?>
        <!-- Already registered — show un-register button -->
        <button class="btn btn-registered join-btn"
                data-id="<?= (int)$ev['id'] ?>"
                title="Click to cancel registration">
          <i class="bi bi-check-circle-fill"></i> Registered
        </button>

      <?php elseif ($ev['can_register']): ?>
        <!-- Open registration -->
        <button class="btn btn-register join-btn"
                data-id="<?= (int)$ev['id'] ?>">
          <i class="bi bi-person-plus"></i> Register
        </button>

      <?php else: ?>
        <!-- Cannot register for one of: restricted / deadline passed / full -->
        <button class="btn btn-register"
                disabled
                title="<?= $ev['is_restricted']
                           ? 'Restricted to ' . htmlspecialchars($ev['restrict_label'])
                           : ($ev['deadline_passed'] ? 'Deadline passed' : 'Event full') ?>">
          <?php if ($ev['is_restricted']): ?>
            <i class="bi bi-lock"></i> Restricted
          <?php elseif ($ev['deadline_passed']): ?>
            <i class="bi bi-calendar-x"></i> Closed
          <?php else: ?>
            <i class="bi bi-person-x"></i> Full
          <?php endif; ?>
        </button>
      <?php endif; ?>
    </div>

  </div><!-- /.event-card -->

  <?php endforeach; ?>
<?php endif; ?>

<!-- Toast notification -->
<div id="toast"></div>

<script>
// ── Toggle registration via AJAX ──────────────────────────────
document.querySelectorAll('.join-btn').forEach(function(btn) {
  btn.addEventListener('click', function() {
    var id  = btn.dataset.id;
    var fd  = new FormData();
    fd.append('event_id', id);

    btn.disabled = true;

    fetch('student/actions/toggle_join.php', { method: 'POST', body: fd })
      .then(function(r) { return r.json(); })
      .then(function(res) {
        if (!res.success) {
          showToast(res.msg || 'Error', 'error');
          btn.disabled = false;
          return;
        }
        // Refresh page to re-render accurate state from DB
        showToast(res.msg, res.joined ? 'success' : 'warning');
        setTimeout(function() { location.reload(); }, 1200);
      })
      .catch(function() {
        showToast('Network error. Please try again.', 'error');
        btn.disabled = false;
      });
  });
});

function showToast(msg, type) {
  var t = document.getElementById('toast');
  t.textContent = msg;
  t.className   = 'show ' + (type || '');
  clearTimeout(t._timer);
  t._timer = setTimeout(function() { t.className = ''; }, 3000);
}
</script>
</body>
</html>
