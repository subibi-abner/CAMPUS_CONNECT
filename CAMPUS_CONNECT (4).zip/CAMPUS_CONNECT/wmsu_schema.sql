-- ============================================================
-- CampusConnect — Western Mindanao State University
-- Single authoritative schema
-- NOTE: `colleges` is a VIEW over `departments`.
--       This lets `INSERT INTO colleges (code, name, description)`
--       work unchanged while all PHP code keeps using `departments`.
-- ============================================================

DROP DATABASE IF EXISTS campus_connect;
CREATE DATABASE campus_connect CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE campus_connect;

-- ─── DEPARTMENTS ─────────────────────────────────────────────
CREATE TABLE departments (
  id          INT AUTO_INCREMENT PRIMARY KEY,
  code        VARCHAR(10)  UNIQUE NOT NULL,
  name        VARCHAR(200) UNIQUE NOT NULL,
  description TEXT,
  created_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ─── colleges VIEW — keeps INSERT INTO colleges (...) working ─
CREATE VIEW colleges AS
  SELECT id, code, name, description, created_at
  FROM departments;

-- ─── ORGANIZATIONS ───────────────────────────────────────────
CREATE TABLE organizations (
  id            INT AUTO_INCREMENT PRIMARY KEY,
  name          VARCHAR(200) UNIQUE NOT NULL,
  acronym       VARCHAR(30),
  description   TEXT,
  department_id INT DEFAULT NULL,
  type          ENUM('academic','religious','cultural','sports','civic','student_gov') DEFAULT 'academic',
  created_at    TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (department_id) REFERENCES departments(id) ON DELETE SET NULL
);

-- ─── USERS ───────────────────────────────────────────────────
CREATE TABLE users (
  id            INT AUTO_INCREMENT PRIMARY KEY,
  username      VARCHAR(50)  UNIQUE NOT NULL,
  email         VARCHAR(100) UNIQUE NOT NULL,
  password      VARCHAR(255) NOT NULL,
  role          ENUM('student','organizer','admin') DEFAULT 'student',
  full_name     VARCHAR(100),
  department_id INT DEFAULT NULL,
  course        VARCHAR(100) DEFAULT NULL,
  year_level    ENUM('1st Year','2nd Year','3rd Year','4th Year','5th Year','Graduate') DEFAULT NULL,
  bio           TEXT,
  contact       VARCHAR(200),
  created_at    TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (department_id) REFERENCES departments(id) ON DELETE SET NULL
);

-- ─── EVENTS ──────────────────────────────────────────────────
CREATE TABLE events (
  id            INT AUTO_INCREMENT PRIMARY KEY,
  title         VARCHAR(200) NOT NULL,
  description   TEXT,
  category      VARCHAR(50)  DEFAULT 'General',
  event_date    DATETIME     NOT NULL,
  location      VARCHAR(200),
  organizer_id  INT,
  org_id        INT DEFAULT NULL,
  department_id INT DEFAULT NULL,
  max_attendees INT DEFAULT 100,
  status        ENUM('pending','approved','rejected','deleted') DEFAULT 'pending',
  delete_reason TEXT,
  created_at    TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at    TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (organizer_id)  REFERENCES users(id)         ON DELETE SET NULL,
  FOREIGN KEY (org_id)        REFERENCES organizations(id) ON DELETE SET NULL,
  FOREIGN KEY (department_id) REFERENCES departments(id)   ON DELETE SET NULL
);

-- ─── DELETION REQUESTS ─────────────────────────────────────
CREATE TABLE deletion_requests (
  id            INT AUTO_INCREMENT PRIMARY KEY,
  event_id      INT NOT NULL,
  organizer_id  INT NOT NULL,
  reason        TEXT NOT NULL,
  status        ENUM('pending','approved','rejected') DEFAULT 'pending',
  created_at    TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  resolved_at   TIMESTAMP NULL,
  INDEX idx_status (status),
  INDEX idx_event (event_id),
  FOREIGN KEY (event_id)     REFERENCES events(id) ON DELETE CASCADE,
  FOREIGN KEY (organizer_id) REFERENCES users(id)  ON DELETE CASCADE
);

-- ─── REGISTRATIONS ───────────────────────────────────────────
CREATE TABLE registrations (
  id            INT AUTO_INCREMENT PRIMARY KEY,
  user_id       INT,
  event_id      INT,
  registered_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id)  REFERENCES users(id)  ON DELETE CASCADE,
  FOREIGN KEY (event_id) REFERENCES events(id) ON DELETE CASCADE,
  UNIQUE KEY unique_registration (user_id, event_id)
);

-- ─── SAVED EVENTS ────────────────────────────────────────────
CREATE TABLE saved_events (
  id       INT AUTO_INCREMENT PRIMARY KEY,
  user_id  INT,
  event_id INT,
  saved_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id)  REFERENCES users(id)  ON DELETE CASCADE,
  FOREIGN KEY (event_id) REFERENCES events(id) ON DELETE CASCADE,
  UNIQUE KEY unique_saved (user_id, event_id)
);

-- ─── ANNOUNCEMENTS ───────────────────────────────────────────
CREATE TABLE announcements (
  id         INT AUTO_INCREMENT PRIMARY KEY,
  title      VARCHAR(200) NOT NULL,
  content    TEXT         NOT NULL,
  created_by INT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE SET NULL
);

-- ─── NOTIFICATIONS ────────────────────────────────────────────
CREATE TABLE notifications (
  id         INT AUTO_INCREMENT PRIMARY KEY,
  user_id    INT,
  message    TEXT NOT NULL,
  type       ENUM('event','announcement','system') DEFAULT 'system',
  is_read    TINYINT(1) DEFAULT 0,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- ============================================================
-- SEED DATA — WMSU Departments / Colleges
-- Inserted via the colleges VIEW so the statement is unchanged.
-- ============================================================

INSERT INTO colleges (code, name, description) VALUES
('CAS',   'College of Arts and Sciences',                    'Offers programs in humanities, social sciences, natural sciences, and mathematics'),
('CBA',   'College of Business Administration',              'Prepares students for careers in business, management, and entrepreneurship'),
('COE',   'College of Education',                            'Trains future educators and school administrators'),
('CENG',  'College of Engineering and Technology',           'Provides engineering and technology programs'),
('CCS',   'College of Computing Studies',                     'Focuses on computing, information technology, and software development'),
('CLAW',  'College of Law',                                  'Offers Juris Doctor and other law programs'),
('CMED',  'College of Medicine',                             'Trains future doctors and medical professionals'),
('CN',    'College of Nursing',                              'Prepares students for the nursing profession'),
('CPT',   'College of Physical Therapy',                     'Trains physical therapy practitioners'),
('CRIM',  'College of Criminology',                          'Offers criminology and forensic science programs'),
('CSSP',  'College of Social Sciences and Philosophy',       'Focuses on social sciences, psychology, and philosophy'),
('CSSD',  'College of Social Work and Community Development','Focuses on social welfare and community programs'),
('CTE',   'College of Teacher Education',                    'Specializes in teacher training and pedagogy'),
('CVE',   'College of Veterinary Medicine',                  'Trains veterinary medicine practitioners'),
('GRAD',  'Graduate School',                                 'Offers masters and doctoral programs across disciplines');

-- ============================================================
-- ORGANIZATIONS
-- department_id order: 1=CAS 2=CBA 3=COE 4=CENG 5=CCS
--   6=CLAW 7=CMED 8=CN 9=CPT 10=CRIM 11=CSSP 12=CSSD
--   13=CTE 14=CVE 15=GRAD
-- ============================================================

INSERT INTO organizations (name, acronym, description, department_id, type) VALUES
('Supreme Student Council',           'SSC',   'The highest governing body of students in WMSU',                               NULL, 'student_gov'),
('WMSU Cultural Dance Troupe',        'CDT',   'Preserves and promotes Filipino cultural dances and heritage performances',     NULL, 'cultural'),
('WMSU Chorale',                      NULL,    'Official choral ensemble of Western Mindanao State University',                 NULL, 'cultural'),
('Sigma Delta Phi',                   NULL,    'Official student literary and journalistic organization of WMSU',               NULL, 'cultural'),
('WMSU Campus Ministry',              'CM',    'Catholic campus ministry providing faith formation and community service',      NULL, 'religious'),
('Baptist Student Union',             'BSU',   'Christian student fellowship and ministry for Baptist students in WMSU',        NULL, 'religious'),
('WMSU Jaguars Athletic Association', 'WJAA',  'Umbrella sports organization representing WMSU athletes',                       NULL, 'sports'),
('ROTC Corps',                        'ROTC',  'Reserve Officers Training Corps unit for civic welfare and leadership',         NULL, 'civic'),
('Computer Science Society',          'CSS',   'Official organization of computing students in WMSU',                           5,    'academic'),
('Nursing Student Association',       'NSA',   'Official student organization of nursing students in WMSU',                     8,    'academic'),
('Future Educators Association',      'FEA',   'Organization for teacher education students promoting teaching excellence',     13,   'academic'),
('Junior Criminologists Association', 'JCA',   'Professional organization for criminal justice students of WMSU',               10,   'academic');

-- ============================================================
-- USERS
-- Passwords: admin → admin123 | student → student123 | officer → officer123
-- department_id 5 = CCS, 8 = CN
-- ============================================================

INSERT INTO users (username, email, password, role, full_name, department_id, course, year_level) VALUES
-- Admin
('admin',         'admin@wmsu.edu.ph',          '$2y$10$ipv7xtKzeiZHsd43YYSuY.GMMzrj6Bdzo7KByFL/eYOlt.rVujYmy', 'admin',     'Administrator',            NULL, NULL,                                          NULL),
-- CCS Officer (CSS Society) — logs in as officer123
('css.officer',   'css.officer@wmsu.edu.ph',    '$2y$10$IpCQqeQrukzHglD6.PKHROtNokz.DWmVNveHxDCuSqH5UX0Tf/WxG', 'organizer', 'Carlo M. Santos',          5,    'Bachelor of Science in Information Technology', NULL),
-- SSC President — university-wide officer
('ssc.president', 'ssc.president@wmsu.edu.ph',  '$2y$10$IpCQqeQrukzHglD6.PKHROtNokz.DWmVNveHxDCuSqH5UX0Tf/WxG', 'organizer', 'Reina P. Villanueva',      NULL, NULL,                                          NULL),
-- BSIT Students from CCS (department_id = 5) — all log in as student123
('jdelacruz',     'juan.delacruz@wmsu.edu.ph',  '$2y$10$ChvcZDQV4SMbhQlf.FCSq.xjNOzkPxQJR/GjpnxF5hG2yLmrxkt.W', 'student',   'Juan Miguel dela Cruz',   5,    'Bachelor of Science in Information Technology', '3rd Year'),
('mreyes',        'maria.reyes@wmsu.edu.ph',    '$2y$10$ChvcZDQV4SMbhQlf.FCSq.xjNOzkPxQJR/GjpnxF5hG2yLmrxkt.W', 'student',   'Maria Cristina Reyes',    5,    'Bachelor of Science in Information Technology', '2nd Year'),
('kpadilla',      'kevin.padilla@wmsu.edu.ph',  '$2y$10$ChvcZDQV4SMbhQlf.FCSq.xjNOzkPxQJR/GjpnxF5hG2yLmrxkt.W', 'student',   'Kevin R. Padilla',        5,    'Bachelor of Science in Information Technology', '4th Year'),
('agonzales',     'anna.gonzales@wmsu.edu.ph',  '$2y$10$ChvcZDQV4SMbhQlf.FCSq.xjNOzkPxQJR/GjpnxF5hG2yLmrxkt.W', 'student',   'Anna Lorraine Gonzales',  5,    'Bachelor of Science in Information Technology', '1st Year'),
('rmorales',      'rico.morales@wmsu.edu.ph',   '$2y$10$ChvcZDQV4SMbhQlf.FCSq.xjNOzkPxQJR/GjpnxF5hG2yLmrxkt.W', 'student',   'Rico Emmanuel Morales',   5,    'Bachelor of Science in Information Technology', '3rd Year');

-- ============================================================
-- SAMPLE EVENTS
-- department_id 5 = CCS, 8 = CN
-- ============================================================

INSERT INTO events (title, description, category, event_date, location, organizer_id, org_id, department_id, max_attendees, status) VALUES
('WMSU Research Congress 2026',       'Annual research presentation and exhibit for all WMSU departments.',                'Academic',  '2026-05-10 08:00:00', 'WMSU Covered Court',     2, 1,  NULL, 500,  'approved'),
('CCS DevFest 2026',                 'Technology festival with industry talks, live demos, and workshops for CCS.',      'Academic',  '2026-05-15 09:00:00', 'CCS Auditorium',        2, 9,  5,    300,  'approved'),
('CSS Hackathon 2026',                'A 24-hour coding competition open to all computing and IT students of WMSU.',       'Org Event', '2026-05-20 08:00:00', 'CCS Building, Lab 3F',  2, 9,  5,    150,  'approved'),
('WMSU Cultural Night',               'Annual celebration of culture and arts showcasing WMSU talent.',                    'Social',    '2026-05-24 18:00:00', 'WMSU Open Amphitheater', 3, 2,  NULL, 800,  'approved'),
('Intramurals 2026 Opening Ceremony', 'Official opening ceremony of the WMSU Intramural Games 2026.',                     'Sports',    '2026-06-01 07:30:00', 'WMSU Gymnasium',         3, 7,  NULL, 1000, 'approved'),
('SSC General Assembly',              'Supreme Student Council general assembly open to all WMSU students.',               'Org Event', '2026-06-05 14:00:00', 'WMSU Covered Court',     3, 1,  NULL, 600,  'pending'),
('ROTC Leadership Seminar',           'Leadership training and civic responsibility seminar for WMSU ROTC cadets.',        'Academic',  '2026-06-08 08:00:00', 'WMSU Parade Ground',     3, 8,  NULL, 250,  'approved'),
('Nursing Board Exam Review',         'Free review sessions organized by NSA for graduating nursing students.',            'Academic',  '2026-06-10 08:00:00', 'CN Lecture Hall A',      2, 10, 8,    180,  'pending'),
('ITS Web Dev Workshop',              'Hands-on workshop on modern web development — HTML, CSS, JS, PHP for BSIT students.','Academic',  '2026-06-12 09:00:00', 'CCS Computer Lab 2',    2, 9,  5,    60,   'approved');

-- ============================================================
-- ANNOUNCEMENTS
-- ============================================================

INSERT INTO announcements (title, content, created_by) VALUES
('Welcome to CampusConnect WMSU',    'The official CampusConnect portal for Western Mindanao State University is now live. Stay updated with all campus events and activities!', 1),
('Enrollment Schedule AY 2026-2027', 'Enrollment for the First Semester of AY 2026-2027 begins June 15, 2026. Check the Registrar website for your college schedule.',           1),
('WMSU Foundation Week 2026',        'WMSU Foundation Week is set for the last week of June 2026. Various activities are planned by the SSC. Watch for more announcements!',    1);

-- ============================================================
-- SEED REGISTRATIONS
-- Users: 4=jdelacruz, 5=mreyes, 6=kpadilla, 7=agonzales, 8=rmorales
-- Events: 1=Research Congress, 2=CCS DevFest, 3=CSS Hackathon,
--         4=Cultural Night, 5=Intramurals, 9=Web Dev Workshop
-- ============================================================

INSERT INTO registrations (user_id, event_id) VALUES
-- jdelacruz: joined DevFest and CSS Hackathon and Web Dev Workshop
(4, 2), (4, 3), (4, 9),
-- mreyes: joined DevFest and Research Congress
(5, 1), (5, 2),
-- kpadilla: joined Hackathon, DevFest, Cultural Night
(6, 3), (6, 2), (6, 4),
-- agonzales: joined Research Congress and Web Dev Workshop
(7, 1), (7, 9),
-- rmorales: joined Hackathon, Intramurals, Web Dev Workshop
(8, 3), (8, 5), (8, 9);

-- ============================================================
-- STAFF ROLE & ATTENDANCE SYSTEM — Added in Phase 2
-- ============================================================

-- Add 'staff' to the users role ENUM
ALTER TABLE users
  MODIFY COLUMN role ENUM('student','organizer','staff','admin') DEFAULT 'student';

-- ─── STAFF ASSIGNMENTS ───────────────────────────────────────
CREATE TABLE event_staff (
  id          INT AUTO_INCREMENT PRIMARY KEY,
  event_id    INT NOT NULL,
  staff_id    INT NOT NULL,
  assigned_by INT NOT NULL,
  assigned_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (event_id)    REFERENCES events(id)  ON DELETE CASCADE,
  FOREIGN KEY (staff_id)    REFERENCES users(id)   ON DELETE CASCADE,
  FOREIGN KEY (assigned_by) REFERENCES users(id)   ON DELETE CASCADE,
  UNIQUE KEY one_staff_per_event (event_id, staff_id)
);

-- ─── ATTENDANCE ──────────────────────────────────────────────
CREATE TABLE attendance (
  id               INT AUTO_INCREMENT PRIMARY KEY,
  event_id         INT NOT NULL,
  user_id          INT NOT NULL,
  time_in          DATETIME DEFAULT NULL,
  time_out         DATETIME DEFAULT NULL,
  marked_by        INT DEFAULT NULL,
  certificate_sent TINYINT(1) DEFAULT 0,
  sent_at          DATETIME DEFAULT NULL,
  FOREIGN KEY (event_id)  REFERENCES events(id) ON DELETE CASCADE,
  FOREIGN KEY (user_id)   REFERENCES users(id)  ON DELETE CASCADE,
  FOREIGN KEY (marked_by) REFERENCES users(id)  ON DELETE SET NULL,
  UNIQUE KEY unique_attendance (event_id, user_id)
);

-- ─── QR TOKENS ───────────────────────────────────────────────
CREATE TABLE attendance_tokens (
  id         INT AUTO_INCREMENT PRIMARY KEY,
  event_id   INT NOT NULL,
  user_id    INT NOT NULL,
  token      VARCHAR(64) UNIQUE NOT NULL,
  used       TINYINT(1) DEFAULT 0,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (event_id) REFERENCES events(id) ON DELETE CASCADE,
  FOREIGN KEY (user_id)  REFERENCES users(id)  ON DELETE CASCADE,
  UNIQUE KEY unique_token (event_id, user_id)
);

-- ─── SEED: Staff user (password: staff123) ───────────────────
INSERT INTO users (username, email, password, role, full_name, department_id) VALUES
('css.staff', 'css.staff@wmsu.edu.ph', '$2y$10$IpCQqeQrukzHglD6.PKHROtNokz.DWmVNveHxDCuSqH5UX0Tf/WxG', 'staff', 'Mark A. Villanueva', 5);

-- ============================================================
-- MIGRATION v3: Event Status System + Participant Management
-- Run this if upgrading from an existing database.
-- ============================================================

-- 1. Expand events.status with new lifecycle statuses
ALTER TABLE events
  MODIFY COLUMN status 
    ENUM('draft','pending','approved','ongoing','completed','rejected','deleted') 
    DEFAULT 'draft';

-- 2. Add participant approval columns to registrations
ALTER TABLE registrations
  ADD COLUMN IF NOT EXISTS approval_status ENUM('pending','approved','rejected') DEFAULT 'approved',
  ADD COLUMN IF NOT EXISTS approval_note   TEXT           DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS approved_by     INT            DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS approved_at     TIMESTAMP      NULL DEFAULT NULL,
  ADD FOREIGN KEY (approved_by) REFERENCES users(id) ON DELETE SET NULL;

-- 3. Event-scoped announcement log
CREATE TABLE IF NOT EXISTS event_announcements (
  id              INT AUTO_INCREMENT PRIMARY KEY,
  event_id        INT NOT NULL,
  sender_id       INT NOT NULL,
  subject         VARCHAR(200) NOT NULL,
  message         TEXT NOT NULL,
  recipient_count INT DEFAULT 0,
  sent_at         TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (event_id)  REFERENCES events(id) ON DELETE CASCADE,
  FOREIGN KEY (sender_id) REFERENCES users(id)  ON DELETE CASCADE
);
