-- ============================================================
-- Migration: Add max_participants + registration_deadline
-- Run this once in phpMyAdmin or MySQL CLI
-- ============================================================

-- 1. Add registration_deadline column to events table
ALTER TABLE events
  ADD COLUMN IF NOT EXISTS registration_deadline DATE NULL DEFAULT NULL
    COMMENT 'Optional: students cannot register after this date'
    AFTER max_attendees;

-- 2. Make sure capacity stays in sync with max_attendees (both columns exist)
--    If your table only has one of them, add the missing one:
ALTER TABLE events
  ADD COLUMN IF NOT EXISTS capacity INT NOT NULL DEFAULT 100
    AFTER max_attendees;

ALTER TABLE events
  ADD COLUMN IF NOT EXISTS max_attendees INT NOT NULL DEFAULT 100
    AFTER capacity;

-- 3. Sync existing rows so capacity = max_attendees
UPDATE events SET capacity = max_attendees WHERE capacity = 0 OR capacity IS NULL;
UPDATE events SET max_attendees = capacity WHERE max_attendees = 0 OR max_attendees IS NULL;

-- Done!
SELECT 'Migration complete. Columns added: registration_deadline.' AS status;
