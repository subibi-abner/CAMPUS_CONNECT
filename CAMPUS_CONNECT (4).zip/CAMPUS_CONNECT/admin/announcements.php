<?php
require_once '../config.php';
require_once '../db_functions.php';
require_login('admin');

$active_page = 'announcements';
$success_msg = '';
$error_msg   = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $action = $_POST['action'] ?? '';
  if ($action === 'create') {
    $title   = trim($_POST['title']   ?? '');
    $content = trim($_POST['content'] ?? '');
    if ($title && $content) {
      $stmt = $pdo->prepare("INSERT INTO announcements (title, content, created_by, created_at) VALUES (?, ?, ?, NOW())");
      $stmt->execute([$title, $content, $_SESSION['user_id']]);
      $success_msg = 'Announcement posted successfully.';
    } else { $error_msg = 'Title and content are required.'; }
  } elseif ($action === 'delete') {
    $id = (int)($_POST['announcement_id'] ?? 0);
    if ($id > 0) { $pdo->prepare("DELETE FROM announcements WHERE id=?")->execute([$id]); $success_msg = 'Announcement deleted.'; }
  } elseif ($action === 'edit') {
    $id = (int)($_POST['announcement_id'] ?? 0);
    $title   = trim($_POST['title']   ?? '');
    $content = trim($_POST['content'] ?? '');
    if ($id > 0 && $title && $content) {
      $pdo->prepare("UPDATE announcements SET title=?, content=?, updated_at=NOW() WHERE id=?")->execute([$title, $content, $id]);
      $success_msg = 'Announcement updated.';
    }
  }
}

$announcements = [];
try {
  $stmt = $pdo->query("SELECT a.*, u.full_name AS posted_by FROM announcements a LEFT JOIN users u ON a.created_by = u.id ORDER BY a.created_at DESC");
  $announcements = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Announcements – CampusConnect Admin</title>
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
  <link rel="stylesheet" href="css/admin.css">
</head>
<body>

<?php include 'header.php'; ?>

<div class="layout">
<?php include 'sidebar.php'; ?>

<div class="main">
  <div class="page-header">
    <div>
      <div class="page-title">Announcements</div>
      <div class="page-sub">Post and manage campus-wide notices</div>
    </div>
    <button class="btn-primary" onclick="openCreateAnn()">
      <i class="bi bi-plus-lg"></i> New Announcement
    </button>
  </div>

  <?php if ($success_msg): ?><div class="alert alert-success"><i class="bi bi-check-circle"></i> <?= htmlspecialchars($success_msg) ?></div><?php endif; ?>
  <?php if ($error_msg):   ?><div class="alert alert-error"><i class="bi bi-exclamation-circle"></i> <?= htmlspecialchars($error_msg) ?></div><?php endif; ?>

  <div class="card">
    <div class="card-header">
      <h4>All Announcements <span style="font-weight:400;color:var(--text-muted);font-size:13px;">(<?= count($announcements) ?>)</span></h4>
    </div>
    <?php if (empty($announcements)): ?>
    <div class="empty-state">
      <i class="bi bi-megaphone"></i>
      <p>No announcements yet. Create your first one!</p>
    </div>
    <?php else: ?>
    <table class="data-table">
      <thead>
        <tr><th>Title</th><th>Content</th><th>Posted By</th><th>Date</th><th>Actions</th></tr>
      </thead>
      <tbody>
        <?php foreach ($announcements as $ann): ?>
        <tr>
          <td style="font-weight:500;max-width:200px;"><?= htmlspecialchars($ann['title']) ?></td>
          <td style="color:var(--text-secondary);max-width:320px;">
            <div style="overflow:hidden;text-overflow:ellipsis;white-space:nowrap;max-width:320px;">
              <?= htmlspecialchars($ann['content']) ?>
            </div>
          </td>
          <td style="color:var(--text-secondary);"><?= htmlspecialchars($ann['posted_by'] ?? 'Admin') ?></td>
          <td style="color:var(--text-muted);white-space:nowrap;"><?= date('M j, Y', strtotime($ann['created_at'])) ?></td>
          <td>
            <div class="table-actions">
              <button class="action-btn" title="Edit"
                onclick="openEditAnn(<?= $ann['id'] ?>,'<?= addslashes(htmlspecialchars($ann['title'])) ?>','<?= addslashes(htmlspecialchars($ann['content'])) ?>')">
                <i class="bi bi-pencil"></i>
              </button>
              <button class="action-btn danger" title="Delete"
                onclick="if(confirm('Delete this announcement?'))deleteAnn(<?= $ann['id'] ?>)">
                <i class="bi bi-trash"></i>
              </button>
            </div>
          </td>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
    <?php endif; ?>
  </div>
</div>
</div>

<!-- Create Modal -->
<div class="modal-overlay" id="createAnnModal" onclick="if(event.target===this)closeCreateAnn()">
  <div class="modal-box">
    <div class="modal-header">
      <h4><i class="bi bi-megaphone me-2"></i>New Announcement</h4>
      <button class="modal-close" onclick="closeCreateAnn()"><i class="bi bi-x"></i></button>
    </div>
    <form method="POST">
      <input type="hidden" name="action" value="create">
      <div class="form-group"><label>Title *</label><input type="text" name="title" required placeholder="Announcement title"></div>
      <div class="form-group"><label>Content *</label><textarea name="content" rows="5" required placeholder="Write your announcement here..."></textarea></div>
      <div class="modal-actions">
        <button type="submit" class="btn-save"><i class="bi bi-send me-1"></i>Post Announcement</button>
        <button type="button" class="btn-cancel-modal" onclick="closeCreateAnn()">Cancel</button>
      </div>
    </form>
  </div>
</div>

<!-- Edit Modal -->
<div class="modal-overlay" id="editAnnModal" onclick="if(event.target===this)closeEditAnn()">
  <div class="modal-box">
    <div class="modal-header">
      <h4><i class="bi bi-pencil me-2"></i>Edit Announcement</h4>
      <button class="modal-close" onclick="closeEditAnn()"><i class="bi bi-x"></i></button>
    </div>
    <form method="POST">
      <input type="hidden" name="action" value="edit">
      <input type="hidden" name="announcement_id" id="editAnnId">
      <div class="form-group"><label>Title *</label><input type="text" name="title" id="editAnnTitle" required></div>
      <div class="form-group"><label>Content *</label><textarea name="content" id="editAnnContent" rows="5" required></textarea></div>
      <div class="modal-actions">
        <button type="submit" class="btn-save"><i class="bi bi-check2 me-1"></i>Save Changes</button>
        <button type="button" class="btn-cancel-modal" onclick="closeEditAnn()">Cancel</button>
      </div>
    </form>
  </div>
</div>

<!-- Delete Form -->
<form id="deleteAnnForm" method="POST" style="display:none;">
  <input type="hidden" name="action" value="delete">
  <input type="hidden" name="announcement_id" id="deleteAnnId">
</form>

<script>
function openCreateAnn() { document.getElementById('createAnnModal').classList.add('open'); }
function closeCreateAnn() { document.getElementById('createAnnModal').classList.remove('open'); }
function openEditAnn(id, title, content) {
  document.getElementById('editAnnId').value = id;
  document.getElementById('editAnnTitle').value = title;
  document.getElementById('editAnnContent').value = content;
  document.getElementById('editAnnModal').classList.add('open');
}
function closeEditAnn() { document.getElementById('editAnnModal').classList.remove('open'); }
function deleteAnn(id) {
  document.getElementById('deleteAnnId').value = id;
  document.getElementById('deleteAnnForm').submit();
}
</script>
</body>
</html>
