<?php
require_once '../config.php';
require_once '../db_functions.php';
require_login('admin');

$active_page = 'departments';
$success_msg = '';
$error_msg   = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $action = $_POST['action'] ?? '';
  if ($action === 'create') {
    $code = strtoupper(trim($_POST['code'] ?? ''));
    $name = trim($_POST['name'] ?? '');
    $desc = trim($_POST['description'] ?? '');
    if ($name && $code) {
      try {
        $pdo->prepare("INSERT INTO departments (code, name, description, created_at) VALUES (?, ?, ?, NOW())")->execute([$code, $name, $desc]);
        $success_msg = 'Department added successfully.';
      } catch (PDOException $e) { $error_msg = 'Department code/name already exists.'; }
    } else { $error_msg = 'Code and name are required.'; }
  } elseif ($action === 'edit') {
    $id   = (int)($_POST['dept_id'] ?? 0);
    $code = strtoupper(trim($_POST['code'] ?? ''));
    $name = trim($_POST['name'] ?? '');
    $desc = trim($_POST['description'] ?? '');
    if ($id && $name && $code) {
      $pdo->prepare("UPDATE departments SET code=?, name=?, description=? WHERE id=?")->execute([$code, $name, $desc, $id]);
      $success_msg = 'Department updated.';
    }
  } elseif ($action === 'delete') {
    $id = (int)($_POST['dept_id'] ?? 0);
    if ($id > 0) { $pdo->prepare("DELETE FROM departments WHERE id=?")->execute([$id]); $success_msg = 'Department deleted.'; }
  }
}

$departments = [];
try {
  $departments = $pdo->query("SELECT d.*, COUNT(u.id) AS student_count FROM departments d LEFT JOIN users u ON u.department_id=d.id AND u.role='student' GROUP BY d.id ORDER BY d.name ASC")->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Departments – CampusConnect Admin</title>
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
  <link rel="stylesheet" href="css/admin.css">
</head>
<body>

<?php include 'header.php'; ?>

<div class="layout">
<?php include 'sidebar.php'; ?>

<div class="main">
  <div class="page-header">
    <div>
      <div class="page-title">Departments</div>
      <div class="page-sub">Manage college departments and their memberships</div>
    </div>
    <button class="btn-primary" onclick="openCreateDept()">
      <i class="bi bi-plus-lg"></i> Add Department
    </button>
  </div>

  <?php if ($success_msg): ?><div class="alert alert-success"><i class="bi bi-check-circle"></i> <?= htmlspecialchars($success_msg) ?></div><?php endif; ?>
  <?php if ($error_msg):   ?><div class="alert alert-error"><i class="bi bi-exclamation-circle"></i> <?= htmlspecialchars($error_msg) ?></div><?php endif; ?>

  <?php if (empty($departments)): ?>
  <div class="card">
    <div class="empty-state">
      <i class="bi bi-building"></i>
      <p>No departments yet. Add your first one!</p>
    </div>
  </div>
  <?php else: ?>
  <div class="dept-grid">
    <?php foreach ($departments as $d): ?>
    <div class="dept-card">
      <div style="display:flex;align-items:flex-start;justify-content:space-between;margin-bottom:10px;">
        <div style="width:38px;height:38px;border-radius:9px;background:var(--red-light);color:var(--red);display:flex;align-items:center;justify-content:center;font-size:13px;font-weight:700;">
          <?= htmlspecialchars($d['code']) ?>
        </div>
        <div class="table-actions">
          <button class="action-btn" title="Edit"
            onclick="openEditDept(<?= $d['id'] ?>,'<?= addslashes(htmlspecialchars($d['code'])) ?>','<?= addslashes(htmlspecialchars($d['name'])) ?>','<?= addslashes(htmlspecialchars($d['description'] ?? '')) ?>')">
            <i class="bi bi-pencil"></i>
          </button>
          <form method="POST" style="display:inline;" onsubmit="return confirm('Delete this department? Users will lose their association.')">
            <input type="hidden" name="action" value="delete">
            <input type="hidden" name="dept_id" value="<?= $d['id'] ?>">
            <button type="submit" class="action-btn danger" title="Delete"><i class="bi bi-trash"></i></button>
          </form>
        </div>
      </div>
      <div class="dept-name"><?= htmlspecialchars($d['name']) ?></div>
      <div class="dept-count"><i class="bi bi-people" style="margin-right:4px;"></i><?= $d['student_count'] ?> student<?= $d['student_count'] != 1 ? 's' : '' ?></div>
      <?php if (!empty($d['description'])): ?>
      <div style="font-size:11.5px;color:var(--text-muted);line-height:1.5;"><?= htmlspecialchars($d['description']) ?></div>
      <?php endif; ?>
    </div>
    <?php endforeach; ?>
  </div>
  <?php endif; ?>

</div>
</div>

<!-- Create Modal -->
<div class="modal-overlay" id="createDeptModal" onclick="if(event.target===this)closeCreateDept()">
  <div class="modal-box">
    <div class="modal-header">
      <h4><i class="bi bi-building me-2"></i>Add Department</h4>
      <button class="modal-close" onclick="closeCreateDept()"><i class="bi bi-x"></i></button>
    </div>
    <form method="POST">
      <input type="hidden" name="action" value="create">
      <div class="form-row">
        <div class="form-group"><label>Code *</label><input type="text" name="code" required placeholder="e.g. CCS" style="text-transform:uppercase;"></div>
        <div class="form-group"><label>Name *</label><input type="text" name="name" required placeholder="e.g. College of Computing Studies"></div>
      </div>
      <div class="form-group"><label>Description</label><textarea name="description" rows="3" placeholder="Optional short description..."></textarea></div>
      <div class="modal-actions">
        <button type="submit" class="btn-save"><i class="bi bi-plus-lg me-1"></i>Add Department</button>
        <button type="button" class="btn-cancel-modal" onclick="closeCreateDept()">Cancel</button>
      </div>
    </form>
  </div>
</div>

<!-- Edit Modal -->
<div class="modal-overlay" id="editDeptModal" onclick="if(event.target===this)closeEditDept()">
  <div class="modal-box">
    <div class="modal-header">
      <h4><i class="bi bi-pencil me-2"></i>Edit Department</h4>
      <button class="modal-close" onclick="closeEditDept()"><i class="bi bi-x"></i></button>
    </div>
    <form method="POST">
      <input type="hidden" name="action" value="edit">
      <input type="hidden" name="dept_id" id="editDeptId">
      <div class="form-row">
        <div class="form-group"><label>Code *</label><input type="text" name="code" id="editDeptCode" required style="text-transform:uppercase;"></div>
        <div class="form-group"><label>Name *</label><input type="text" name="name" id="editDeptName" required></div>
      </div>
      <div class="form-group"><label>Description</label><textarea name="description" id="editDeptDesc" rows="3"></textarea></div>
      <div class="modal-actions">
        <button type="submit" class="btn-save"><i class="bi bi-check2 me-1"></i>Save Changes</button>
        <button type="button" class="btn-cancel-modal" onclick="closeEditDept()">Cancel</button>
      </div>
    </form>
  </div>
</div>

<script>
function openCreateDept()  { document.getElementById('createDeptModal').classList.add('open'); }
function closeCreateDept() { document.getElementById('createDeptModal').classList.remove('open'); }
function openEditDept(id, code, name, desc) {
  document.getElementById('editDeptId').value   = id;
  document.getElementById('editDeptCode').value = code;
  document.getElementById('editDeptName').value = name;
  document.getElementById('editDeptDesc').value = desc;
  document.getElementById('editDeptModal').classList.add('open');
}
function closeEditDept() { document.getElementById('editDeptModal').classList.remove('open'); }
</script>
</body>
</html>
