<?php
require_once '../config.php';
require_once '../db_functions.php';
require_login('admin');

$active_page = 'profile';
$success_msg = '';
$error_msg   = '';

$user = get_user($pdo, $_SESSION['user_id']);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $action = $_POST['action'] ?? '';
  if ($action === 'update_profile') {
    $full_name = trim($_POST['full_name'] ?? '');
    $email     = trim($_POST['email']     ?? '');
    if ($full_name && $email) {
      $pdo->prepare("UPDATE users SET full_name=?, email=? WHERE id=?")->execute([$full_name, $email, $_SESSION['user_id']]);
      $_SESSION['full_name'] = $full_name;
      $success_msg = 'Profile updated.';
      $user = get_user($pdo, $_SESSION['user_id']);
    } else { $error_msg = 'Name and email are required.'; }
  } elseif ($action === 'change_password') {
    $current  = $_POST['current_password'] ?? '';
    $new_pass = $_POST['new_password']     ?? '';
    $confirm  = $_POST['confirm_password'] ?? '';
    if (!password_verify($current, $user['password'])) {
      $error_msg = 'Current password is incorrect.';
    } elseif (strlen($new_pass) < 6) {
      $error_msg = 'New password must be at least 6 characters.';
    } elseif ($new_pass !== $confirm) {
      $error_msg = 'Passwords do not match.';
    } else {
      $pdo->prepare("UPDATE users SET password=? WHERE id=?")->execute([password_hash($new_pass, PASSWORD_DEFAULT), $_SESSION['user_id']]);
      $success_msg = 'Password changed successfully.';
    }
  }
}

$admin_initial = strtoupper(substr($user['full_name'] ?? 'A', 0, 1));
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Profile – CampusConnect Admin</title>
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
  <link rel="stylesheet" href="css/admin.css">
</head>
<body>

<?php include 'header.php'; ?>

<div class="layout">
<?php include 'sidebar.php'; ?>

<div class="main">
  <div class="page-header">
    <div>
      <div class="page-title">My Profile</div>
      <div class="page-sub">Manage your account details and security</div>
    </div>
  </div>

  <?php if ($success_msg): ?><div class="alert alert-success" style="max-width:680px;"><i class="bi bi-check-circle"></i> <?= htmlspecialchars($success_msg) ?></div><?php endif; ?>
  <?php if ($error_msg):   ?><div class="alert alert-error"   style="max-width:680px;"><i class="bi bi-exclamation-circle"></i> <?= htmlspecialchars($error_msg) ?></div><?php endif; ?>

  <div class="profile-wrap">

    <!-- Profile Info -->
    <div class="profile-card">
      <div class="profile-banner"></div>
      <div class="profile-body">
        <div class="profile-avatar-wrap">
          <div class="profile-avatar"><?= $admin_initial ?></div>
        </div>
        <div class="profile-name"><?= htmlspecialchars($user['full_name'] ?? '') ?></div>
        <span class="profile-role-tag">Administrator</span>

        <form method="POST">
          <input type="hidden" name="action" value="update_profile">
          <div class="form-row">
            <div class="form-group">
              <label>Full Name *</label>
              <input type="text" name="full_name" value="<?= htmlspecialchars($user['full_name'] ?? '') ?>" required>
            </div>
            <div class="form-group">
              <label>Email Address *</label>
              <input type="email" name="email" value="<?= htmlspecialchars($user['email'] ?? '') ?>" required>
            </div>
          </div>
          <button type="submit" class="btn-primary"><i class="bi bi-check2 me-1"></i>Save Profile</button>
        </form>
      </div>
    </div>

    <!-- Change Password -->
    <div class="profile-card">
      <div class="card-header" style="border-bottom:1px solid var(--border);padding:16px 28px;">
        <h4><i class="bi bi-shield-lock me-2"></i>Change Password</h4>
      </div>
      <div style="padding:24px 28px;">
        <form method="POST">
          <input type="hidden" name="action" value="change_password">
          <div class="form-row">
            <div class="form-group">
              <label>Current Password</label>
              <input type="password" name="current_password" placeholder="Enter current password">
            </div>
            <div class="form-group">
              <label>New Password</label>
              <input type="password" name="new_password" placeholder="Min. 6 characters">
            </div>
          </div>
          <div class="form-group" style="max-width:320px;">
            <label>Confirm New Password</label>
            <input type="password" name="confirm_password" placeholder="Repeat new password">
          </div>
          <button type="submit" class="btn-primary"><i class="bi bi-shield-check me-1"></i>Update Password</button>
        </form>
      </div>
    </div>

  </div><!-- end .profile-wrap -->
</div>
</div>
</body>
</html>
