<?php
require_once '../config.php';
require_once '../db_functions.php';
require_login('admin');

$active_page = 'users';
$success_msg = '';
$error_msg   = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $action = $_POST['action'] ?? '';
  if ($action === 'create') {
    $full_name     = trim($_POST['full_name'] ?? '');
    $email         = trim($_POST['email'] ?? '');
    $password      = $_POST['password'] ?? '';
    $role          = $_POST['role'] ?? 'student';
    $department_id = (int)($_POST['department_id'] ?? 0) ?: null;
    if ($full_name && $email && $password) {
      $hashed = password_hash($password, PASSWORD_DEFAULT);
      try {
        $pdo->prepare("INSERT INTO users (full_name, email, password, role, department_id, created_at) VALUES (?, ?, ?, ?, ?, NOW())")->execute([$full_name, $email, $hashed, $role, $department_id]);
        $success_msg = 'Account created successfully.';
      } catch (PDOException $e) {
        $error_msg = 'Email already exists or an error occurred.';
      }
    } else { $error_msg = 'Full name, email, and password are required.'; }
  } elseif ($action === 'delete') {
    $id = (int)($_POST['user_id'] ?? 0);
    if ($id > 0 && $id !== (int)$_SESSION['user_id']) {
      $pdo->prepare("DELETE FROM users WHERE id=?")->execute([$id]);
      $success_msg = 'User deleted.';
    } else { $error_msg = 'Cannot delete your own account.'; }
  } elseif ($action === 'change_role') {
    $id = (int)($_POST['user_id'] ?? 0);
    $newRole = $_POST['new_role'] ?? '';
    if ($id > 0 && in_array($newRole, ['student','organizer','admin'])) {
      $pdo->prepare("UPDATE users SET role=? WHERE id=?")->execute([$newRole, $id]);
      $success_msg = 'Role updated.';
    }
  }
}

$departments = get_departments($pdo);
$filter_role = $_GET['role'] ?? 'all';
$where = $filter_role !== 'all' ? "WHERE u.role = " . $pdo->quote($filter_role) : '';
$users = $pdo->query("SELECT u.*, d.name AS department_name, d.code AS dept_code FROM users u LEFT JOIN departments d ON u.department_id = d.id $where ORDER BY u.created_at DESC")->fetchAll(PDO::FETCH_ASSOC);
$cnt_students = $pdo->query("SELECT COUNT(*) FROM users WHERE role='student'")->fetchColumn();
$cnt_officers = $pdo->query("SELECT COUNT(*) FROM users WHERE role='organizer'")->fetchColumn();
$cnt_admins   = $pdo->query("SELECT COUNT(*) FROM users WHERE role='admin'")->fetchColumn();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>User Management – CampusConnect Admin</title>
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
  <link rel="stylesheet" href="css/admin.css">
</head>
<body>

<?php include 'header.php'; ?>

<div class="layout">
<?php include 'sidebar.php'; ?>

<div class="main">
  <div class="page-header">
    <div>
      <div class="page-title">User Management</div>
      <div class="page-sub">Manage student, officer, and admin accounts</div>
    </div>
    <button class="btn-primary" onclick="openCreateUser()">
      <i class="bi bi-person-plus"></i> Add User
    </button>
  </div>

  <?php if ($success_msg): ?><div class="alert alert-success"><i class="bi bi-check-circle"></i> <?= htmlspecialchars($success_msg) ?></div><?php endif; ?>
  <?php if ($error_msg):   ?><div class="alert alert-error"><i class="bi bi-exclamation-circle"></i> <?= htmlspecialchars($error_msg) ?></div><?php endif; ?>

  <!-- Role Filter Tabs -->
  <div class="tab-row">
    <a href="user_management.php"               class="tab-btn <?= $filter_role === 'all'       ? 'active' : '' ?>">All</a>
    <a href="user_management.php?role=student"  class="tab-btn <?= $filter_role === 'student'   ? 'active' : '' ?>">
      Students <span style="font-size:11px;opacity:.8;">(<?= $cnt_students ?>)</span>
    </a>
    <a href="user_management.php?role=organizer" class="tab-btn <?= $filter_role === 'organizer' ? 'active' : '' ?>">
      Officers <span style="font-size:11px;opacity:.8;">(<?= $cnt_officers ?>)</span>
    </a>
    <a href="user_management.php?role=admin"    class="tab-btn <?= $filter_role === 'admin'     ? 'active' : '' ?>">
      Admins <span style="font-size:11px;opacity:.8;">(<?= $cnt_admins ?>)</span>
    </a>
  </div>

  <div class="card">
    <div class="card-header">
      <h4>Users <span style="font-weight:400;color:var(--text-muted);font-size:13px;">(<?= count($users) ?>)</span></h4>
    </div>
    <?php if (empty($users)): ?>
    <div class="empty-state">
      <i class="bi bi-people"></i>
      <p>No users found.</p>
    </div>
    <?php else: ?>
    <table class="data-table">
      <thead>
        <tr><th>User</th><th>Role</th><th>Department</th><th>Joined</th><th>Actions</th></tr>
      </thead>
      <tbody>
        <?php foreach ($users as $u): ?>
        <tr>
          <td>
            <div class="user-cell">
              <div class="user-avatar"><?= strtoupper(substr($u['full_name'] ?? '?', 0, 1)) ?></div>
              <div>
                <div class="user-name"><?= htmlspecialchars($u['full_name'] ?? '') ?></div>
                <div class="user-email"><?= htmlspecialchars($u['email'] ?? '') ?></div>
              </div>
            </div>
          </td>
          <td>
            <span class="badge badge-<?= $u['role'] === 'admin' ? 'admin' : ($u['role'] === 'organizer' ? 'officer' : 'student') ?>">
              <?= ucfirst($u['role'] === 'organizer' ? 'Officer' : ($u['role'] ?? 'Student')) ?>
            </span>
          </td>
          <td style="color:var(--text-secondary);font-size:12px;"><?= htmlspecialchars($u['department_name'] ?? '—') ?></td>
          <td style="color:var(--text-muted);font-size:12px;white-space:nowrap;"><?= isset($u['created_at']) ? date('M j, Y', strtotime($u['created_at'])) : '—' ?></td>
          <td>
            <div class="table-actions">
              <!-- Change Role -->
              <form method="POST" style="display:inline;">
                <input type="hidden" name="action" value="change_role">
                <input type="hidden" name="user_id" value="<?= $u['id'] ?>">
                <select name="new_role" class="filter-select" style="padding:4px 8px;font-size:12px;" onchange="this.form.submit()" title="Change role">
                  <option value="student"   <?= $u['role']==='student'   ? 'selected':'' ?>>Student</option>
                  <option value="organizer" <?= $u['role']==='organizer' ? 'selected':'' ?>>Officer</option>
                  <option value="admin"     <?= $u['role']==='admin'     ? 'selected':'' ?>>Admin</option>
                </select>
              </form>
              <?php if ($u['id'] != $_SESSION['user_id']): ?>
              <form method="POST" style="display:inline;" onsubmit="return confirm('Delete this user permanently?')">
                <input type="hidden" name="action" value="delete">
                <input type="hidden" name="user_id" value="<?= $u['id'] ?>">
                <button type="submit" class="action-btn danger" title="Delete user"><i class="bi bi-trash"></i></button>
              </form>
              <?php endif; ?>
            </div>
          </td>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
    <?php endif; ?>
  </div>
</div>
</div>

<!-- Create User Modal -->
<div class="modal-overlay" id="createUserModal" onclick="if(event.target===this)closeCreateUser()">
  <div class="modal-box">
    <div class="modal-header">
      <h4><i class="bi bi-person-plus me-2"></i>Add New User</h4>
      <button class="modal-close" onclick="closeCreateUser()"><i class="bi bi-x"></i></button>
    </div>
    <form method="POST">
      <input type="hidden" name="action" value="create">
      <div class="form-row">
        <div class="form-group"><label>Full Name *</label><input type="text" name="full_name" required placeholder="e.g. Juan dela Cruz"></div>
        <div class="form-group"><label>Email *</label><input type="email" name="email" required placeholder="email@wmsu.edu.ph"></div>
      </div>
      <div class="form-row">
        <div class="form-group"><label>Password *</label><input type="password" name="password" required placeholder="Min. 6 characters"></div>
        <div class="form-group">
          <label>Role</label>
          <select name="role">
            <option value="student">Student</option>
            <option value="organizer">Officer</option>
            <option value="admin">Admin</option>
          </select>
        </div>
      </div>
      <div class="form-group">
        <label>Department</label>
        <select name="department_id">
          <option value="">— Select Department —</option>
          <?php foreach ($departments as $d): ?>
          <option value="<?= $d['id'] ?>"><?= htmlspecialchars($d['name']) ?></option>
          <?php endforeach; ?>
        </select>
      </div>
      <div class="modal-actions">
        <button type="submit" class="btn-save"><i class="bi bi-person-check me-1"></i>Create Account</button>
        <button type="button" class="btn-cancel-modal" onclick="closeCreateUser()">Cancel</button>
      </div>
    </form>
  </div>
</div>

<script>
function openCreateUser()  { document.getElementById('createUserModal').classList.add('open'); }
function closeCreateUser() { document.getElementById('createUserModal').classList.remove('open'); }
</script>
</body>
</html>
