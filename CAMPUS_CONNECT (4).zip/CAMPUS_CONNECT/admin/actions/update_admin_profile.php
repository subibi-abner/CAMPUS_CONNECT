<?php
require_once '../../config.php';
require_login('admin');

header('Content-Type: application/json');
$action = $_POST['action'] ?? '';

if ($action === 'update_profile') {
  $full_name = trim($_POST['full_name'] ?? '');
  if (!$full_name) { echo json_encode(['success'=>false,'message'=>'Name is required.']); exit; }
  $stmt = $pdo->prepare("UPDATE users SET full_name=? WHERE id=?");
  $stmt->execute([$full_name, $_SESSION['user_id']]);
  $_SESSION['full_name'] = $full_name;
  echo json_encode(['success'=>true,'message'=>'Profile updated.']);

} elseif ($action === 'change_password') {
  $current = $_POST['current_password'] ?? '';
  $new     = $_POST['new_password']     ?? '';
  $row = $pdo->prepare("SELECT password FROM users WHERE id=?");
  $row->execute([$_SESSION['user_id']]);
  $user = $row->fetch(PDO::FETCH_ASSOC);
  if (!$user || !password_verify($current, $user['password'])) {
    echo json_encode(['success'=>false,'message'=>'Current password is incorrect.']); exit;
  }
  if (strlen($new) < 6) { echo json_encode(['success'=>false,'message'=>'Password must be at least 6 characters.']); exit; }
  $pdo->prepare("UPDATE users SET password=? WHERE id=?")->execute([password_hash($new, PASSWORD_DEFAULT), $_SESSION['user_id']]);
  echo json_encode(['success'=>true,'message'=>'Password updated successfully.']);

} else {
  echo json_encode(['success'=>false,'message'=>'Invalid action.']);
}
