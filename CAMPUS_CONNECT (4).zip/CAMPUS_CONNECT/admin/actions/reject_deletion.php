<?php
session_start();
require_once '../../config.php';
require_once '../../db_functions.php';
require_login('admin');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
  header('Location: ../event_management.php');
  exit;
}

$request_id = (int)($_POST['request_id'] ?? 0);
if (!$request_id) {
  $_SESSION['flash'] = ['type'=>'error','msg'=>'Invalid request'];
  header('Location: ../event_management.php');
  exit;
}

// Mark rejected
$stmt = $pdo->prepare("UPDATE deletion_requests SET status='rejected', resolved_at=NOW() WHERE id=? AND status='pending'");
if ($stmt->execute([$request_id])) {
  $_SESSION['flash'] = ['type'=>'success','msg'=>'Deletion request rejected.'];
} else {
  $_SESSION['flash'] = ['type'=>'error','msg'=>'Request not found or already processed.'];
}

header('Location: ../event_management.php');
exit;
?>

