<?php
session_start();
require_once '../../config.php';
require_once '../../db_functions.php';
require_login('admin');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
  header('Location: ../event_management.php');
  exit;
}

$event_id = (int)($_POST['event_id'] ?? 0);
if (!$event_id) {
  $_SESSION['flash'] = ['type'=>'error','msg'=>'Invalid request'];
  header('Location: ../event_management.php');
  exit;
}

// Get request details
$stmt = $pdo->prepare("SELECT r.reason, r.id FROM deletion_requests r WHERE r.event_id = ? AND r.status = 'pending'");
$stmt->execute([$event_id]);
$request = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$request) {
  $_SESSION['flash'] = ['type'=>'error','msg'=>'No pending request found'];
  header('Location: ../event_management.php');
  exit;
}

// Mark approved
$pdo->prepare("UPDATE deletion_requests SET status='approved', resolved_at=NOW() WHERE id=?")->execute([$request['id']]);

// Delete event + registrations
$pdo->prepare("DELETE FROM registrations WHERE event_id=?")->execute([$event_id]);
$pdo->prepare("UPDATE events SET status='deleted' WHERE id=?")->execute([$event_id]);

// Email students
$stmt = $pdo->prepare("SELECT DISTINCT u.email, u.full_name FROM registrations r JOIN users u ON r.user_id = u.id WHERE r.event_id=?");
$stmt->execute([$event_id]);
$students = $stmt->fetchAll(PDO::FETCH_ASSOC);

foreach ($students as $s) {
  $subject = 'Event Cancelled: Admin Approved Deletion';
  $msg = "Hi " . $s['full_name'] . ",\n\n";
  $msg .= "The event you registered for has been cancelled following organizer request.\n\n";
  $msg .= "Reason provided: " . $request['reason'] . "\n\n";
  $msg .= "Admin has approved the deletion.\n\n";
  $msg .= "Thank you,\nCampusConnect Admin";
  // mail($s['email'], $subject, $msg);
}

$_SESSION['flash'] = ['type'=>'success','msg'=>'Deletion approved. Students notified.'];
header('Location: ../event_management.php');
exit;
?>

