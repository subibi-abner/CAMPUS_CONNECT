<?php
session_start();
require_once '../config.php';
require_once '../db_functions.php';
require_login('admin');

// admin.php is the login entry point.
// Redirect to the real dashboard — all admin pages are separate PHP files.
header('Location: dashboard.php');
exit;
