<?php
require_once '../config.php';
require_once '../db_functions.php';
require_login('admin');

$active_page = 'analytics';

// ═══════════════════════════════════════════════════════
// SUMMARY CARDS — real counts from DB
// ═══════════════════════════════════════════════════════
$total_students   = (int)$pdo->query("SELECT COUNT(*) FROM users WHERE role='student'")->fetchColumn();
$total_organizers = (int)$pdo->query("SELECT COUNT(*) FROM users WHERE role='organizer' OR role='staff'")->fetchColumn();
$total_admins     = (int)$pdo->query("SELECT COUNT(*) FROM users WHERE role='admin'")->fetchColumn();
$total_users      = $total_students + $total_organizers + $total_admins;

$total_events     = (int)$pdo->query("SELECT COUNT(*) FROM events")->fetchColumn();
$events_pending   = (int)$pdo->query("SELECT COUNT(*) FROM events WHERE status='pending'")->fetchColumn();
$events_approved  = (int)$pdo->query("SELECT COUNT(*) FROM events WHERE status='approved'")->fetchColumn();
$events_ongoing   = (int)$pdo->query("SELECT COUNT(*) FROM events WHERE status='ongoing'")->fetchColumn();
$events_completed = (int)$pdo->query("SELECT COUNT(*) FROM events WHERE status='completed'")->fetchColumn();
$events_draft     = (int)$pdo->query("SELECT COUNT(*) FROM events WHERE status='draft'")->fetchColumn();
$events_rejected  = (int)$pdo->query("SELECT COUNT(*) FROM events WHERE status='rejected'")->fetchColumn();

$total_registrations = (int)$pdo->query("SELECT COUNT(*) FROM registrations")->fetchColumn();
$total_attendance    = (int)$pdo->query("SELECT COUNT(*) FROM attendance WHERE time_in IS NOT NULL")->fetchColumn();

// Attendance rate = attended / registered (if any registrations exist)
$attendance_rate = $total_registrations > 0
  ? round($total_attendance / $total_registrations * 100, 1)
  : 0;

// Active users = users who registered for at least one event
$active_users = (int)$pdo->query("SELECT COUNT(DISTINCT user_id) FROM registrations")->fetchColumn();
$inactive_users = $total_users - $active_users;

// ═══════════════════════════════════════════════════════
// EVENTS PER MONTH (last 12 months) — for bar chart
// ═══════════════════════════════════════════════════════
$eventsPerMonth = $pdo->query("
  SELECT DATE_FORMAT(created_at, '%Y-%m') AS ym,
         DATE_FORMAT(created_at, '%b %Y') AS label,
         COUNT(*) AS total
  FROM events
  WHERE created_at >= DATE_SUB(NOW(), INTERVAL 12 MONTH)
  GROUP BY ym, label
  ORDER BY ym ASC
")->fetchAll(PDO::FETCH_ASSOC);

// ═══════════════════════════════════════════════════════
// REGISTRATIONS PER MONTH (last 12 months)
// ═══════════════════════════════════════════════════════
$regsPerMonth = $pdo->query("
  SELECT DATE_FORMAT(registered_at, '%Y-%m') AS ym,
         COUNT(*) AS total
  FROM registrations
  WHERE registered_at >= DATE_SUB(NOW(), INTERVAL 12 MONTH)
  GROUP BY ym
  ORDER BY ym ASC
")->fetchAll(PDO::FETCH_ASSOC);
// Index by ym for merge
$regsMap = [];
foreach ($regsPerMonth as $r) $regsMap[$r['ym']] = (int)$r['total'];

// ═══════════════════════════════════════════════════════
// ATTENDANCE PER MONTH (last 12 months)
// ═══════════════════════════════════════════════════════
$attPerMonth = $pdo->query("
  SELECT DATE_FORMAT(time_in, '%Y-%m') AS ym,
         COUNT(*) AS total
  FROM attendance
  WHERE time_in IS NOT NULL
    AND time_in >= DATE_SUB(NOW(), INTERVAL 12 MONTH)
  GROUP BY ym
  ORDER BY ym ASC
")->fetchAll(PDO::FETCH_ASSOC);
$attMap = [];
foreach ($attPerMonth as $a) $attMap[$a['ym']] = (int)$a['total'];

// Build merged month labels array for charts
$chartLabels = [];
$chartEvents = [];
$chartRegs   = [];
$chartAtt    = [];
foreach ($eventsPerMonth as $row) {
  $chartLabels[] = $row['label'];
  $chartEvents[] = (int)$row['total'];
  $chartRegs[]   = $regsMap[$row['ym']] ?? 0;
  $chartAtt[]    = $attMap[$row['ym']] ?? 0;
}

// ═══════════════════════════════════════════════════════
// USERS PER ROLE — for donut chart
// ═══════════════════════════════════════════════════════
$usersPerRole = $pdo->query("
  SELECT role, COUNT(*) AS total FROM users GROUP BY role ORDER BY total DESC
")->fetchAll(PDO::FETCH_ASSOC);

// ═══════════════════════════════════════════════════════
// TOP EVENTS BY REGISTRATION
// ═══════════════════════════════════════════════════════
$topEvents = $pdo->query("
  SELECT e.title, COUNT(r.id) AS reg_count, e.max_attendees, e.status
  FROM events e
  LEFT JOIN registrations r ON r.event_id = e.id
  GROUP BY e.id
  ORDER BY reg_count DESC
  LIMIT 8
")->fetchAll(PDO::FETCH_ASSOC);

// ═══════════════════════════════════════════════════════
// EVENTS PER CATEGORY
// ═══════════════════════════════════════════════════════
$eventsPerCat = $pdo->query("
  SELECT COALESCE(NULLIF(category,''),'General') AS category, COUNT(*) AS total
  FROM events
  GROUP BY category
  ORDER BY total DESC
")->fetchAll(PDO::FETCH_ASSOC);

// ═══════════════════════════════════════════════════════
// EVENTS PER DEPARTMENT (top 8)
// ═══════════════════════════════════════════════════════
$eventsPerDept = $pdo->query("
  SELECT COALESCE(d.code, 'University-wide') AS dept, COUNT(e.id) AS total
  FROM events e
  LEFT JOIN departments d ON e.department_id = d.id
  GROUP BY dept
  ORDER BY total DESC
  LIMIT 8
")->fetchAll(PDO::FETCH_ASSOC);

// ═══════════════════════════════════════════════════════
// RECENT REGISTRATIONS (activity feed)
// ═══════════════════════════════════════════════════════
$recentRegs = $pdo->query("
  SELECT u.full_name, u.role, e.title AS event_title, r.registered_at
  FROM registrations r
  JOIN users u ON r.user_id = u.id
  JOIN events e ON r.event_id = e.id
  ORDER BY r.registered_at DESC
  LIMIT 8
")->fetchAll(PDO::FETCH_ASSOC);

// JSON encode for JS
$jsLabels   = json_encode($chartLabels);
$jsEvents   = json_encode($chartEvents);
$jsRegs     = json_encode($chartRegs);
$jsAtt      = json_encode($chartAtt);
$jsRoleLabels = json_encode(array_column($usersPerRole, 'role'));
$jsRoleData   = json_encode(array_map('intval', array_column($usersPerRole, 'total')));
$jsCatLabels  = json_encode(array_column($eventsPerCat, 'category'));
$jsCatData    = json_encode(array_map('intval', array_column($eventsPerCat, 'total')));
$jsDeptLabels = json_encode(array_column($eventsPerDept, 'dept'));
$jsDeptData   = json_encode(array_map('intval', array_column($eventsPerDept, 'total')));
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Analytics – CampusConnect Admin</title>
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
  <link rel="stylesheet" href="css/admin.css">
  <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
  <style>
    /* ── Analytics-specific styles ── */
    .analytics-grid { display: grid; gap: 20px; margin-bottom: 24px; }
    .summary-row    { grid-template-columns: repeat(5, 1fr); }
    .charts-row-2   { grid-template-columns: 2fr 1fr; }
    .charts-row-3   { grid-template-columns: 1fr 1fr 1fr; }
    .charts-row-bottom { grid-template-columns: 1fr 1fr; }

    .an-card {
      background: var(--bg-card);
      border: 1px solid var(--border);
      border-radius: 12px;
      padding: 20px 22px;
    }
    .an-card-title {
      font-size: 13px; font-weight: 600; color: var(--text-primary);
      margin-bottom: 16px; display: flex; align-items: center; gap: 8px;
    }
    .an-card-title i { font-size: 15px; color: var(--red); }

    /* Summary stat cards */
    .an-stat {
      background: var(--bg-card); border: 1px solid var(--border);
      border-radius: 12px; padding: 18px 20px;
      display: flex; align-items: center; gap: 14px;
      transition: box-shadow .15s;
    }
    .an-stat:hover { box-shadow: 0 4px 20px rgba(0,0,0,.07); }
    .an-stat-icon {
      width: 44px; height: 44px; border-radius: 10px;
      display: flex; align-items: center; justify-content: center;
      font-size: 20px; flex-shrink: 0;
    }
    .an-stat-val  { font-size: 24px; font-weight: 700; color: var(--text-primary); line-height: 1; }
    .an-stat-lbl  { font-size: 11.5px; color: var(--text-muted); margin-top: 3px; }
    .an-stat-sub  { font-size: 11px; color: var(--text-muted); margin-top: 6px; }
    .pill { display:inline-block; padding:1px 7px; border-radius:20px; font-size:10px; font-weight:600; margin:1px; }
    .pill-green  { background:#dcfce7; color:#16a34a; }
    .pill-blue   { background:#dbeafe; color:#1d4ed8; }
    .pill-yellow { background:#fef9c3; color:#b45309; }
    .pill-gray   { background:#f1f5f9; color:#64748b; }
    .pill-red    { background:#fee2e2; color:#b91c1c; }
    .pill-purple { background:#ede9fe; color:#6d28d9; }
    .pill-orange { background:#fff7ed; color:#c2410c; }

    /* Chart containers */
    .chart-wrap { position: relative; }
    .chart-wrap canvas { width: 100% !important; }

    /* Activity feed */
    .feed-item {
      display: flex; align-items: center; gap: 10px;
      padding: 10px 0; border-bottom: 1px solid #f3f4f6;
      font-size: 12.5px;
    }
    .feed-item:last-child { border-bottom: none; }
    .feed-avatar {
      width: 32px; height: 32px; border-radius: 50%; background: var(--red-light);
      color: var(--red); display: flex; align-items: center; justify-content: center;
      font-size: 13px; font-weight: 700; flex-shrink: 0;
    }
    .feed-name  { font-weight: 600; color: var(--text-primary); }
    .feed-event { color: var(--text-secondary); font-size: 11.5px; }
    .feed-time  { font-size: 11px; color: var(--text-muted); margin-left: auto; white-space: nowrap; }

    /* Top events table */
    .top-ev-row { display: flex; align-items: center; gap: 10px; padding: 9px 0; border-bottom: 1px solid #f3f4f6; }
    .top-ev-row:last-child { border-bottom: none; }
    .top-ev-bar-wrap { flex: 1; background: #f3f4f6; border-radius: 4px; height: 6px; overflow: hidden; }
    .top-ev-bar-fill { height: 100%; border-radius: 4px; background: var(--red); }
    .top-ev-title { font-size: 12.5px; font-weight: 500; color: var(--text-primary); min-width: 0; flex: 1; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
    .top-ev-count { font-size: 12px; font-weight: 700; color: var(--text-primary); min-width: 28px; text-align: right; }

    /* Section header */
    .section-label {
      font-size: 11px; font-weight: 600; letter-spacing: .07em;
      text-transform: uppercase; color: var(--text-muted);
      margin: 8px 0 14px;
    }

    @media (max-width: 1100px) {
      .summary-row   { grid-template-columns: repeat(3, 1fr); }
      .charts-row-2  { grid-template-columns: 1fr; }
      .charts-row-3  { grid-template-columns: 1fr 1fr; }
      .charts-row-bottom { grid-template-columns: 1fr; }
    }
    @media (max-width: 700px) {
      .summary-row  { grid-template-columns: 1fr 1fr; }
      .charts-row-3 { grid-template-columns: 1fr; }
    }
  </style>
</head>
<body>

<?php include 'header.php'; ?>

<div class="layout">
<?php include 'sidebar.php'; ?>

<div class="main">
  <div class="page-header">
    <div>
      <div class="page-title">Analytics</div>
      <div class="page-sub">Live system metrics — all data pulled from the database</div>
    </div>
    <div style="font-size:12px;color:var(--text-muted);">
      <i class="bi bi-clock"></i> Last updated: <?= date('M j, Y g:i A') ?>
    </div>
  </div>

  <!-- ── SECTION: Summary Cards ───────────────────────────── -->
  <div class="section-label">Overview</div>
  <div class="analytics-grid summary-row">

    <!-- Total Users -->
    <div class="an-stat">
      <div class="an-stat-icon" style="background:#eff6ff;color:#3b82f6;">
        <i class="bi bi-people-fill"></i>
      </div>
      <div>
        <div class="an-stat-val"><?= number_format($total_users) ?></div>
        <div class="an-stat-lbl">Total Users</div>
        <div class="an-stat-sub">
          <span class="pill pill-blue"><?= $total_students ?> students</span>
          <span class="pill pill-yellow"><?= $total_organizers ?> organizers</span>
          <span class="pill pill-red"><?= $total_admins ?> admins</span>
        </div>
      </div>
    </div>

    <!-- Active vs Inactive -->
    <div class="an-stat">
      <div class="an-stat-icon" style="background:#ecfdf5;color:#059669;">
        <i class="bi bi-person-check-fill"></i>
      </div>
      <div>
        <div class="an-stat-val"><?= number_format($active_users) ?></div>
        <div class="an-stat-lbl">Active Users</div>
        <div class="an-stat-sub">
          <span class="pill pill-green"><?= $active_users ?> active</span>
          <span class="pill pill-gray"><?= $inactive_users ?> inactive</span>
          <?php $act_pct = $total_users > 0 ? round($active_users/$total_users*100) : 0; ?>
          <span class="pill pill-blue"><?= $act_pct ?>% rate</span>
        </div>
      </div>
    </div>

    <!-- Total Events -->
    <div class="an-stat">
      <div class="an-stat-icon" style="background:#f5f3ff;color:#7c3aed;">
        <i class="bi bi-calendar-event-fill"></i>
      </div>
      <div>
        <div class="an-stat-val"><?= number_format($total_events) ?></div>
        <div class="an-stat-lbl">Total Events</div>
        <div class="an-stat-sub">
          <span class="pill pill-gray"><?= $events_draft ?> draft</span>
          <span class="pill pill-yellow"><?= $events_pending ?> pending</span>
          <span class="pill pill-green"><?= $events_approved ?> approved</span>
          <span class="pill pill-orange"><?= $events_ongoing ?> ongoing</span>
          <span class="pill pill-purple"><?= $events_completed ?> done</span>
        </div>
      </div>
    </div>

    <!-- Total Registrations -->
    <div class="an-stat">
      <div class="an-stat-icon" style="background:#fff7ed;color:#ea580c;">
        <i class="bi bi-ticket-perforated-fill"></i>
      </div>
      <div>
        <div class="an-stat-val"><?= number_format($total_registrations) ?></div>
        <div class="an-stat-lbl">Registrations</div>
        <div class="an-stat-sub" style="color:var(--text-muted);font-size:11px;">
          Across all events
        </div>
      </div>
    </div>

    <!-- Attendance Rate -->
    <div class="an-stat">
      <div class="an-stat-icon" style="background:#fef0f0;color:var(--red);">
        <i class="bi bi-graph-up-arrow"></i>
      </div>
      <div>
        <div class="an-stat-val"><?= $attendance_rate ?>%</div>
        <div class="an-stat-lbl">Attendance Rate</div>
        <div class="an-stat-sub">
          <?= number_format($total_attendance) ?> attended / <?= number_format($total_registrations) ?> registered
        </div>
      </div>
    </div>
  </div>

  <!-- ── SECTION: Charts Row 1 — Events+Regs over time ──── -->
  <div class="section-label">Trends (Last 12 Months)</div>
  <div class="analytics-grid charts-row-2">

    <!-- Events + Registrations + Attendance per month -->
    <div class="an-card">
      <div class="an-card-title"><i class="bi bi-bar-chart-fill"></i> Events &amp; Registrations Over Time</div>
      <?php if (empty($chartLabels)): ?>
        <div style="text-align:center;color:var(--text-muted);padding:40px 0;font-size:13px;">
          Not enough data yet — events will appear here as they are created.
        </div>
      <?php else: ?>
      <div class="chart-wrap" style="height:260px;">
        <canvas id="timelineChart"></canvas>
      </div>
      <?php endif; ?>
    </div>

    <!-- User roles donut -->
    <div class="an-card">
      <div class="an-card-title"><i class="bi bi-pie-chart-fill"></i> Users by Role</div>
      <?php if ($total_users === 0): ?>
        <div style="text-align:center;color:var(--text-muted);padding:40px 0;font-size:13px;">No users yet.</div>
      <?php else: ?>
      <div class="chart-wrap" style="height:200px;">
        <canvas id="roleDonut"></canvas>
      </div>
      <div style="margin-top:12px;display:flex;flex-wrap:wrap;gap:8px;justify-content:center;">
        <?php foreach ($usersPerRole as $ur): ?>
          <span style="font-size:12px;color:var(--text-secondary);">
            <strong><?= $ur['total'] ?></strong> <?= ucfirst($ur['role']) ?>
          </span>
        <?php endforeach; ?>
      </div>
      <?php endif; ?>
    </div>
  </div>

  <!-- ── SECTION: Charts Row 2 — Category, Dept, Status ── -->
  <div class="analytics-grid charts-row-3">

    <!-- Events per status donut -->
    <div class="an-card">
      <div class="an-card-title"><i class="bi bi-circle-half"></i> Events by Status</div>
      <div class="chart-wrap" style="height:180px;">
        <canvas id="statusDonut"></canvas>
      </div>
      <div style="margin-top:10px;display:flex;flex-wrap:wrap;gap:6px;justify-content:center;">
        <?php
          $statusBadge = [
            'draft'=>'pill-gray','pending'=>'pill-yellow','approved'=>'pill-green',
            'ongoing'=>'pill-orange','completed'=>'pill-purple','rejected'=>'pill-red'
          ];
          $statuses = [
            'draft'=>$events_draft,'pending'=>$events_pending,'approved'=>$events_approved,
            'ongoing'=>$events_ongoing,'completed'=>$events_completed,'rejected'=>$events_rejected
          ];
          foreach($statuses as $s=>$c): if($c > 0): ?>
          <span class="pill <?= $statusBadge[$s] ?? 'pill-gray' ?>"><?= ucfirst($s) ?>: <?= $c ?></span>
        <?php endif; endforeach; ?>
      </div>
    </div>

    <!-- Events per category -->
    <div class="an-card">
      <div class="an-card-title"><i class="bi bi-tag-fill"></i> Events by Category</div>
      <?php if (empty($eventsPerCat)): ?>
        <div style="text-align:center;color:var(--text-muted);padding:30px 0;font-size:13px;">No events yet.</div>
      <?php else: ?>
      <div class="chart-wrap" style="height:180px;">
        <canvas id="categoryBar"></canvas>
      </div>
      <?php endif; ?>
    </div>

    <!-- Events per department -->
    <div class="an-card">
      <div class="an-card-title"><i class="bi bi-building"></i> Events by Department</div>
      <?php if (empty($eventsPerDept)): ?>
        <div style="text-align:center;color:var(--text-muted);padding:30px 0;font-size:13px;">No events yet.</div>
      <?php else: ?>
      <div class="chart-wrap" style="height:180px;">
        <canvas id="deptBar"></canvas>
      </div>
      <?php endif; ?>
    </div>
  </div>

  <!-- ── SECTION: Bottom Row — Top events + Activity feed ─ -->
  <div class="analytics-grid charts-row-bottom">

    <!-- Top events by registration -->
    <div class="an-card">
      <div class="an-card-title"><i class="bi bi-trophy-fill"></i> Top Events by Registrations</div>
      <?php if (empty($topEvents)): ?>
        <div style="color:var(--text-muted);font-size:13px;">No events yet.</div>
      <?php else:
        $maxReg = max(array_column($topEvents, 'reg_count')) ?: 1;
        foreach ($topEvents as $te):
          $pct = round($te['reg_count'] / $maxReg * 100);
      ?>
        <div class="top-ev-row">
          <div class="top-ev-title" title="<?= htmlspecialchars($te['title']) ?>"><?= htmlspecialchars($te['title']) ?></div>
          <div class="top-ev-bar-wrap">
            <div class="top-ev-bar-fill" style="width:<?= $pct ?>%;"></div>
          </div>
          <div class="top-ev-count"><?= $te['reg_count'] ?></div>
        </div>
      <?php endforeach; endif; ?>
    </div>

    <!-- Recent registrations feed -->
    <div class="an-card">
      <div class="an-card-title"><i class="bi bi-activity"></i> Recent Registrations</div>
      <?php if (empty($recentRegs)): ?>
        <div style="color:var(--text-muted);font-size:13px;">No registrations yet.</div>
      <?php else: foreach ($recentRegs as $rr): ?>
        <div class="feed-item">
          <div class="feed-avatar"><?= strtoupper(substr($rr['full_name'],0,1)) ?></div>
          <div>
            <div class="feed-name"><?= htmlspecialchars($rr['full_name']) ?></div>
            <div class="feed-event">Registered for <?= htmlspecialchars($rr['event_title']) ?></div>
          </div>
          <div class="feed-time"><?= date('M j', strtotime($rr['registered_at'])) ?></div>
        </div>
      <?php endforeach; endif; ?>
    </div>
  </div>

</div><!-- end .main -->
</div><!-- end .layout -->

<script>
Chart.defaults.font.family = "'Poppins', sans-serif";
Chart.defaults.font.size   = 11;

const RED    = '#C0272D';
const colors = ['#C0272D','#3b82f6','#10b981','#f59e0b','#6366f1','#ec4899','#14b8a6','#f97316'];

// ── 1. Timeline: Events + Registrations + Attendance ──
<?php if (!empty($chartLabels)): ?>
new Chart(document.getElementById('timelineChart'), {
  type: 'bar',
  data: {
    labels: <?= $jsLabels ?>,
    datasets: [
      {
        label: 'Events Created',
        data: <?= $jsEvents ?>,
        backgroundColor: 'rgba(192,39,45,0.75)',
        borderRadius: 4, order: 1
      },
      {
        label: 'Registrations',
        data: <?= $jsRegs ?>,
        backgroundColor: 'rgba(59,130,246,0.7)',
        borderRadius: 4, order: 2
      },
      {
        label: 'Attendance',
        data: <?= $jsAtt ?>,
        type: 'line',
        borderColor: '#10b981',
        backgroundColor: 'rgba(16,185,129,0.1)',
        tension: 0.4, fill: true,
        pointBackgroundColor: '#10b981',
        pointRadius: 4, order: 0
      }
    ]
  },
  options: {
    responsive: true, maintainAspectRatio: false,
    plugins: {
      legend: { position: 'top', labels: { boxWidth: 12, padding: 16 } },
      tooltip: { mode: 'index', intersect: false }
    },
    scales: {
      x: { grid: { display: false }, ticks: { maxRotation: 45 } },
      y: { beginAtZero: true, grid: { color: 'rgba(0,0,0,.05)' } }
    }
  }
});
<?php endif; ?>

// ── 2. Role donut ──
<?php if ($total_users > 0): ?>
new Chart(document.getElementById('roleDonut'), {
  type: 'doughnut',
  data: {
    labels: <?= $jsRoleLabels ?>.map(l => l.charAt(0).toUpperCase() + l.slice(1)),
    datasets: [{
      data: <?= $jsRoleData ?>,
      backgroundColor: colors,
      borderWidth: 2, borderColor: '#fff'
    }]
  },
  options: {
    responsive: true, maintainAspectRatio: false,
    cutout: '62%',
    plugins: {
      legend: { position: 'bottom', labels: { boxWidth: 12, padding: 14 } }
    }
  }
});
<?php endif; ?>

// ── 3. Status donut ──
(function() {
  const statusLabels = ['Draft','Pending','Approved','Ongoing','Completed','Rejected'];
  const statusData   = [<?= $events_draft ?>,<?= $events_pending ?>,<?= $events_approved ?>,<?= $events_ongoing ?>,<?= $events_completed ?>,<?= $events_rejected ?>];
  const statusColors = ['#94a3b8','#f59e0b','#16a34a','#f97316','#6366f1','#ef4444'];
  if (statusData.reduce((a,b)=>a+b,0) === 0) return;
  new Chart(document.getElementById('statusDonut'), {
    type: 'doughnut',
    data: {
      labels: statusLabels,
      datasets: [{ data: statusData, backgroundColor: statusColors, borderWidth: 2, borderColor: '#fff' }]
    },
    options: {
      responsive: true, maintainAspectRatio: false, cutout: '60%',
      plugins: { legend: { position: 'bottom', labels: { boxWidth: 10, padding: 10, font:{size:10} } } }
    }
  });
})();

// ── 4. Category bar ──
<?php if (!empty($eventsPerCat)): ?>
new Chart(document.getElementById('categoryBar'), {
  type: 'bar',
  data: {
    labels: <?= $jsCatLabels ?>,
    datasets: [{
      label: 'Events',
      data: <?= $jsCatData ?>,
      backgroundColor: colors,
      borderRadius: 5
    }]
  },
  options: {
    responsive: true, maintainAspectRatio: false, indexAxis: 'y',
    plugins: { legend: { display: false } },
    scales: {
      x: { beginAtZero: true, grid: { color: 'rgba(0,0,0,.05)' } },
      y: { grid: { display: false } }
    }
  }
});
<?php endif; ?>

// ── 5. Department bar ──
<?php if (!empty($eventsPerDept)): ?>
new Chart(document.getElementById('deptBar'), {
  type: 'bar',
  data: {
    labels: <?= $jsDeptLabels ?>,
    datasets: [{
      label: 'Events',
      data: <?= $jsDeptData ?>,
      backgroundColor: 'rgba(99,102,241,0.75)',
      borderRadius: 5
    }]
  },
  options: {
    responsive: true, maintainAspectRatio: false, indexAxis: 'y',
    plugins: { legend: { display: false } },
    scales: {
      x: { beginAtZero: true, grid: { color: 'rgba(0,0,0,.05)' } },
      y: { grid: { display: false }, ticks: { font: { size: 10 } } }
    }
  }
});
<?php endif; ?>
</script>
</body>
</html>
