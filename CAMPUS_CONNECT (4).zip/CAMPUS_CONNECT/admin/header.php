<?php
/**
 * header.php — Admin topbar with Profile & Settings as dropdown modals
 * Matches officer/student header design exactly.
 */
$admin_name    = $_SESSION['full_name'] ?? 'Administrator';
$admin_initial = strtoupper(substr($admin_name, 0, 1));
$admin_email   = $_SESSION['email'] ?? '';

// Fetch fresh data for modal pre-fill
$_admin_row = null;
try {
  $s = $pdo->prepare("SELECT * FROM users WHERE id = ?");
  $s->execute([$_SESSION['user_id'] ?? 0]);
  $_admin_row = $s->fetch(PDO::FETCH_ASSOC);
  if ($_admin_row) {
    $admin_name    = $_admin_row['full_name'] ?? $admin_name;
    $admin_initial = strtoupper(substr($admin_name, 0, 1));
    $admin_email   = $_admin_row['email'] ?? $admin_email;
  }
} catch (Exception $e) {}
?>

<header class="topbar">
  <div class="topbar-left">
    <div class="logo-wrap">
      <div class="logo-circle">C</div>
      <div>
        <div class="logo-text">CampusConnect</div>
        <div class="logo-sub">Admin Portal</div>
      </div>
    </div>
    <div class="topbar-search">
      <i class="bi bi-search"></i>
      <input type="text" placeholder="Search events, users...">
    </div>
  </div>
  <div class="topbar-right">
    <button class="icon-btn" title="Notifications">
      <i class="bi bi-bell"></i>
      <span class="notif-dot"></span>
    </button>
    <div class="dropdown">
      <button class="avatar-btn" onclick="toggleAdminDropdown(this)">
        <div class="avatar"><?= $admin_initial ?></div>
        <div>
          <div class="avatar-name"><?= htmlspecialchars($admin_name) ?></div>
          <div class="avatar-role">Administrator</div>
        </div>
        <i class="bi bi-chevron-down" style="font-size:11px;color:var(--text-muted);margin-left:4px;"></i>
      </button>
      <div class="dropdown-menu" id="adminDropdown">
        <a href="#" class="dropdown-item" onclick="openAdminProfile();closeAdminDropdown();return false;">
          <i class="bi bi-person"></i> My Profile
        </a>
        <a href="#" class="dropdown-item" onclick="openAdminSettings();closeAdminDropdown();return false;">
          <i class="bi bi-gear"></i> Settings
        </a>
        <div class="dropdown-divider"></div>
        <a href="../logout.php" class="dropdown-item danger">
          <i class="bi bi-box-arrow-right"></i> Sign Out
        </a>
      </div>
    </div>
  </div>
</header>

<!-- ══ ADMIN PROFILE MODAL ══ -->
<div class="modal-overlay" id="adminProfileModal" onclick="if(event.target===this)closeAdminProfile()">
  <div class="modal-box">
    <div class="modal-header">
      <h4><i class="bi bi-person-circle me-2"></i>My Profile</h4>
      <button class="modal-close" onclick="closeAdminProfile()"><i class="bi bi-x"></i></button>
    </div>

    <div style="display:flex;align-items:center;gap:14px;margin-bottom:22px;padding:16px;background:var(--bg-page);border-radius:10px;">
      <div style="width:52px;height:52px;border-radius:50%;background:var(--red);color:#fff;font-size:22px;font-weight:700;display:flex;align-items:center;justify-content:center;" id="adminModalAvatar">
        <?= $admin_initial ?>
      </div>
      <div>
        <div style="font-size:14px;font-weight:600;color:var(--text-primary);" id="adminModalName"><?= htmlspecialchars($admin_name) ?></div>
        <div style="font-size:11px;color:var(--text-muted);">Administrator</div>
      </div>
    </div>

    <div style="display:grid;gap:14px;">
      <div class="form-group" style="margin:0;">
        <label>Full Name *</label>
        <input id="adminFullName" type="text" value="<?= htmlspecialchars($_admin_row['full_name'] ?? '') ?>" placeholder="Your full name">
      </div>
      <div class="form-group" style="margin:0;">
        <label>Email Address</label>
        <input type="email" value="<?= htmlspecialchars($_admin_row['email'] ?? '') ?>" disabled style="background:#f9fafb;cursor:not-allowed;color:var(--text-muted);">
        <div style="font-size:11px;color:var(--text-muted);margin-top:4px;"><i class="bi bi-info-circle"></i> Email cannot be changed here.</div>
      </div>
    </div>

    <div class="modal-actions">
      <button type="button" class="btn-save" onclick="saveAdminProfile()">
        <i class="bi bi-check2 me-1"></i>Save Changes
      </button>
      <button type="button" class="btn-cancel-modal" onclick="closeAdminProfile()">Cancel</button>
    </div>
  </div>
</div>

<!-- ══ ADMIN SETTINGS MODAL ══ -->
<div class="modal-overlay" id="adminSettingsModal" onclick="if(event.target===this)closeAdminSettings()">
  <div class="modal-box">
    <div class="modal-header">
      <h4><i class="bi bi-gear me-2"></i>Account Settings</h4>
      <button class="modal-close" onclick="closeAdminSettings()"><i class="bi bi-x"></i></button>
    </div>

    <div style="font-size:12px;color:var(--text-muted);margin-bottom:18px;">Change your password to keep your account secure.</div>

    <div style="display:grid;gap:14px;">
      <div class="form-group" style="margin:0;">
        <label>Current Password</label>
        <input id="adminCurrPass" type="password" placeholder="Enter current password">
      </div>
      <div class="form-group" style="margin:0;">
        <label>New Password</label>
        <input id="adminNewPass" type="password" placeholder="Min. 6 characters">
      </div>
      <div class="form-group" style="margin:0;">
        <label>Confirm New Password</label>
        <input id="adminConfirmPass" type="password" placeholder="Repeat new password">
      </div>
    </div>

    <div id="adminSettingsMsg" style="display:none;margin-top:12px;font-size:13px;padding:8px 12px;border-radius:8px;"></div>

    <div class="modal-actions">
      <button type="button" class="btn-save" onclick="saveAdminSettings()">
        <i class="bi bi-shield-lock me-1"></i>Update Password
      </button>
      <button type="button" class="btn-cancel-modal" onclick="closeAdminSettings()">Cancel</button>
    </div>
  </div>
</div>

<script>
function toggleAdminDropdown(btn) {
  const menu = document.getElementById('adminDropdown');
  menu.classList.toggle('open');
  document.addEventListener('click', function handler(e) {
    if (!btn.closest('.dropdown').contains(e.target)) {
      menu.classList.remove('open');
      document.removeEventListener('click', handler);
    }
  });
}
function closeAdminDropdown() {
  document.getElementById('adminDropdown').classList.remove('open');
}
function openAdminProfile() {
  document.getElementById('adminProfileModal').classList.add('open');
}
function closeAdminProfile() {
  document.getElementById('adminProfileModal').classList.remove('open');
}
function openAdminSettings() {
  document.getElementById('adminSettingsModal').classList.add('open');
}
function closeAdminSettings() {
  document.getElementById('adminSettingsModal').classList.remove('open');
  const msg = document.getElementById('adminSettingsMsg');
  msg.style.display = 'none';
  ['adminCurrPass','adminNewPass','adminConfirmPass'].forEach(id => {
    const el = document.getElementById(id);
    if (el) el.value = '';
  });
}

function saveAdminProfile() {
  const name = document.getElementById('adminFullName').value.trim();
  if (!name) { alert('Name is required.'); return; }
  const fd = new FormData();
  fd.append('action', 'update_profile');
  fd.append('full_name', name);
  fetch('actions/update_admin_profile.php', { method: 'POST', body: fd })
    .then(r => r.json())
    .then(d => {
      if (d.success) {
        document.getElementById('adminModalName').textContent = name;
        document.getElementById('adminModalAvatar').textContent = name.charAt(0).toUpperCase();
        closeAdminProfile();
        location.reload();
      } else {
        alert(d.message || 'Could not save profile.');
      }
    }).catch(() => alert('Server error.'));
}

function saveAdminSettings() {
  const curr    = document.getElementById('adminCurrPass').value;
  const newp    = document.getElementById('adminNewPass').value;
  const confirm = document.getElementById('adminConfirmPass').value;
  const msg     = document.getElementById('adminSettingsMsg');
  if (!curr || !newp || !confirm) {
    showAdminMsg('All fields are required.', false); return;
  }
  if (newp.length < 6) {
    showAdminMsg('New password must be at least 6 characters.', false); return;
  }
  if (newp !== confirm) {
    showAdminMsg('Passwords do not match.', false); return;
  }
  const fd = new FormData();
  fd.append('action', 'change_password');
  fd.append('current_password', curr);
  fd.append('new_password', newp);
  fetch('actions/update_admin_profile.php', { method: 'POST', body: fd })
    .then(r => r.json())
    .then(d => {
      showAdminMsg(d.message || (d.success ? 'Password updated!' : 'Error.'), d.success);
      if (d.success) {
        ['adminCurrPass','adminNewPass','adminConfirmPass'].forEach(id => {
          document.getElementById(id).value = '';
        });
      }
    }).catch(() => showAdminMsg('Server error.', false));
}

function showAdminMsg(text, ok) {
  const msg = document.getElementById('adminSettingsMsg');
  msg.textContent = text;
  msg.style.display = 'block';
  msg.style.background = ok ? '#dcfce7' : '#fee2e2';
  msg.style.color = ok ? '#16a34a' : '#b91c1c';
}
</script>
