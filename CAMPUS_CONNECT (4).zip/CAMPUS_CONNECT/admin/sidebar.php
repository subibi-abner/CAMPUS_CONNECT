<?php
// sidebar.php — Admin sidebar, matching student/officer dark theme
// Set $active_page = 'dashboard' | 'events' | 'announcements' | 'users' | 'departments'
if (!isset($active_page)) $active_page = '';
?>
<aside class="sidebar">
  <div class="sidebar-section-label">Main</div>

  <a href="dashboard.php" class="nav-link-item <?= $active_page === 'dashboard' ? 'active' : '' ?>">
    <i class="bi bi-grid-1x2"></i> Dashboard
  </a>

  <a href="analytics.php" class="nav-link-item <?= $active_page === 'analytics' ? 'active' : '' ?>">
    <i class="bi bi-bar-chart-line"></i> Analytics
  </a>

  <a href="event_management.php" class="nav-link-item <?= $active_page === 'events' ? 'active' : '' ?>">
    <i class="bi bi-calendar-event"></i> Events
  </a>

  <a href="announcements.php" class="nav-link-item <?= $active_page === 'announcements' ? 'active' : '' ?>">
    <i class="bi bi-megaphone"></i> Announcements
  </a>

  <div class="sidebar-section-label">Manage</div>

  <a href="user_management.php" class="nav-link-item <?= $active_page === 'users' ? 'active' : '' ?>">
    <i class="bi bi-people"></i> Users
  </a>

  <a href="departments.php" class="nav-link-item <?= $active_page === 'departments' ? 'active' : '' ?>">
    <i class="bi bi-building"></i> Departments
  </a>

  <div class="sidebar-footer">
    <button class="logout-btn" onclick="window.location.href='../logout.php'">
      <i class="bi bi-box-arrow-right" style="font-size:15px"></i> Sign Out
    </button>
  </div>
</aside>
