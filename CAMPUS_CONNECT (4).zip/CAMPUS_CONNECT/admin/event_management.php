<?php
require_once '../config.php';
require_once '../db_functions.php';
require_login('admin');

$active_page = 'events';
$success_msg = '';
$error_msg   = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $event_id = (int)($_POST['event_id'] ?? 0);
  $request_id = (int)($_POST['request_id'] ?? 0);
  $action   = $_POST['action'] ?? '';
  
  if ($event_id > 0) {
    if ($action === 'approve') {
      $pdo->prepare("UPDATE events SET status='approved', updated_at=NOW() WHERE id=?")->execute([$event_id]);
      $success_msg = 'Event approved successfully.';
    } elseif ($action === 'set_ongoing') {
      $pdo->prepare("UPDATE events SET status='ongoing', updated_at=NOW() WHERE id=?")->execute([$event_id]);
      $success_msg = 'Event marked as Ongoing.';
    } elseif ($action === 'set_completed') {
      $pdo->prepare("UPDATE events SET status='completed', updated_at=NOW() WHERE id=?")->execute([$event_id]);
      $success_msg = 'Event marked as Completed.';
    } elseif ($action === 'reject') {
      $pdo->prepare("UPDATE events SET status='rejected', updated_at=NOW() WHERE id=?")->execute([$event_id]);
      $success_msg = 'Event rejected.';
    } elseif ($action === 'delete') {
      $pdo->prepare("DELETE FROM events WHERE id=?")->execute([$event_id]);
      $success_msg = 'Event deleted.';
    } elseif ($action === 'approve_deletion') {
      // Approve deletion request
      $stmt = $pdo->prepare("SELECT id FROM deletion_requests WHERE event_id=? AND status='pending'");
      $stmt->execute([$event_id]);
      if ($request = $stmt->fetch()) {
        $pdo->prepare("UPDATE deletion_requests SET status='approved', resolved_at=NOW() WHERE id=?")->execute([$request['id']]);
        $pdo->prepare("DELETE FROM registrations WHERE event_id=?")->execute([$event_id]);
        $pdo->prepare("DELETE FROM events WHERE id=?")->execute([$event_id]);
        $success_msg = 'Deletion approved and event removed.';
      }
    }
  }
  
  if ($request_id > 0 && $action === 'reject_deletion') {
    $pdo->prepare("UPDATE deletion_requests SET status='rejected', resolved_at=NOW() WHERE id=?")->execute([$request_id]);
    $success_msg = 'Deletion request rejected.';
  }
}

$filter_status = $_GET['status'] ?? 'all';
$where = $filter_status !== 'all' ? "WHERE e.status = " . $pdo->quote($filter_status) : '';
$events = $pdo->query("SELECT e.*, u.full_name AS organizer_name FROM events e LEFT JOIN users u ON e.organizer_id = u.id $where ORDER BY e.created_at DESC")->fetchAll(PDO::FETCH_ASSOC);

$cnt_draft     = $pdo->query("SELECT COUNT(*) FROM events WHERE status='draft'")->fetchColumn();
$cnt_pending   = $pdo->query("SELECT COUNT(*) FROM events WHERE status='pending'")->fetchColumn();
$cnt_approved  = $pdo->query("SELECT COUNT(*) FROM events WHERE status='approved'")->fetchColumn();
$cnt_ongoing   = $pdo->query("SELECT COUNT(*) FROM events WHERE status='ongoing'")->fetchColumn();
$cnt_completed = $pdo->query("SELECT COUNT(*) FROM events WHERE status='completed'")->fetchColumn();
$cnt_rejected  = $pdo->query("SELECT COUNT(*) FROM events WHERE status='rejected'")->fetchColumn();
$pending_requests_count = $pdo->query("SELECT COUNT(*) FROM deletion_requests WHERE status='pending'")->fetchColumn();

$requests = $pdo->query("SELECT r.*, e.title, u.full_name FROM deletion_requests r JOIN events e ON r.event_id=e.id JOIN users u ON r.organizer_id=u.id WHERE r.status='pending' ORDER BY r.created_at DESC")->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Event Management – CampusConnect Admin</title>
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
<link rel="stylesheet" href="css/admin.css">
  <style>
    /* Admin-only dropdown filter styles - scoped */
    .status-filter-dropdown { position: relative; display: inline-block; margin-bottom: 18px; }
    .status-filter-dropdown .filter-select { 
      display: flex; align-items: center; gap: 8px; width: auto; min-width: 200px; 
      background: var(--bg-card); border: 1.5px solid var(--border); 
      color: var(--text-secondary); cursor: pointer; padding: 10px 14px; 
      border-radius: 8px; font-size: 13px; font-weight: 500; 
    }
    .status-filter-dropdown .filter-select:hover { border-color: var(--red); color: var(--text-primary); background: #fafbfc; }
    .status-filter-dropdown .dropdown-menu { 
      position: absolute; top: calc(100% + 4px); left: 0; right: 0; 
      background: var(--bg-card); border: 1px solid var(--border); 
      border-radius: 10px; box-shadow: 0 8px 32px rgba(0,0,0,0.12); 
      min-width: 220px; z-index: 500; padding: 4px 0; margin: 0;
    }
    .status-filter-dropdown .dropdown-item { 
      display: block; padding: 10px 16px; font-size: 13px; color: var(--text-secondary); 
      text-decoration: none; white-space: nowrap; 
    }
    .status-filter-dropdown .dropdown-item:hover { background: var(--bg-page); color: var(--text-primary); }
    .status-filter-dropdown .dropdown-item.active { background: var(--red-light); color: var(--red); font-weight: 500; }
    .status-filter-dropdown .bi-chevron-down { transition: transform 0.2s ease; margin-left: auto; }
    .status-filter-dropdown.open .bi-chevron-down { transform: rotate(180deg); }
  </style>
</head>

<body>

<?php include 'header.php'; ?>

<div class="layout">
<?php include 'sidebar.php'; ?>

<div class="main">
  <div class="page-header">
    <div>
      <div class="page-title">Event Management</div>
      <div class="page-sub">Review, approve, and manage all submitted events</div>
    </div>
  </div>

  <?php if ($success_msg): ?><div class="alert alert-success"><i class="bi bi-check-circle"></i> <?= htmlspecialchars($success_msg) ?></div><?php endif; ?>
  <?php if ($error_msg):   ?><div class="alert alert-error"><i class="bi bi-exclamation-circle"></i> <?= htmlspecialchars($error_msg) ?></div><?php endif; ?>

  <!-- Status Filter Dropdown -->
<div class="status-filter-dropdown dropdown">
    <button class="filter-select" onclick="toggleDropdown(this)" style="min-width: 180px;">
      <span id="filter-text"><?= ucfirst($filter_status) ?> (<?= count($events) ?>)</span>
      <i class="bi bi-chevron-down" style="margin-left: auto; transition: transform 0.2s;"></i>
    </button>
    <div class="dropdown-menu" id="status-dropdown">
      <a href="event_management.php" class="dropdown-item <?= $filter_status === 'all' ? 'active' : '' ?>">All (<?= $cnt_draft+$cnt_pending+$cnt_approved+$cnt_ongoing+$cnt_completed+$cnt_rejected ?>)</a>
      <a href="event_management.php?status=draft"     class="dropdown-item <?= $filter_status === 'draft'     ? 'active' : '' ?>">📝 Draft (<?= $cnt_draft ?>)</a>
      <a href="event_management.php?status=pending"   class="dropdown-item <?= $filter_status === 'pending'   ? 'active' : '' ?>">⏳ Pending (<?= $cnt_pending ?>)</a>
      <a href="event_management.php?status=approved"  class="dropdown-item <?= $filter_status === 'approved'  ? 'active' : '' ?>">✅ Approved (<?= $cnt_approved ?>)</a>
      <a href="event_management.php?status=ongoing"   class="dropdown-item <?= $filter_status === 'ongoing'   ? 'active' : '' ?>">🔴 Ongoing (<?= $cnt_ongoing ?>)</a>
      <a href="event_management.php?status=completed" class="dropdown-item <?= $filter_status === 'completed' ? 'active' : '' ?>">🏁 Completed (<?= $cnt_completed ?>)</a>
      <a href="event_management.php?status=rejected"  class="dropdown-item <?= $filter_status === 'rejected'  ? 'active' : '' ?>">❌ Rejected (<?= $cnt_rejected ?>)</a>
    </div>
  </div>

  <!-- Events Table -->
  <div class="card">
    <div class="card-header">
      <h4>Events <span style="font-weight:400;color:var(--text-muted);font-size:13px;">(<?= count($events) ?>)</span></h4>
    </div>
    <?php if (empty($events)): ?>
    <div class="empty-state">
      <i class="bi bi-calendar-x"></i>
      <p>No events found<?= $filter_status !== 'all' ? " with status '$filter_status'" : '' ?>.</p>
    </div>
    <?php else: ?>
    <table class="data-table">
      <thead>
        <tr><th>Event</th><th>Organizer</th><th>Category</th><th>Date</th><th>Status</th><th>Actions</th></tr>
      </thead>
      <tbody>
        <?php foreach ($events as $ev): ?>
        <tr>
          <td>
            <div style="font-weight:500;color:var(--text-primary);"><?= htmlspecialchars($ev['title']) ?></div>
            <?php if (!empty($ev['description'])): ?>
            <div style="font-size:11px;color:var(--text-muted);margin-top:2px;max-width:240px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;"><?= htmlspecialchars($ev['description']) ?></div>
            <?php endif; ?>
          </td>
          <td style="color:var(--text-secondary);"><?= htmlspecialchars($ev['organizer_name'] ?? 'N/A') ?></td>
          <td><span class="badge badge-blue"><?= htmlspecialchars($ev['category'] ?? 'General') ?></span></td>
          <td style="color:var(--text-muted);white-space:nowrap;font-size:12px;">
            <?= isset($ev['event_date']) ? date('M j, Y', strtotime($ev['event_date'])) : '—' ?>
          </td>
          <?php
            $st = $ev['status'] ?? 'pending';
            $badgeMap = [
              'draft'     => 'badge-draft',
              'pending'   => 'badge-pending',
              'approved'  => 'badge-approved',
              'ongoing'   => 'badge-ongoing',
              'completed' => 'badge-completed',
              'rejected'  => 'badge-rejected',
            ];
            $badgeCls = $badgeMap[$st] ?? 'badge-pending';
          ?>
          <td><span class="badge <?= $badgeCls ?>"><?= ucfirst($st) ?></span></td>
          <td>
            <div class="table-actions">
              <?php if ($st === 'pending'): ?>
              <form method="POST" style="display:inline;">
                <input type="hidden" name="event_id" value="<?= $ev['id'] ?>">
                <input type="hidden" name="action" value="approve">
                <button type="submit" class="action-btn approve" title="Approve"><i class="bi bi-check-lg"></i></button>
              </form>
              <form method="POST" style="display:inline;" onsubmit="return confirm('Reject this event?')">
                <input type="hidden" name="event_id" value="<?= $ev['id'] ?>">
                <input type="hidden" name="action" value="reject">
                <button type="submit" class="action-btn danger" title="Reject"><i class="bi bi-x-lg"></i></button>
              </form>
              <?php endif; ?>
              <?php if ($st === 'approved'): ?>
              <form method="POST" style="display:inline;" onsubmit="return confirm('Mark event as Ongoing?')">
                <input type="hidden" name="event_id" value="<?= $ev['id'] ?>">
                <input type="hidden" name="action" value="set_ongoing">
                <button type="submit" class="action-btn" title="Set Ongoing" style="background:#f59e0b;color:#fff;"><i class="bi bi-play-fill"></i></button>
              </form>
              <?php endif; ?>
              <?php if (in_array($st, ['approved','ongoing'])): ?>
              <form method="POST" style="display:inline;" onsubmit="return confirm('Mark event as Completed?')">
                <input type="hidden" name="event_id" value="<?= $ev['id'] ?>">
                <input type="hidden" name="action" value="set_completed">
                <button type="submit" class="action-btn" title="Set Completed" style="background:#6366f1;color:#fff;"><i class="bi bi-flag-fill"></i></button>
              </form>
              <?php endif; ?>
              <form method="POST" style="display:inline;" onsubmit="return confirm('Permanently delete this event?')">
                <input type="hidden" name="event_id" value="<?= $ev['id'] ?>">
                <input type="hidden" name="action" value="delete">
                <button type="submit" class="action-btn danger" title="Delete"><i class="bi bi-trash"></i></button>
              </form>
            </div>
          </td>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
    <?php endif; ?>
  </div>

  <!-- Deletion Requests Card -->
  <div class="card">
    <div class="card-header">
      <h4>Deletion Requests <span style="font-weight:400;color:var(--text-muted);font-size:13px;">(<?= $pending_requests_count ?>)</span></h4>
    </div>
    <?php if (empty($requests)): ?>
    <div class="empty-state">
      <i class="bi bi-inbox" style="opacity:.4;"></i>
      <p>No pending deletion requests</p>
    </div>
    <?php else: ?>
    <table class="data-table">
      <thead>
        <tr>
          <th>Event</th>
          <th>Organizer</th>
          <th>Reason</th>
          <th>Date</th>
          <th>Actions</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($requests as $r): ?>
        <tr>
          <td><strong><?= htmlspecialchars($r['title']) ?></strong></td>
          <td><?= htmlspecialchars($r['full_name']) ?></td>
          <td style="max-width:200px;"><?= htmlspecialchars(substr($r['reason'], 0, 100)) . (strlen($r['reason']) > 100 ? '...' : '') ?></td>
          <td><?= date('M j, H:i', strtotime($r['created_at'])) ?></td>
          <td>
            <div style="display:flex;gap:6px;">
              <form method="POST" style="display:inline;" onsubmit="return confirm('Approve deletion & notify students?')">
                <input type="hidden" name="event_id" value="<?= $r['event_id'] ?>">
                <input type="hidden" name="action" value="approve_deletion">
                <button type="submit" class="btn btn-sm btn-success">✓ Approve</button>
              </form>
              <form method="POST" style="display:inline;" onsubmit="return confirm('Reject request?')">
                <input type="hidden" name="request_id" value="<?= $r['id'] ?>">
                <input type="hidden" name="action" value="reject_deletion">
                <button type="submit" class="btn btn-sm btn-secondary">✗ Reject</button>
              </form>
            </div>
          </td>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
    <?php endif; ?>
  </div>

</div>
</div>

<script>
function toggleDropdown(btn) {
  const menu = btn.parentElement.querySelector('.dropdown-menu');
  menu.classList.toggle('open');
  const icon = btn.querySelector('i.bi-chevron-down');
  if (icon) icon.style.transform = menu.classList.contains('open') ? 'rotate(180deg)' : 'rotate(0deg)';
}

document.addEventListener('click', function(e) {
  if (!e.target.closest('.dropdown')) {
    document.querySelectorAll('.dropdown-menu.open').forEach(menu => {
      menu.classList.remove('open');
      const btn = menu.previousElementSibling;
      const icon = btn.querySelector('i.bi-chevron-down');
      if (icon) icon.style.transform = 'rotate(0deg)';
    });
  }
});
</script>
</body>
</html>


