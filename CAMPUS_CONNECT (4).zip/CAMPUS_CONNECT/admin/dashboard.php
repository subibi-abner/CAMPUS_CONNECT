<?php
require_once '../config.php';
require_once '../db_functions.php';
require_login('admin');

$active_page = 'dashboard';

$pending_events      = $pdo->query("SELECT COUNT(*) FROM events WHERE status = 'pending'")->fetchColumn();
$approved_events     = $pdo->query("SELECT COUNT(*) FROM events WHERE status = 'approved'")->fetchColumn();
$total_users         = $pdo->query("SELECT COUNT(*) FROM users")->fetchColumn();
$total_announcements = $pdo->query("SELECT COUNT(*) FROM announcements")->fetchColumn() ?: 0;
$total_departments   = $pdo->query("SELECT COUNT(*) FROM departments")->fetchColumn() ?: 0;

$pending_list = $pdo->query(
  "SELECT e.*, u.full_name AS organizer_name
   FROM events e LEFT JOIN users u ON e.organizer_id = u.id
   WHERE e.status = 'pending'
   ORDER BY e.created_at DESC LIMIT 6"
)->fetchAll(PDO::FETCH_ASSOC);

$recent_events = $pdo->query(
  "SELECT e.*, u.full_name AS organizer_name
   FROM events e LEFT JOIN users u ON e.organizer_id = u.id
   ORDER BY e.updated_at DESC LIMIT 6"
)->fetchAll(PDO::FETCH_ASSOC);

$recent_submissions = $pdo->query(
  "SELECT e.*, u.full_name AS organizer_name
   FROM events e LEFT JOIN users u ON e.organizer_id = u.id
   ORDER BY e.created_at DESC LIMIT 4"
)->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Dashboard – CampusConnect Admin</title>
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
  <link rel="stylesheet" href="css/admin.css">
</head>
<body>

<?php include 'header.php'; ?>

<div class="layout">
<?php include 'sidebar.php'; ?>

<div class="main">
  <div class="page-header">
    <div>
      <div class="page-title">Dashboard</div>
      <div class="page-sub">Welcome back, <?= htmlspecialchars($_SESSION['full_name'] ?? 'Administrator') ?></div>
    </div>
  </div>

  <!-- Stats -->
  <div class="stats-row">
    <div class="stat-card">
      <div class="stat-icon red"><i class="bi bi-hourglass-split"></i></div>
      <div>
        <div class="stat-value"><?= $pending_events ?></div>
        <div class="stat-label">Pending Approvals</div>
      </div>
    </div>
    <div class="stat-card">
      <div class="stat-icon green"><i class="bi bi-calendar-check"></i></div>
      <div>
        <div class="stat-value"><?= $approved_events ?></div>
        <div class="stat-label">Approved Events</div>
      </div>
    </div>
    <div class="stat-card">
      <div class="stat-icon blue"><i class="bi bi-people"></i></div>
      <div>
        <div class="stat-value"><?= number_format($total_users) ?></div>
        <div class="stat-label">Total Users</div>
      </div>
    </div>
    <div class="stat-card">
      <div class="stat-icon orange"><i class="bi bi-megaphone"></i></div>
      <div>
        <div class="stat-value"><?= $total_announcements ?></div>
        <div class="stat-label">Announcements</div>
      </div>
    </div>
    <div class="stat-card">
      <div class="stat-icon purple"><i class="bi bi-building"></i></div>
      <div>
        <div class="stat-value"><?= $total_departments ?></div>
        <div class="stat-label">Departments</div>
      </div>
    </div>
  </div>

  <div class="two-col">
    <!-- Left: Pending Events -->
    <div>
      <div class="card">
        <div class="card-header">
          <h4>Pending Approvals</h4>
          <a href="event_management.php" class="card-link">View all →</a>
        </div>
        <table class="data-table">
          <thead>
            <tr>
              <th>Event</th>
              <th>Organizer</th>
              <th>Category</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody>
            <?php if (empty($pending_list)): ?>
            <tr><td colspan="4" style="text-align:center;color:var(--text-muted);padding:28px;">No pending events</td></tr>
            <?php else: ?>
            <?php foreach ($pending_list as $ev): ?>
            <tr>
              <td style="font-weight:500;"><?= htmlspecialchars($ev['title']) ?></td>
              <td style="color:var(--text-secondary);"><?= htmlspecialchars($ev['organizer_name'] ?? 'N/A') ?></td>
              <td><span class="badge badge-academic"><?= htmlspecialchars($ev['category'] ?? 'General') ?></span></td>
              <td>
                <a href="event_management.php" class="action-btn" title="Review"><i class="bi bi-arrow-right-circle"></i></a>
              </td>
            </tr>
            <?php endforeach; ?>
            <?php endif; ?>
          </tbody>
        </table>
      </div>

      <!-- Recent Submissions -->
      <div class="card">
        <div class="card-header">
          <h4>Recent Submissions</h4>
        </div>
        <?php foreach ($recent_submissions as $ev): ?>
        <div class="sub-item">
          <div class="sub-icon"><i class="bi bi-calendar-event"></i></div>
          <div style="flex:1;">
            <div class="sub-name"><?= htmlspecialchars($ev['title']) ?></div>
            <div class="sub-org"><?= htmlspecialchars($ev['organizer_name'] ?? 'Unknown') ?> &bull; <?= isset($ev['created_at']) ? date('M j, Y', strtotime($ev['created_at'])) : 'N/A' ?></div>
          </div>
          <span class="badge badge-<?= $ev['status'] ?? 'pending' ?>"><?= ucfirst($ev['status'] ?? 'Pending') ?></span>
        </div>
        <?php endforeach; ?>
        <?php if (empty($recent_submissions)): ?>
        <div class="card-body"><p style="color:var(--text-muted);font-size:13px;">No submissions yet.</p></div>
        <?php endif; ?>
      </div>
    </div>

    <!-- Right: Activity -->
    <div class="right-col">
      <div class="card">
        <div class="card-header"><h4>Recent Activity</h4></div>
        <ul class="activity-list">
          <?php foreach ($recent_events as $ev): ?>
          <?php $status = $ev['status'] ?? 'pending'; ?>
          <li>
            <?php if ($status === 'approved'): ?>
              <div class="act-dot green"><i class="bi bi-check-lg"></i></div>
              <div class="act-text"><strong><?= htmlspecialchars($ev['title']) ?></strong> was approved<div class="act-time">Recently</div></div>
            <?php elseif ($status === 'rejected'): ?>
              <div class="act-dot red"><i class="bi bi-x-lg"></i></div>
              <div class="act-text"><strong><?= htmlspecialchars($ev['title']) ?></strong> was rejected<div class="act-time">Recently</div></div>
            <?php else: ?>
              <div class="act-dot yellow"><i class="bi bi-clock"></i></div>
              <div class="act-text"><strong><?= htmlspecialchars($ev['title']) ?></strong> submitted for review<div class="act-time">Recently</div></div>
            <?php endif; ?>
          </li>
          <?php endforeach; ?>
          <?php if (empty($recent_events)): ?>
          <li><div class="act-text" style="color:var(--text-muted);">No recent activity</div></li>
          <?php endif; ?>
        </ul>
      </div>
    </div>
  </div>

</div><!-- end .main -->
</div><!-- end .layout -->
</body>
</html>
