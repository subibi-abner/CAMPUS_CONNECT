<?php
require_once 'config.php';

// Already logged in? Send to dashboard
if (isset($_SESSION['user_id'])) {
  switch ($_SESSION['role']) {
    case 'admin':     header('Location: admin/dashboard.php');  exit;
    case 'organizer': header('Location: officer/dashboard.php'); exit;
    default:          header('Location: student/student.php');  exit;
  }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>CampusConnect - Sign Up</title>

  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"/>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet"/>
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet"/>

  <!-- Reuse the exact same login.css — no new styles needed -->
  <link rel="stylesheet" href="css/login.css"/>
</head>
<body>

  <!-- ── TOAST ── -->
  <div class="toast-container position-fixed top-0 end-0 p-3">
    <div id="appToast" class="toast align-items-center text-white border-0" role="alert">
      <div class="d-flex">
        <div class="toast-body d-flex align-items-center gap-2">
          <i class="bi bi-check-circle-fill"></i>
          <span id="toast-msg">Success!</span>
        </div>
        <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast"></button>
      </div>
    </div>
  </div>

  <!-- ── SAME CARD STRUCTURE AS login.php ── -->
  <div id="loginPage" class="main-card">
    <div class="row g-0">

      <!-- LEFT: FORMS -->
      <div class="col-12 col-md-6 panel-left">

        <!-- Logo -->
        <div class="d-flex align-items-center gap-2 mb-4">
          <div class="logo-circle">C</div>
          <span class="fw-semibold text-dark" style="font-size:14px;">CampusConnect</span>
        </div>

        <!-- ── LOGIN FORM (hidden by default on this page) ── -->
        <div id="loginForm" style="display:none;">
          <h5 class="fw-semibold text-dark mb-1" style="font-size:17px;">Welcome Back</h5>
          <p class="text-muted mb-4" style="font-size:12px;">Log in to your account</p>

          <div class="mb-3">
            <div class="input-icon-wrap">
              <i class="bi bi-envelope input-icon"></i>
              <input type="email" id="login-email" class="form-control" placeholder="Email Address" autocomplete="email"/>
            </div>
            <div class="invalid-feedback d-block" id="login-email-error"></div>
          </div>

          <div class="mb-3">
            <div class="input-icon-wrap">
              <i class="bi bi-lock input-icon"></i>
              <input type="password" id="login-password" class="form-control" placeholder="Password" style="padding-right:36px;" autocomplete="current-password"/>
              <button class="eye-toggle" onclick="togglePass('login-password','login-eye')">
                <i class="bi bi-eye" id="login-eye" style="font-size:14px;"></i>
              </button>
            </div>
            <div class="invalid-feedback d-block" id="login-pass-error"></div>
          </div>

          <div class="text-end mb-4">
            <a href="#" class="link-crimson" style="font-size:12px;">Forgot password?</a>
          </div>

          <button class="btn-signup d-flex align-items-center justify-content-center gap-2 mb-3"
                  id="loginBtn" onclick="handleLogin()">
            <span class="spinner-border spinner-border-sm btn-spinner" id="login-spinner"></span>
            <span id="login-btn-text">Log In</span>
          </button>

          <p class="text-center text-muted mb-0" style="font-size:12px;">
            Don't have an account?
            <span class="link-crimson" onclick="switchToSignUp()">Sign Up</span>
          </p>
        </div>

        <!-- ── SIGN UP FORM (shown by default on this page) ── -->
        <div id="signupForm">
          <h5 class="fw-semibold text-dark mb-1" style="font-size:17px;">Create your Account</h5>
          <p class="text-muted mb-4" style="font-size:12px;">Join the campus community today</p>

          <div class="mb-3">
            <div class="input-icon-wrap">
              <i class="bi bi-person input-icon"></i>
              <input type="text" id="reg-name" class="form-control" placeholder="Full Name" autocomplete="name"/>
            </div>
            <div class="invalid-feedback d-block" id="reg-name-error"></div>
          </div>

          <div class="mb-3">
            <div class="input-icon-wrap">
              <i class="bi bi-envelope input-icon"></i>
              <input type="email" id="reg-email" class="form-control" placeholder="Email Address" autocomplete="email"/>
            </div>
            <div class="invalid-feedback d-block" id="reg-email-error"></div>
          </div>

          <div class="mb-4">
            <div class="input-icon-wrap">
              <i class="bi bi-lock input-icon"></i>
              <input type="password" id="reg-password" class="form-control" placeholder="Password"
                     style="padding-right:36px;" autocomplete="new-password"/>
              <button class="eye-toggle" onclick="togglePass('reg-password','reg-eye')">
                <i class="bi bi-eye" id="reg-eye" style="font-size:14px;"></i>
              </button>
            </div>
            <div class="invalid-feedback d-block" id="reg-pass-error"></div>
          </div>

          <button class="btn-signup d-flex align-items-center justify-content-center gap-2 mb-3"
                  id="signupBtn" onclick="handleSignUp()">
            <span class="spinner-border spinner-border-sm btn-spinner" id="signup-spinner"></span>
            <span id="signup-btn-text">Sign Up</span>
          </button>

          <p class="text-center text-muted mb-0" style="font-size:12px;">
            Already have an account?
            <span class="link-crimson" onclick="switchToLogin()">Log In</span>
          </p>
        </div>

      </div>

      <!-- RIGHT: WELCOME PANEL -->
      <div class="col-12 col-md-6 panel-right">
        <div id="welcomeLogin" style="display:none;">
          <h2 class="fw-bold text-white mb-3" style="font-size:32px;">Welcome Back!</h2>
          <p class="text-white mb-4" style="font-size:13px; opacity:0.65; line-height:1.7; max-width:260px;">
            New to CampusConnect? Click Sign Up in the form to create an account and join the campus community.
          </p>
        </div>

        <div id="welcomeSignup">
          <h2 class="fw-bold text-white mb-3" style="font-size:32px;">Join Us!</h2>
          <p class="text-white mb-4" style="font-size:13px; opacity:0.65; line-height:1.7; max-width:260px;">
            Already have an account? Click Log In to access your account and continue exploring campus events.
          </p>
          <a href="index.html" style="font-size:12px; color:rgba(255,255,255,0.5); text-decoration:none;">
            ← Back to home
          </a>
        </div>
      </div>

    </div>
  </div>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

  <!-- Reuse the exact same login-script-db.js — all logic already there -->
  <script src="login-script-db.js"></script>

  <script>
    // After successful signup, redirect to login.php instead of staying on page
    const _originalHandleSignUp = handleSignUp;

    // Override the toast-then-switch behavior to redirect to login instead
    // We patch showToast to also trigger redirect after signup success
    const _origShowToast = showToast;
    let _signupSuccess = false;

    window.showToast = function(msg) {
      _origShowToast(msg);
      if (msg.toLowerCase().includes('account created')) {
        setTimeout(() => {
          window.location.href = 'login.php?registered=1';
        }, 1500);
      }
    };
  </script>

</body>
</html>
