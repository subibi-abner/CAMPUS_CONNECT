<?php
// sidebar.php — Staff portal sidebar
// Set $active_page = 'dashboard' | 'attendance'
if (!isset($active_page)) $active_page = 'dashboard';
?>
<aside class="sidebar">
  <div class="sidebar-section-label">Staff Menu</div>

  <a href="dashboard.php" class="nav-link-item <?= $active_page === 'dashboard' ? 'active' : '' ?>">
    <i class="bi bi-grid-1x2"></i> Dashboard
  </a>

  <a href="attendance.php" class="nav-link-item <?= $active_page === 'attendance' ? 'active' : '' ?>">
    <i class="bi bi-clipboard2-check"></i> Attendance
  </a>

  <div class="sidebar-footer">
    <button class="logout-btn" onclick="window.location.href='../logout.php'">
      <i class="bi bi-box-arrow-right" style="font-size:15px"></i> Sign Out
    </button>
  </div>
</aside>
