<?php
session_start();
require_once '../config.php';
require_once '../db_functions.php';
require_login('staff');

$staff_id    = $_SESSION['user_id'];
$active_page = 'attendance';
$page_title  = 'Attendance';

$event = get_staff_event($pdo, $staff_id);

if (!$event) {
  // No event assigned — show empty state
  $registered = [];
  $status = 'none';
} else {
  // Determine event status
  $now        = new DateTime();
  $event_date = new DateTime($event['event_date']);
  $event_end  = (clone $event_date)->modify('+6 hours');

  if ($now < $event_date)                             $status = 'upcoming';
  elseif ($now >= $event_date && $now <= $event_end)  $status = 'ongoing';
  else                                                 $status = 'ended';

  // Fetch all registered students with their attendance record
  $stmt = $pdo->prepare("
    SELECT u.id AS user_id, u.full_name, u.email,
           d.code AS dept_code,
           a.time_in, a.time_out, a.certificate_sent,
           at.token
    FROM registrations r
    JOIN users u ON r.user_id = u.id
    LEFT JOIN departments d ON u.department_id = d.id
    LEFT JOIN attendance a  ON a.event_id = r.event_id AND a.user_id = u.id
    LEFT JOIN attendance_tokens at ON at.event_id = r.event_id AND at.user_id = u.id
    WHERE r.event_id = ?
    ORDER BY u.full_name ASC
  ");
  $stmt->execute([$event['id']]);
  $registered = $stmt->fetchAll(PDO::FETCH_ASSOC);
}

// Quick stats
$total = count($registered);
$timed_in_count  = count(array_filter($registered, fn($r) => !empty($r['time_in'])));
$timed_out_count = count(array_filter($registered, fn($r) => !empty($r['time_out'])));
$absent_count    = $total - $timed_in_count;
?>
<?php include 'header.php'; ?>

<div class="layout">
<?php include 'sidebar.php'; ?>

<main class="main">

<?php if (!$event): ?>
  <div class="no-event-wrap">
    <i class="bi bi-calendar-x"></i>
    <h3>No Event Assigned</h3>
    <p>You have not been assigned to any event yet. Contact your organizer.</p>
  </div>

<?php else: ?>

  <div class="page-header">
    <div>
      <div class="page-title">Attendance</div>
      <div class="page-sub"><?= htmlspecialchars($event['title']) ?> &mdash; <?= (new DateTime($event['event_date']))->format('F d, Y · g:i A') ?></div>
    </div>
    <div style="display:flex;gap:10px;flex-wrap:wrap;">
      <?php if ($status === 'ongoing' || $status === 'ended'): ?>
      <button class="btn-outline" onclick="openQR()"><i class="bi bi-qr-code"></i> Show QR Code</button>
      <?php endif; ?>
      <?php if ($status === 'ended' || $status === 'ongoing'): ?>
      <button class="btn-primary" id="sendCertsBtn" onclick="sendCertificates()"><i class="bi bi-envelope-check"></i> Send Certificates</button>
      <?php endif; ?>
    </div>
  </div>

  <!-- STATUS BANNER -->
  <?php if ($status === 'upcoming'): ?>
  <div class="status-banner upcoming">
    <i class="bi bi-clock"></i>
    <div>
      <strong>Event has not started yet.</strong>
      Attendance tracking will be available on
      <strong><?= (new DateTime($event['event_date']))->format('F d, Y \a\t g:i A') ?></strong>.
      The list below shows registered students (read-only).
    </div>
  </div>
  <?php elseif ($status === 'ongoing'): ?>
  <div class="status-banner ongoing">
    <i class="bi bi-broadcast"></i>
    <div><strong>Event is ongoing.</strong> All attendance features are active. The table refreshes automatically every 10 seconds.</div>
  </div>
  <?php else: ?>
  <div class="status-banner ended">
    <i class="bi bi-check2-all"></i>
    <div><strong>Event has ended.</strong> You may still correct records manually and send certificates to attendees.</div>
  </div>
  <?php endif; ?>

  <!-- QUICK STATS -->
  <div class="stats-row" style="grid-template-columns:repeat(3,1fr);margin-bottom:16px;">
    <div class="stat-card">
      <div class="stat-icon blue"><i class="bi bi-people"></i></div>
      <div><div class="stat-value"><?= $total ?></div><div class="stat-label">Registered</div></div>
    </div>
    <div class="stat-card">
      <div class="stat-icon green"><i class="bi bi-check2-circle"></i></div>
      <div><div class="stat-value" id="statIn"><?= $timed_in_count ?></div><div class="stat-label">Timed In</div></div>
    </div>
    <div class="stat-card">
      <div class="stat-icon red"><i class="bi bi-x-circle"></i></div>
      <div><div class="stat-value" id="statAbsent"><?= $absent_count ?></div><div class="stat-label">Absent</div></div>
    </div>
  </div>

  <!-- ATTENDANCE TABLE -->
  <div class="card">
    <div class="toolbar">
      <div class="search-box">
        <i class="bi bi-search"></i>
        <input type="text" id="searchInput" placeholder="Search by name or department..." oninput="filterTable()">
      </div>
      <select class="filter-select" id="statusFilter" onchange="filterTable()">
        <option value="all">All Students</option>
        <option value="in">Timed In</option>
        <option value="absent">Absent</option>
        <option value="out">Timed Out</option>
      </select>
      <span style="font-size:12px;color:var(--text-muted);margin-left:auto;" id="rowCount"><?= $total ?> students</span>
    </div>

    <div style="overflow-x:auto;">
      <table class="data-table" id="attendanceTable">
        <thead>
          <tr>
            <th>#</th>
            <th>Student Name</th>
            <th>Dept</th>
            <th>Time In</th>
            <th>Time Out</th>
            <th>Status</th>
            <?php if ($status !== 'upcoming'): ?>
            <th>Actions</th>
            <?php endif; ?>
          </tr>
        </thead>
        <tbody id="attendanceBody">
          <?php if (empty($registered)): ?>
          <tr>
            <td colspan="7">
              <div class="empty-state"><i class="bi bi-people"></i><p>No students registered for this event yet.</p></div>
            </td>
          </tr>
          <?php else: ?>
          <?php foreach ($registered as $i => $r):
            $hasTin  = !empty($r['time_in']);
            $hasTout = !empty($r['time_out']);
            $rowStatus = $hasTin ? ($hasTout ? 'out' : 'in') : 'absent';
          ?>
          <tr data-status="<?= $rowStatus ?>" data-name="<?= strtolower(htmlspecialchars($r['full_name'])) ?>" data-dept="<?= strtolower($r['dept_code'] ?? '') ?>">
            <td style="color:var(--text-muted);font-size:12px;"><?= $i+1 ?></td>
            <td>
              <div style="font-weight:500;"><?= htmlspecialchars($r['full_name']) ?></div>
              <div style="font-size:11px;color:var(--text-muted);"><?= htmlspecialchars($r['email']) ?></div>
            </td>
            <td><?= htmlspecialchars($r['dept_code'] ?? '—') ?></td>
            <td class="cell-timein-<?= $r['user_id'] ?>">
              <?= $hasTin ? '<span style="font-size:12px;font-weight:500;color:#059669;">' . (new DateTime($r['time_in']))->format('g:i A') . '</span>' : '<span style="color:var(--text-muted);">—</span>' ?>
            </td>
            <td class="cell-timeout-<?= $r['user_id'] ?>">
              <?= $hasTout ? '<span style="font-size:12px;font-weight:500;color:#d97706;">' . (new DateTime($r['time_out']))->format('g:i A') . '</span>' : '<span style="color:var(--text-muted);">—</span>' ?>
            </td>
            <td class="cell-status-<?= $r['user_id'] ?>">
              <?php if ($hasTout): ?>
                <span class="badge badge-yellow"><i class="bi bi-door-closed" style="font-size:9px"></i> Out</span>
              <?php elseif ($hasTin): ?>
                <span class="badge badge-green"><i class="bi bi-check2" style="font-size:9px"></i> Present</span>
              <?php else: ?>
                <span class="badge badge-gray">Absent</span>
              <?php endif; ?>
            </td>
            <?php if ($status !== 'upcoming'): ?>
            <td>
              <div style="display:flex;gap:6px;flex-wrap:wrap;">
                <button class="btn-green btn-sm"
                  onclick="markTime(<?= $event['id'] ?>, <?= $r['user_id'] ?>, 'timein', this)"
                  <?= $hasTin ? 'disabled title="Already timed in"' : '' ?>>
                  <i class="bi bi-box-arrow-in-right"></i> In
                </button>
                <button class="btn-orange btn-sm"
                  onclick="markTime(<?= $event['id'] ?>, <?= $r['user_id'] ?>, 'timeout', this)"
                  <?= (!$hasTin || $hasTout) ? 'disabled title="Must time in first"' : '' ?>>
                  <i class="bi bi-box-arrow-right"></i> Out
                </button>
              </div>
            </td>
            <?php endif; ?>
          </tr>
          <?php endforeach; ?>
          <?php endif; ?>
        </tbody>
      </table>
    </div>
  </div>

<?php endif; ?>
</main>
</div>

<!-- QR FULLSCREEN OVERLAY -->
<?php if ($event && ($status === 'ongoing' || $status === 'ended')): ?>
<div class="qr-fullscreen" id="qrOverlay">
  <h2><?= htmlspecialchars($event['title']) ?></h2>
  <p>Students: scan this QR code with your phone to mark your attendance</p>
  <div class="qr-box">
    <!-- Uses Google Charts QR API — no library needed -->
    <img id="qrImage" src="" alt="QR Code" style="width:280px;height:280px;display:block;">
  </div>
  <p style="font-size:12px;">Each student uses their personal QR from <strong>My Events</strong> page on their phone.</p>
  <button class="qr-close-btn" onclick="closeQR()"><i class="bi bi-x-lg"></i> Close</button>
</div>
<?php endif; ?>

<!-- TOAST -->
<div id="toast" style="position:fixed;bottom:28px;right:28px;background:#1a0a0b;color:#fff;padding:12px 20px;border-radius:10px;font-size:13px;font-weight:500;display:none;align-items:center;gap:8px;z-index:9999;box-shadow:0 4px 20px rgba(0,0,0,0.3);"></div>

<script>
const EVENT_ID = <?= $event ? $event['id'] : 0 ?>;
const STATUS   = '<?= $status ?>';

/* ── FILTER ───────────────────────────────────────── */
function filterTable() {
  const q      = document.getElementById('searchInput').value.toLowerCase();
  const filter = document.getElementById('statusFilter').value;
  const rows   = document.querySelectorAll('#attendanceBody tr[data-status]');
  let visible  = 0;
  rows.forEach(row => {
    const name   = row.dataset.name  || '';
    const dept   = row.dataset.dept  || '';
    const status = row.dataset.status;
    const matchQ = name.includes(q) || dept.includes(q);
    const matchF = filter === 'all' || status === filter;
    row.style.display = (matchQ && matchF) ? '' : 'none';
    if (matchQ && matchF) visible++;
  });
  document.getElementById('rowCount').textContent = visible + ' students';
}

/* ── MARK TIME IN / OUT ───────────────────────────── */
function markTime(eventId, userId, action, btn) {
  btn.disabled = true;
  fetch('actions/' + (action === 'timein' ? 'mark_timein.php' : 'mark_timeout.php'), {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: `event_id=${eventId}&user_id=${userId}`
  })
  .then(r => r.json())
  .then(data => {
    if (data.success) {
      showToast('✅ ' + data.msg);
      refreshRow(userId, data);
    } else {
      showToast('❌ ' + (data.msg || 'Error'), true);
      btn.disabled = false;
    }
  })
  .catch(() => { showToast('❌ Network error', true); btn.disabled = false; });
}

function refreshRow(userId, data) {
  // Update time cells
  if (data.time_in) {
    document.querySelector('.cell-timein-' + userId).innerHTML =
      '<span style="font-size:12px;font-weight:500;color:#059669;">' + data.time_in + '</span>';
  }
  if (data.time_out) {
    document.querySelector('.cell-timeout-' + userId).innerHTML =
      '<span style="font-size:12px;font-weight:500;color:#d97706;">' + data.time_out + '</span>';
  }
  // Update status badge
  const sc = document.querySelector('.cell-status-' + userId);
  if (data.time_out) {
    sc.innerHTML = '<span class="badge badge-yellow"><i class="bi bi-door-closed" style="font-size:9px"></i> Out</span>';
    document.querySelector('[data-status]').dataset.status = 'out';
  } else if (data.time_in) {
    sc.innerHTML = '<span class="badge badge-green"><i class="bi bi-check2" style="font-size:9px"></i> Present</span>';
  }
  // Update stats
  refreshStats();
}

function refreshStats() {
  fetch('actions/get_attendance.php?event_id=' + EVENT_ID)
    .then(r => r.json())
    .then(data => {
      if (data.timed_in  !== undefined) document.getElementById('statIn').textContent     = data.timed_in;
      if (data.absent    !== undefined) document.getElementById('statAbsent').textContent = data.absent;
    });
}

/* ── SEND CERTIFICATES ────────────────────────────── */
function sendCertificates() {
  if (!confirm('Send certificates to all students who have timed in? This cannot be undone.')) return;
  const btn = document.getElementById('sendCertsBtn');
  btn.disabled = true;
  btn.innerHTML = '<i class="bi bi-hourglass-split"></i> Sending...';

  fetch('actions/send_certificates.php', {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: `event_id=${EVENT_ID}`
  })
  .then(r => r.json())
  .then(data => {
    if (data.success) {
      showToast('✅ ' + data.sent + ' certificate(s) sent!');
    } else {
      showToast('❌ ' + (data.msg || 'Failed to send'), true);
    }
    btn.disabled = false;
    btn.innerHTML = '<i class="bi bi-envelope-check"></i> Send Certificates';
  })
  .catch(() => {
    showToast('❌ Network error', true);
    btn.disabled = false;
    btn.innerHTML = '<i class="bi bi-envelope-check"></i> Send Certificates';
  });
}

/* ── QR OVERLAY ───────────────────────────────────── */
function openQR() {
  // Build the scan URL — points to the student's personal QR
  // The QR we display here is informational, pointing to the My Events page
  const scanBase = window.location.origin + '/CAMPUS_CONNECT/student/My events.php';
  const qrUrl = 'https://chart.googleapis.com/chart?chs=280x280&cht=qr&chl=' + encodeURIComponent(scanBase) + '&choe=UTF-8';
  document.getElementById('qrImage').src = qrUrl;
  document.getElementById('qrOverlay').classList.add('active');
}
function closeQR() {
  document.getElementById('qrOverlay').classList.remove('active');
}

/* ── TOAST ────────────────────────────────────────── */
function showToast(msg, isError = false) {
  const t = document.getElementById('toast');
  t.textContent = msg;
  t.style.background = isError ? '#991b1b' : '#1a0a0b';
  t.style.display = 'flex';
  setTimeout(() => t.style.display = 'none', 3500);
}

/* ── AUTO-REFRESH every 10s when ongoing ─────────── */
<?php if ($status === 'ongoing'): ?>
setInterval(() => {
  fetch('actions/get_attendance.php?event_id=' + EVENT_ID)
    .then(r => r.json())
    .then(data => {
      if (data.rows) {
        data.rows.forEach(row => {
          if (row.time_in) {
            const cellIn = document.querySelector('.cell-timein-' + row.user_id);
            if (cellIn && cellIn.querySelector('span')?.style.color !== 'rgb(5, 150, 105)') {
              cellIn.innerHTML = '<span style="font-size:12px;font-weight:500;color:#059669;">' + row.time_in + '</span>';
            }
          }
          if (row.time_out) {
            const cellOut = document.querySelector('.cell-timeout-' + row.user_id);
            if (cellOut) cellOut.innerHTML = '<span style="font-size:12px;font-weight:500;color:#d97706;">' + row.time_out + '</span>';
          }
        });
        if (data.timed_in  !== undefined) document.getElementById('statIn').textContent     = data.timed_in;
        if (data.absent    !== undefined) document.getElementById('statAbsent').textContent = data.absent;
      }
    });
}, 10000);
<?php endif; ?>
</script>
</body>
</html>
