<?php
/**
 * staff/header.php — Topbar for staff portal
 */
$staff_name    = $_SESSION['full_name'] ?? 'Staff';
$staff_initial = strtoupper(substr($staff_name, 0, 1));
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title><?= $page_title ?? 'Staff Portal' ?> – CampusConnect</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="css/staff.css">
</head>
<body>

<header class="topbar">
  <div class="topbar-left">
    <div class="logo-wrap">
      <div class="logo-circle">C</div>
      <div>
        <div class="logo-text">CampusConnect</div>
        <div class="logo-sub">Staff Portal</div>
      </div>
    </div>
  </div>
  <div class="topbar-right">
    <div class="avatar-btn">
      <div class="avatar"><?= $staff_initial ?></div>
      <div>
        <div class="avatar-name"><?= htmlspecialchars($staff_name) ?></div>
        <div class="avatar-role">Staff</div>
      </div>
    </div>
  </div>
</header>
