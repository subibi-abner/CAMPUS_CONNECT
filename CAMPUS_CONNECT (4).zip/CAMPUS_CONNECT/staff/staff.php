<?php
session_start();
require_once '../config.php';
require_once '../db_functions.php';
require_login('staff');
header('Location: /CAMPUS_CONNECT/staff/dashboard.php');
exit;
