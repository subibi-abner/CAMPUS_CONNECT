<?php
session_start();
require_once '../../../config.php';
require_once '../../../db_functions.php';
header('Content-Type: application/json');
require_login('staff');

$staff_id = $_SESSION['user_id'];
$event    = get_staff_event($pdo, $staff_id);

if (!$event) {
  echo json_encode(['success' => false, 'msg' => 'No event assigned to you.']); exit;
}

// Check event has started
$event_date = new DateTime($event['event_date']);
if (new DateTime() < $event_date) {
  echo json_encode(['success' => false, 'msg' => 'Event has not started yet.']); exit;
}

// Fetch attendees who haven't received cert yet
$stmt = $pdo->prepare("
  SELECT a.user_id, u.full_name, u.email
  FROM attendance a
  JOIN users u ON a.user_id = u.id
  WHERE a.event_id = ?
    AND a.time_in IS NOT NULL
    AND a.certificate_sent = 0
");
$stmt->execute([$event['id']]);
$attendees = $stmt->fetchAll(PDO::FETCH_ASSOC);

if (empty($attendees)) {
  echo json_encode(['success' => true, 'sent' => 0, 'msg' => 'No new attendees to send certificates to.']); exit;
}

$event_dt  = (new DateTime($event['event_date']))->format('F d, Y');
$sent      = 0;
$failed    = 0;

foreach ($attendees as $att) {
  $to      = $att['email'];
  $name    = $att['full_name'];
  $subject = "Certificate of Attendance — " . $event['title'];

  $message = wordwrap(
    "Dear {$name},\r\n\r\n" .
    "Congratulations! This email confirms that you successfully attended:\r\n\r\n" .
    "  Event    : {$event['title']}\r\n" .
    "  Date     : {$event_dt}\r\n" .
    "  Location : " . ($event['location'] ?? 'WMSU Campus') . "\r\n\r\n" .
    "Thank you for your participation! We hope to see you in future events.\r\n\r\n" .
    "— CampusConnect\r\n" .
    "   Western Mindanao State University",
    70
  );

  $headers  = "From: no-reply@wmsu.edu.ph\r\n";
  $headers .= "Reply-To: no-reply@wmsu.edu.ph\r\n";
  $headers .= "Content-Type: text/plain; charset=utf-8\r\n";
  $headers .= "X-Mailer: CampusConnect\r\n";

  if (@mail($to, $subject, $message, $headers)) {
    $pdo->prepare("
      UPDATE attendance SET certificate_sent = 1, sent_at = NOW()
      WHERE event_id = ? AND user_id = ?
    ")->execute([$event['id'], $att['user_id']]);
    $sent++;
  } else {
    $failed++;
  }
}

echo json_encode([
  'success' => true,
  'sent'    => $sent,
  'failed'  => $failed,
  'msg'     => "$sent certificate(s) sent" . ($failed ? ", $failed failed" : '') . '.',
]);
