<?php
/**
 * scan_qr.php
 * Students land here after scanning their personal QR code.
 * No login required — the token itself is the credential.
 *
 * URL format: /CAMPUS_CONNECT/staff/actions/scan_qr.php?token=abc123...
 */
require_once '../../../config.php';

$token = trim($_GET['token'] ?? '');

function render($title, $icon, $color, $msg, $sub = '') {
  echo "<!DOCTYPE html><html lang='en'><head>
  <meta charset='UTF-8'><meta name='viewport' content='width=device-width,initial-scale=1'>
  <title>$title – CampusConnect</title>
  <link href='https://fonts.googleapis.com/css2?family=Poppins:wght@400;600;700&display=swap' rel='stylesheet'>
  <style>
    *{box-sizing:border-box;margin:0;padding:0;font-family:'Poppins',sans-serif}
    body{background:#f4f6fb;display:flex;align-items:center;justify-content:center;min-height:100vh;padding:20px}
    .card{background:#fff;border-radius:20px;padding:40px 32px;text-align:center;max-width:400px;width:100%;box-shadow:0 4px 24px rgba(0,0,0,0.08)}
    .icon{font-size:60px;margin-bottom:16px}
    h2{font-size:22px;font-weight:700;color:#111827;margin-bottom:8px}
    p{font-size:14px;color:#6b7280;line-height:1.6}
    .sub{margin-top:12px;font-size:13px;color:#9ca3af}
    .brand{margin-top:28px;font-size:12px;color:#d1d5db}
  </style>
  </head><body><div class='card'>
  <div class='icon'>$icon</div>
  <h2>$title</h2>
  <p>$msg</p>" . ($sub ? "<p class='sub'>$sub</p>" : "") . "
  <p class='brand'>CampusConnect · WMSU</p>
  </div></body></html>";
}

if (!$token) {
  render('Invalid QR', '❌', 'red', 'This QR code is not valid.', 'Please use your personal QR code from the My Events page.');
  exit;
}

// Look up token
$stmt = $pdo->prepare("
  SELECT at.*, e.event_date, e.title, e.location, u.full_name, u.id AS uid, e.id AS eid
  FROM attendance_tokens at
  JOIN events e ON at.event_id = e.id
  JOIN users  u ON at.user_id  = u.id
  WHERE at.token = ?
");
$stmt->execute([$token]);
$record = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$record) {
  render('Not Recognized', '❓', 'red', 'This QR code was not found in our system.', 'Try refreshing your QR from the My Events page.');
  exit;
}

// Check if already used
if ($record['used']) {
  render(
    'Already Checked In',
    '✅',
    'green',
    'You have already been checked in for: <strong>' . htmlspecialchars($record['title']) . '</strong>',
    'If you believe this is an error, see the event staff.'
  );
  exit;
}

// Check event has started
$event_date = new DateTime($record['event_date']);
$now        = new DateTime();
if ($now < $event_date) {
  render(
    'Too Early',
    '⏰',
    'yellow',
    'This event has not started yet.',
    'Come back on ' . $event_date->format('F d, Y \a\t g:i A')
  );
  exit;
}

// Mark attendance
$stmt = $pdo->prepare("
  INSERT INTO attendance (event_id, user_id, time_in)
  VALUES (?, ?, NOW())
  ON DUPLICATE KEY UPDATE time_in = COALESCE(time_in, NOW())
");
$stmt->execute([$record['eid'], $record['uid']]);

// Mark token as used
$pdo->prepare("UPDATE attendance_tokens SET used = 1 WHERE token = ?")->execute([$token]);

// Success
render(
  'Attendance Confirmed!',
  '🎉',
  'green',
  'Welcome, <strong>' . htmlspecialchars($record['full_name']) . '</strong>!<br><br>
   You have been checked in to:<br><strong>' . htmlspecialchars($record['title']) . '</strong>',
  '📍 ' . htmlspecialchars($record['location'] ?? '') . ' &nbsp;·&nbsp; ⏰ ' . $now->format('g:i A')
);
