<?php
session_start();
require_once '../../../config.php';
require_once '../../../db_functions.php';
header('Content-Type: application/json');
require_login('staff');

$staff_id = $_SESSION['user_id'];
$event_id = (int)($_POST['event_id'] ?? 0);
$user_id  = (int)($_POST['user_id']  ?? 0);

if (!$event_id || !$user_id) {
  echo json_encode(['success' => false, 'msg' => 'Missing parameters']); exit;
}

// Verify assignment
$stmt = $pdo->prepare("SELECT 1 FROM event_staff WHERE event_id = ? AND staff_id = ?");
$stmt->execute([$event_id, $staff_id]);
if (!$stmt->fetch()) {
  echo json_encode(['success' => false, 'msg' => 'Unauthorized']); exit;
}

// Must have timed in first
$stmt = $pdo->prepare("SELECT time_in, time_out FROM attendance WHERE event_id = ? AND user_id = ?");
$stmt->execute([$event_id, $user_id]);
$row = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$row || !$row['time_in']) {
  echo json_encode(['success' => false, 'msg' => 'Student has not timed in yet']); exit;
}
if ($row['time_out']) {
  echo json_encode(['success' => false, 'msg' => 'Student has already timed out']); exit;
}

// Set time_out
$stmt = $pdo->prepare("UPDATE attendance SET time_out = NOW(), marked_by = ? WHERE event_id = ? AND user_id = ?");
$stmt->execute([$staff_id, $event_id, $user_id]);

// Fetch saved time_out
$stmt = $pdo->prepare("SELECT time_out FROM attendance WHERE event_id = ? AND user_id = ?");
$stmt->execute([$event_id, $user_id]);
$row = $stmt->fetch(PDO::FETCH_ASSOC);

$formatted = $row && $row['time_out'] ? (new DateTime($row['time_out']))->format('g:i A') : null;

echo json_encode(['success' => true, 'msg' => 'Timed out successfully', 'time_out' => $formatted]);
