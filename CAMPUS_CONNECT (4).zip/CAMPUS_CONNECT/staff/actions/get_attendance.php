<?php
session_start();
require_once '../../../config.php';
require_once '../../../db_functions.php';
header('Content-Type: application/json');
require_login('staff');

$staff_id = $_SESSION['user_id'];
$event_id = (int)($_GET['event_id'] ?? 0);

if (!$event_id) {
  echo json_encode(['success' => false, 'msg' => 'Missing event_id']); exit;
}

// Verify assignment
$stmt = $pdo->prepare("SELECT 1 FROM event_staff WHERE event_id = ? AND staff_id = ?");
$stmt->execute([$event_id, $staff_id]);
if (!$stmt->fetch()) {
  echo json_encode(['success' => false, 'msg' => 'Unauthorized']); exit;
}

// Fetch live attendance
$stmt = $pdo->prepare("
  SELECT u.id AS user_id,
         a.time_in, a.time_out
  FROM registrations r
  JOIN users u ON r.user_id = u.id
  LEFT JOIN attendance a ON a.event_id = r.event_id AND a.user_id = u.id
  WHERE r.event_id = ?
");
$stmt->execute([$event_id]);
$rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

$timed_in = 0; $total = count($rows);
$formatted = [];
foreach ($rows as $row) {
  $tin  = $row['time_in']  ? (new DateTime($row['time_in']))->format('g:i A')  : null;
  $tout = $row['time_out'] ? (new DateTime($row['time_out']))->format('g:i A') : null;
  if ($tin) $timed_in++;
  $formatted[] = [
    'user_id'  => $row['user_id'],
    'time_in'  => $tin,
    'time_out' => $tout,
  ];
}

echo json_encode([
  'success'  => true,
  'rows'     => $formatted,
  'timed_in' => $timed_in,
  'absent'   => $total - $timed_in,
  'total'    => $total,
]);
