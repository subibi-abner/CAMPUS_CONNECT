<?php
session_start();
require_once '../../../config.php';
require_once '../../../db_functions.php';
header('Content-Type: application/json');
require_login('staff');

$staff_id = $_SESSION['user_id'];
$event_id = (int)($_POST['event_id'] ?? 0);
$user_id  = (int)($_POST['user_id']  ?? 0);

if (!$event_id || !$user_id) {
  echo json_encode(['success' => false, 'msg' => 'Missing parameters']); exit;
}

// Verify this event is assigned to this staff
$stmt = $pdo->prepare("SELECT 1 FROM event_staff WHERE event_id = ? AND staff_id = ?");
$stmt->execute([$event_id, $staff_id]);
if (!$stmt->fetch()) {
  echo json_encode(['success' => false, 'msg' => 'Unauthorized']); exit;
}

// Verify student is registered for this event
$stmt = $pdo->prepare("SELECT 1 FROM registrations WHERE event_id = ? AND user_id = ?");
$stmt->execute([$event_id, $user_id]);
if (!$stmt->fetch()) {
  echo json_encode(['success' => false, 'msg' => 'Student not registered for this event']); exit;
}

// Insert or update — only set time_in if not already set
$stmt = $pdo->prepare("
  INSERT INTO attendance (event_id, user_id, time_in, marked_by)
  VALUES (?, ?, NOW(), ?)
  ON DUPLICATE KEY UPDATE
    time_in  = COALESCE(time_in, NOW()),
    marked_by = COALESCE(marked_by, VALUES(marked_by))
");
$stmt->execute([$event_id, $user_id, $staff_id]);

// Fetch the saved time_in to return to client
$stmt = $pdo->prepare("SELECT time_in FROM attendance WHERE event_id = ? AND user_id = ?");
$stmt->execute([$event_id, $user_id]);
$row = $stmt->fetch(PDO::FETCH_ASSOC);

$formatted = $row && $row['time_in'] ? (new DateTime($row['time_in']))->format('g:i A') : null;

echo json_encode(['success' => true, 'msg' => 'Timed in successfully', 'time_in' => $formatted]);
