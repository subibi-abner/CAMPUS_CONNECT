<?php
session_start();
require_once '../config.php';
require_once '../db_functions.php';
require_login('staff');

$staff_id    = $_SESSION['user_id'];
$active_page = 'dashboard';
$page_title  = 'Dashboard';

$event = get_staff_event($pdo, $staff_id);

// Attendance stats
$total_registered = 0; $timed_in = 0; $timed_out = 0; $certs_sent = 0;
if ($event) {
  $s = $pdo->prepare("SELECT COUNT(*) FROM registrations WHERE event_id=?");
  $s->execute([$event['id']]); $total_registered = (int)$s->fetchColumn();

  $s = $pdo->prepare("SELECT COUNT(*) FROM attendance WHERE event_id=? AND time_in IS NOT NULL");
  $s->execute([$event['id']]); $timed_in = (int)$s->fetchColumn();

  $s = $pdo->prepare("SELECT COUNT(*) FROM attendance WHERE event_id=? AND time_out IS NOT NULL");
  $s->execute([$event['id']]); $timed_out = (int)$s->fetchColumn();

  $s = $pdo->prepare("SELECT COUNT(*) FROM attendance WHERE event_id=? AND certificate_sent=1");
  $s->execute([$event['id']]); $certs_sent = (int)$s->fetchColumn();
}

// Event status
$status = 'upcoming';
if ($event) {
  $now        = new DateTime();
  $event_date = new DateTime($event['event_date']);
  $event_end  = (clone $event_date)->modify('+6 hours');
  if ($now >= $event_date && $now <= $event_end) $status = 'ongoing';
  elseif ($now > $event_end) $status = 'ended';
}
?>
<?php include 'header.php'; ?>

<div class="layout">
<?php include 'sidebar.php'; ?>

<main class="main">
  <div class="page-header">
    <div>
      <div class="page-title">Staff Dashboard</div>
      <div class="page-sub">Welcome back, <?= htmlspecialchars($_SESSION['full_name'] ?? 'Staff') ?></div>
    </div>
    <?php if ($event): ?>
    <a href="attendance.php" class="btn-primary"><i class="bi bi-clipboard2-check"></i> Manage Attendance</a>
    <?php endif; ?>
  </div>

  <?php if (!$event): ?>
  <div class="no-event-wrap">
    <i class="bi bi-calendar-x"></i>
    <h3>No Event Assigned Yet</h3>
    <p>An organizer has not yet assigned you to an event. Please wait or contact your organizer.</p>
  </div>

  <?php else: ?>

  <!-- Event Info Box -->
  <div class="event-info-box">
    <h2><?= htmlspecialchars($event['title']) ?></h2>
    <div class="event-meta">
      <div class="event-meta-item"><i class="bi bi-calendar-event"></i><?= (new DateTime($event['event_date']))->format('F d, Y · g:i A') ?></div>
      <div class="event-meta-item"><i class="bi bi-geo-alt"></i><?= htmlspecialchars($event['location'] ?? 'TBA') ?></div>
      <div class="event-meta-item"><i class="bi bi-person-check"></i>Assigned by: <?= htmlspecialchars($event['assigned_by_name']) ?></div>
      <?php
        $statusLabels = ['upcoming'=>'Upcoming','ongoing'=>'Ongoing','ended'=>'Ended'];
        $statusColors = ['upcoming'=>'badge-yellow','ongoing'=>'badge-green','ended'=>'badge-gray'];
      ?>
      <span class="badge <?= $statusColors[$status] ?>"><i class="bi bi-circle-fill" style="font-size:7px"></i><?= $statusLabels[$status] ?></span>
    </div>
  </div>

  <!-- Stat Cards -->
  <div class="stats-row">
    <div class="stat-card">
      <div class="stat-icon blue"><i class="bi bi-people"></i></div>
      <div><div class="stat-value"><?= $total_registered ?></div><div class="stat-label">Registered</div></div>
    </div>
    <div class="stat-card">
      <div class="stat-icon green"><i class="bi bi-check2-circle"></i></div>
      <div><div class="stat-value"><?= $timed_in ?></div><div class="stat-label">Timed In</div></div>
    </div>
    <div class="stat-card">
      <div class="stat-icon yellow"><i class="bi bi-door-closed"></i></div>
      <div><div class="stat-value"><?= $timed_out ?></div><div class="stat-label">Timed Out</div></div>
    </div>
    <div class="stat-card">
      <div class="stat-icon red"><i class="bi bi-envelope-check"></i></div>
      <div><div class="stat-value"><?= $certs_sent ?></div><div class="stat-label">Certs Sent</div></div>
    </div>
  </div>

  <!-- Attendance Progress -->
  <div class="card">
    <div class="card-header"><h4>Attendance Progress</h4><a href="attendance.php" class="card-link">View Full List →</a></div>
    <div class="card-body">
      <div class="attendance-progress">
        <span style="font-size:13px;color:var(--text-muted);min-width:80px"><?= $timed_in ?> / <?= $total_registered ?> in</span>
        <div class="progress-bar-wrap">
          <div class="progress-bar" style="width:<?= $total_registered > 0 ? round($timed_in/$total_registered*100) : 0 ?>%"></div>
        </div>
        <span class="progress-text"><?= $total_registered > 0 ? round($timed_in/$total_registered*100) : 0 ?>%</span>
      </div>
      <?php if ($status === 'upcoming'): ?>
      <p style="font-size:12px;color:var(--text-muted);margin-top:12px;"><i class="bi bi-info-circle"></i> Attendance tracking activates on <?= (new DateTime($event['event_date']))->format('F d, Y \a\t g:i A') ?>.</p>
      <?php elseif ($status === 'ended'): ?>
      <p style="font-size:12px;color:var(--text-muted);margin-top:12px;"><i class="bi bi-check-circle"></i> Event has ended. You may still send certificates to attendees.</p>
      <?php endif; ?>
    </div>
  </div>

  <!-- Event Description -->
  <?php if (!empty($event['description'])): ?>
  <div class="card">
    <div class="card-header"><h4>About This Event</h4></div>
    <div class="card-body" style="font-size:13.5px;color:var(--text-secondary);line-height:1.7;">
      <?= nl2br(htmlspecialchars($event['description'])) ?>
    </div>
  </div>
  <?php endif; ?>

  <?php endif; ?>
</main>
</div>
</body>
</html>
