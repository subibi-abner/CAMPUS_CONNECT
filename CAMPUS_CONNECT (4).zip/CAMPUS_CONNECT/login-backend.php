<?php
header('Content-Type: application/json');
require_once 'config.php';
require_once 'db_functions.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $action = $_POST['action'] ?? '';

  if ($action === 'login') {
    $email = trim($_POST['email']);
    $password = $_POST['password'];

    $user = authenticate($pdo, $email, $password);
    if ($user) {
      echo json_encode(['success' => true, 'redirect' => match($user['role']) {
        'admin'     => 'admin/admin.php',
        'organizer' => 'officer/officer.php',
        'staff'     => 'staff/staff.php',
        default     => 'student/student.php',
      }]);
    } else {
      echo json_encode(['success' => false, 'message' => 'Invalid credentials']);
    }
  } elseif ($action === 'signup') {
    $name = trim($_POST['name']);
    $email = trim($_POST['email']);
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);

    try {
      $stmt = $pdo->prepare("INSERT INTO users (full_name, email, password, role) VALUES (?, ?, ?, 'student')");
      $stmt->execute([$name, $email, $password]);
      echo json_encode(['success' => true]);
    } catch (PDOException $e) {
      echo json_encode(['success' => false, 'message' => 'Email already exists']);
    }
  }
}
?>

