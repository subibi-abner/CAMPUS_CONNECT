<?php
include 'db.php';

$result = $conn->query("SELECT title, event_date FROM events");

$events = [];

while($row=$result->fetch_assoc()){
  $events[] = [
    "title"=>$row['title'],
    "date"=>$row['event_date']
  ];
}

echo json_encode($events);