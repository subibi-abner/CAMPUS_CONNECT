// Full login functionality from original script.js
const USERS = [
  { email: 'student@example.com', password: 'student123', role: 'student', name: 'Student', department: 'Computer Science' },
  { email: 'officer@example.com', password: 'officer123', role: 'officer', name: 'Officer' },
  { email: 'admin@example.com', password: 'admin123', role: 'admin', name: 'Administrator' },
];

let currentUser = null;

function switchToSignUp() {
  document.getElementById('loginForm').style.display = 'none';
  document.getElementById('signupForm').style.display = 'block';
  document.getElementById('welcomeLogin').style.display = 'none';
  document.getElementById('welcomeSignup').style.display = 'block';
  clearLoginErrors();
}

function switchToLogin() {
  document.getElementById('loginForm').style.display = 'block';
  document.getElementById('signupForm').style.display = 'none';
  document.getElementById('welcomeLogin').style.display = 'block';
  document.getElementById('welcomeSignup').style.display = 'none';
  clearSignupErrors();
}

function togglePass(inputId, iconId) {
  const inp = document.getElementById(inputId);
  const icon = document.getElementById(iconId);
  const show = inp.type === 'password';
  inp.type = show ? 'text' : 'password';
  icon.className = show ? 'bi bi-eye-slash' : 'bi bi-eye';
  icon.style.fontSize = '14px';
}

function isValidEmail(v) { 
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v); 
}

function showErr(inputId, errId, msg) {
  document.getElementById(inputId).classList.add('is-invalid');
  const el = document.getElementById(errId);
  el.textContent = msg;
  el.style.display = 'block';
}

function clearErr(inputId, errId) {
  document.getElementById(inputId).classList.remove('is-invalid');
  const el = document.getElementById(errId);
  el.textContent = '';
  el.style.display = 'none';
}

function clearLoginErrors() {
  clearErr('login-email', 'login-email-error');
  clearErr('login-password', 'login-pass-error');
}

function clearSignupErrors() {
  clearErr('reg-name', 'reg-name-error');
  clearErr('reg-email', 'reg-email-error');
  clearErr('reg-password', 'reg-pass-error');
}

function handleSignUp() {
  clearSignupErrors();
  const name = document.getElementById('reg-name').value.trim();
  const email = document.getElementById('reg-email').value.trim();
  const pass = document.getElementById('reg-password').value;
  let valid = true;

  if (!name) { showErr('reg-name', 'reg-name-error', 'Full name required'); valid = false; }
  if (!isValidEmail(email)) { showErr('reg-email', 'reg-email-error', 'Valid email required'); valid = false; }
  if (pass.length < 6) { showErr('reg-password', 'reg-pass-error', 'Password min 6 chars'); valid = false; }
  if (!valid) return;

  setLoading('signupBtn', 'signup-spinner', 'signup-btn-text', 'Creating...');
  setTimeout(() => {
    resetLoading('signupBtn', 'signup-spinner', 'signup-btn-text', 'Sign Up');
    document.getElementById('reg-name').value = '';
    document.getElementById('reg-email').value = '';
    document.getElementById('reg-password').value = '';
    showToast('Account created! Please log in.');
    switchToLogin();
  }, 1500);
}

function handleLogin() {
  clearLoginErrors();
  const email = document.getElementById('login-email').value.trim();
  const pass = document.getElementById('login-password').value;
  let valid = true;

  if (!isValidEmail(email)) { showErr('login-email', 'login-email-error', 'Valid email required'); valid = false; }
  if (!pass) { showErr('login-password', 'login-pass-error', 'Password required'); valid = false; }
  if (!valid) return;

  const match = USERS.find(u => u.email === email && u.password === pass);
  if (!match) {
    showErr('login-email', 'login-email-error', 'Invalid credentials');
    showErr('login-password', 'login-pass-error', 'Check email/password');
    return;
  }

  setLoading('loginBtn', 'login-spinner', 'login-btn-text', 'Logging in...');
  setTimeout(() => {
    resetLoading('loginBtn', 'login-spinner', 'login-btn-text', 'Log In');
    showToast('Welcome, ' + match.name + '!');
    
    // PHP page redirects
    if (match.role === 'student') window.location.href = 'student.php';
    else if (match.role === 'officer') window.location.href = 'officer.php';
    else if (match.role === 'admin') window.location.href = 'admin.php';
  }, 1500);
}

function setLoading(btnId, spinnerId, textId, msg) {
  const btn = document.getElementById(btnId);
  btn.disabled = true;
  document.getElementById(spinnerId).style.display = 'inline-block';
  document.getElementById(textId).textContent = msg;
}

function resetLoading(btnId, spinnerId, textId, msg) {
  const btn = document.getElementById(btnId);
  btn.disabled = false;
  document.getElementById(spinnerId).style.display = 'none';
  document.getElementById(textId).textContent = msg;
}

function showToast(msg) {
  document.getElementById('toast-msg').textContent = msg;
  const toast = new bootstrap.Toast(document.getElementById('appToast'));
  toast.show();
}

// Enter key handling
document.addEventListener('keydown', e => {
  if (e.key === 'Enter') {
    const loginForm = document.getElementById('loginForm');
    if (loginForm.style.display !== 'none') handleLogin();
    else handleSignUp();
  }
});

