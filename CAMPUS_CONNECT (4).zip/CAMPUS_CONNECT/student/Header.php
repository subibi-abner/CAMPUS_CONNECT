<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8"/>
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>CampusConnect — Student</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/fullcalendar@6.1.11/main.min.css" rel="stylesheet">
  <link href="student.css" rel="stylesheet">
  <style>
    *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; font-family: 'Poppins', sans-serif; }
    :root {
      --red: #C0272D;
      --red-dark: #9b1e23;
      --red-light: #fef0f0;
      --sidebar-bg: #1a0a0b;
      --sidebar-hover: rgba(255,255,255,0.07);
      --sidebar-active: rgba(192,39,45,0.25);
      --text-primary: #111827;
      --text-secondary: #6b7280;
      --text-muted: #9ca3af;
      --border: #e5e7eb;
      --bg-page: #f4f6fb;
      --bg-card: #ffffff;
      --badge-h: 22px;
    }
    body { background: var(--bg-page); display: flex; flex-direction: column; min-height: 100vh; }

    /* ── NAVBAR ── */
    .topbar {
      height: 60px; background: #fff;
      border-bottom: 1px solid var(--border);
      display: flex; align-items: center;
      justify-content: space-between;
      padding: 0 20px 0 0;
      position: sticky; top: 0; z-index: 200;
    }
    .topbar-left { display: flex; align-items: center; gap: 0; }
    .logo-wrap {
      width: 240px; height: 60px;
      background: var(--sidebar-bg);
      display: flex; align-items: center;
      gap: 10px; padding: 0 20px;
      flex-shrink: 0;
    }
    .logo-circle {
      width: 34px; height: 34px; border-radius: 50%;
      background: var(--red); color: #fff;
      font-weight: 700; font-size: 14px;
      display: flex; align-items: center; justify-content: center;
    }
    .brand { font-size: 14px; font-weight: 600; color: #fff; letter-spacing: 0.01em; }
    .search-wrap {
      display: flex; align-items: center; gap: 8px;
      background: var(--bg-page); border: 1px solid var(--border);
      border-radius: 8px; padding: 6px 14px;
      width: 280px; margin-left: 20px;
      transition: border-color .2s;
    }
    .search-wrap:focus-within { border-color: var(--red); }
    .search-wrap input { border: none; background: none; outline: none; font-size: 13px; color: var(--text-primary); width: 100%; }
    .search-wrap i { color: var(--text-muted); font-size: 14px; }
    .topbar-right { display: flex; align-items: center; gap: 6px; }
    .icon-btn {
      width: 36px; height: 36px; border-radius: 8px;
      border: none; background: none; cursor: pointer;
      display: flex; align-items: center; justify-content: center;
      font-size: 17px; color: var(--text-secondary);
      transition: background .15s, color .15s; position: relative;
    }
    .icon-btn:hover { background: var(--bg-page); color: var(--text-primary); }
    .notif-dot {
      position: absolute; top: 6px; right: 6px;
      width: 8px; height: 8px; border-radius: 50%;
      background: var(--red); border: 2px solid #fff;
    }
    .avatar-btn {
      display: flex; align-items: center; gap: 8px;
      background: none; border: none; cursor: pointer;
      padding: 4px 8px; border-radius: 8px; transition: background .15s;
    }
    .avatar-btn:hover { background: var(--bg-page); }
    .avatar {
      width: 32px; height: 32px; border-radius: 50%;
      background: var(--red); color: #fff; font-size: 13px; font-weight: 600;
      display: flex; align-items: center; justify-content: center; flex-shrink: 0;
    }
    .avatar-name { font-size: 13px; font-weight: 500; color: var(--text-primary); }
    .avatar-role { font-size: 11px; color: var(--text-muted); }

    /* ── LAYOUT ── */
    .layout { display: flex; flex: 1; }

    /* ── MAIN ── */
    .main { flex: 1; padding: 28px 28px 40px; min-width: 0; }

    /* ── PAGE HEADER ── */
    .page-header { display: flex; align-items: flex-start; justify-content: space-between; margin-bottom: 24px; }
    .page-title { font-size: 22px; font-weight: 700; color: var(--text-primary); }
    .page-sub { font-size: 13px; color: var(--text-muted); margin-top: 2px; }

    /* ── STAT CARDS ── */
    .stat-row { display: grid; grid-template-columns: repeat(4, 1fr); gap: 14px; margin-bottom: 28px; }
    .stat-card {
      background: var(--bg-card); border: 1px solid var(--border);
      border-radius: 12px; padding: 16px 18px;
      display: flex; align-items: center; gap: 14px;
    }
    .stat-icon {
      width: 42px; height: 42px; border-radius: 10px;
      display: flex; align-items: center; justify-content: center;
      font-size: 18px; flex-shrink: 0;
    }
    .stat-icon.red { background: var(--red-light); color: var(--red); }
    .stat-icon.blue { background: #eaf3fb; color: #3b82f6; }
    .stat-icon.purple { background: #f3edfb; color: #9333ea; }
    .stat-icon.green { background: #ecfdf5; color: #059669; }
    .stat-num { font-size: 22px; font-weight: 700; color: var(--text-primary); line-height: 1; }
    .stat-label { font-size: 12px; color: var(--text-muted); margin-top: 2px; }

    /* ── CONTENT GRID ── */
    .content-grid { display: grid; grid-template-columns: 1fr 320px; gap: 20px; align-items: start; }

    /* ── FILTERS ── */
    .filter-bar { display: flex; gap: 8px; flex-wrap: wrap; margin-bottom: 18px; align-items: center; }
    .cat-pill {
      padding: 5px 16px; border-radius: 20px; font-size: 12px; font-weight: 500;
      border: 1.5px solid var(--border); background: var(--bg-card);
      color: var(--text-secondary); cursor: pointer; transition: all .18s;
    }
    .cat-pill.active { background: var(--red); color: #fff; border-color: var(--red); }
    .cat-pill:hover:not(.active) { border-color: var(--red); color: var(--red); }
    .view-toggle { margin-left: auto; display: flex; gap: 4px; }
    .view-btn {
      width: 30px; height: 30px; border-radius: 6px; border: 1.5px solid var(--border);
      background: var(--bg-card); display: flex; align-items: center; justify-content: center;
      cursor: pointer; color: var(--text-muted); font-size: 14px; transition: all .15s;
    }
    .view-btn.active { border-color: var(--red); color: var(--red); background: var(--red-light); }

    /* ── EVENT CARDS ── */
    .events-list { display: flex; flex-direction: column; gap: 12px; }
    .event-card {
      background: var(--bg-card); border: 1px solid var(--border);
      border-radius: 12px; overflow: hidden;
      display: flex; transition: box-shadow .2s, transform .2s;
    }
    .event-card:hover { box-shadow: 0 4px 16px rgba(0,0,0,0.08); transform: translateY(-1px); }
    .event-color-bar { width: 5px; flex-shrink: 0; }
    .event-color-bar.academic { background: #3b82f6; }
    .event-color-bar.social { background: #9333ea; }
    .event-color-bar.sports { background: var(--red); }
    .event-color-bar.org { background: #ca8a04; }
    .event-icon-col {
      width: 70px; flex-shrink: 0;
      display: flex; align-items: center; justify-content: center;
      font-size: 26px;
    }
    .event-icon-col.academic { background: #eaf3fb; color: #3b82f6; }
    .event-icon-col.social { background: #f3edfb; color: #9333ea; }
    .event-icon-col.sports { background: var(--red-light); color: var(--red); }
    .event-icon-col.org { background: #fefae0; color: #ca8a04; }
    .event-info { padding: 14px 16px; flex: 1; min-width: 0; }
    .event-cat-badge {
      display: inline-flex; align-items: center; height: var(--badge-h);
      padding: 0 10px; border-radius: 20px; font-size: 11px; font-weight: 600;
      margin-bottom: 6px;
    }
    .badge-academic { background: #dbeafe; color: #1d4ed8; }
    .badge-social { background: #ede9fe; color: #7c3aed; }
    .badge-sports { background: #fee2e2; color: #dc2626; }
    .badge-org { background: #fef9c3; color: #a16207; }
    .event-title-text { font-size: 14px; font-weight: 600; color: var(--text-primary); margin-bottom: 5px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
    .event-meta-row { display: flex; flex-wrap: wrap; gap: 10px; font-size: 11px; color: var(--text-muted); }
    .event-meta-row span { display: flex; align-items: center; gap: 4px; }
    .event-actions { padding: 14px 16px 14px 0; display: flex; flex-direction: column; align-items: flex-end; justify-content: center; gap: 6px; flex-shrink: 0; }
    .btn-details {
      padding: 7px 16px; border-radius: 7px;
      background: var(--red); color: #fff;
      border: none; font-size: 12px; font-weight: 600;
      cursor: pointer; transition: background .15s; white-space: nowrap;
    }
    .btn-details:hover { background: var(--red-dark); }
    .btn-save {
      padding: 7px 16px; border-radius: 7px;
      background: none; color: var(--text-secondary);
      border: 1.5px solid var(--border); font-size: 12px; font-weight: 500;
      cursor: pointer; transition: all .15s; white-space: nowrap;
    }
    .btn-save:hover { border-color: var(--red); color: var(--red); }
    .btn-save.saved { background: var(--red-light); color: var(--red); border-color: var(--red); }

    /* ── RIGHT SIDEBAR ── */
    .right-col { display: flex; flex-direction: column; gap: 16px; }
    .panel { background: var(--bg-card); border: 1px solid var(--border); border-radius: 12px; padding: 18px; }
    .panel-header { display: flex; align-items: center; justify-content: space-between; margin-bottom: 14px; }
    .panel-title { font-size: 14px; font-weight: 600; color: var(--text-primary); }
    .panel-link { font-size: 12px; color: var(--red); text-decoration: none; cursor: pointer; }
    .panel-link:hover { text-decoration: underline; }

    /* This Week */
    .week-item { display: flex; align-items: center; gap: 12px; padding: 9px 0; border-bottom: 1px solid #f5f5f5; cursor: pointer; border-radius: 6px; transition: background .15s; }
    .week-item:last-child { border-bottom: none; }
    .week-item:hover { background: var(--bg-page); padding-left: 6px; }
    .week-badge { width: 36px; height: 36px; border-radius: 10px; background: var(--red-light); color: var(--red); font-size: 13px; font-weight: 700; display: flex; align-items: center; justify-content: center; flex-shrink: 0; }
    .week-name { font-size: 13px; font-weight: 600; color: var(--text-primary); }
    .week-sub { font-size: 11px; color: var(--text-muted); }

    /* Mini Calendar */
    .mini-cal-nav { display: flex; align-items: center; justify-content: space-between; }
    .mini-cal-nav-btn { width: 26px; height: 26px; border-radius: 6px; border: 1px solid var(--border); background: none; cursor: pointer; display: flex; align-items: center; justify-content: center; font-size: 13px; color: var(--text-secondary); transition: all .15s; }
    .mini-cal-nav-btn:hover { background: var(--red-light); border-color: var(--red); color: var(--red); }
    .mini-cal-grid { display: grid; grid-template-columns: repeat(7, 1fr); gap: 2px; margin-top: 10px; }
    .mini-cal-day-label { font-size: 10px; color: var(--text-muted); text-align: center; padding: 4px 0; font-weight: 600; }
    .mini-cal-day { font-size: 12px; text-align: center; padding: 6px 2px; border-radius: 6px; cursor: pointer; color: var(--text-secondary); transition: all .15s; }
    .mini-cal-day:hover:not(.today) { background: var(--red-light); color: var(--red); }
    .mini-cal-day.today { background: var(--red); color: #fff; font-weight: 700; border-radius: 50%; }
    .mini-cal-day.has-event { color: var(--red); font-weight: 600; }
    .mini-cal-day.has-event::after { content: ''; display: block; width: 4px; height: 4px; border-radius: 50%; background: var(--red); margin: 1px auto 0; }
    .mini-cal-day.today::after { background: rgba(255,255,255,0.7); }

    /* Org grid */
    .org-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 8px; }
    .org-card {
      border: 1px solid var(--border); border-radius: 8px;
      padding: 10px; display: flex; align-items: center; gap: 10px;
      cursor: pointer; transition: all .15s;
    }
    .org-card:hover { border-color: var(--red); background: var(--red-light); }
    .org-icon-wrap { width: 32px; height: 32px; border-radius: 8px; background: var(--bg-page); display: flex; align-items: center; justify-content: center; font-size: 15px; color: var(--text-secondary); flex-shrink: 0; }
    .org-name-text { font-size: 12px; font-weight: 600; color: var(--text-primary); }
    .org-members-text { font-size: 10px; color: var(--text-muted); }

    /* ── CALENDAR SECTION ── */
    .section-header { margin-bottom: 20px; }
    .section-header h2 { font-size: 20px; font-weight: 700; color: var(--text-primary); }
    .section-header p { font-size: 13px; color: var(--text-muted); margin-top: 4px; }
    #calendarEl .fc-toolbar-title { font-size: 16px; font-weight: 600; }
    #calendarEl .fc-button { background: var(--red); border-color: var(--red); font-size: 12px; }
    #calendarEl .fc-button:hover { background: var(--red-dark); border-color: var(--red-dark); }
    #calendarEl .fc-daygrid-event { border-radius: 4px; font-size: 11px; }

    /* ── MY EVENTS ── */
    .empty-state { text-align: center; padding: 60px 20px; }
    .empty-state i { font-size: 48px; color: var(--text-muted); margin-bottom: 12px; display: block; }
    .empty-state h3 { font-size: 16px; font-weight: 600; color: var(--text-primary); margin-bottom: 6px; }
    .empty-state p { font-size: 13px; color: var(--text-muted); }
    .my-event-item {
      background: var(--bg-card); border: 1px solid var(--border); border-radius: 10px;
      padding: 14px 18px; display: flex; align-items: center; gap: 14px; margin-bottom: 10px;
    }
    .my-event-badge { width: 40px; height: 40px; border-radius: 10px; display: flex; align-items: center; justify-content: center; font-size: 18px; flex-shrink: 0; }
    .my-event-name { font-size: 14px; font-weight: 600; color: var(--text-primary); }
    .my-event-sub { font-size: 12px; color: var(--text-muted); margin-top: 2px; }
    .my-event-actions { margin-left: auto; display: flex; gap: 6px; }
    .btn-unsave { padding: 6px 12px; border-radius: 7px; font-size: 12px; font-weight: 500; border: 1.5px solid var(--border); background: none; color: var(--text-secondary); cursor: pointer; transition: all .15s; }
    .btn-unsave:hover { border-color: #dc2626; color: #dc2626; background: #fee2e2; }

    /* ── NOTIFICATIONS PANEL ── */
    .notif-panel {
      position: fixed; top: 60px; right: 0;
      width: 340px; max-height: calc(100vh - 60px);
      background: var(--bg-card); border-left: 1px solid var(--border);
      box-shadow: -4px 0 20px rgba(0,0,0,0.08);
      z-index: 190; display: none; flex-direction: column;
      overflow: hidden;
    }
    .notif-panel.open { display: flex; }
    .notif-panel-header { padding: 16px 18px; border-bottom: 1px solid var(--border); display: flex; align-items: center; justify-content: space-between; }
    .notif-panel-title { font-size: 14px; font-weight: 600; color: var(--text-primary); }
    .notif-panel-actions { display: flex; gap: 8px; }
    .notif-mark-all { font-size: 12px; color: var(--red); cursor: pointer; border: none; background: none; }
    .notif-close { background: none; border: none; cursor: pointer; font-size: 16px; color: var(--text-muted); }
    .notif-list { overflow-y: auto; flex: 1; }
    .notif-item { display: flex; gap: 12px; padding: 14px 18px; border-bottom: 1px solid var(--border); cursor: pointer; transition: background .15s; }
    .notif-item:hover { background: var(--bg-page); }
    .notif-item.unread { background: #fffaf9; }
    .notif-item-icon { width: 36px; height: 36px; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-size: 16px; flex-shrink: 0; }
    .notif-item-icon.red { background: var(--red-light); color: var(--red); }
    .notif-item-icon.blue { background: #eaf3fb; color: #3b82f6; }
    .notif-item-icon.green { background: #ecfdf5; color: #059669; }
    .notif-item-text { font-size: 13px; color: var(--text-primary); line-height: 1.5; }
    .notif-item-text strong { font-weight: 600; }
    .notif-item-time { font-size: 11px; color: var(--text-muted); margin-top: 3px; }
    .notif-unread-dot { width: 8px; height: 8px; border-radius: 50%; background: var(--red); margin-top: 6px; flex-shrink: 0; }

    /* ── MODAL ── */
    .modal-overlay {
      position: fixed; inset: 0; background: rgba(0,0,0,0.45);
      z-index: 300; display: none; align-items: center; justify-content: center;
    }
    .modal-overlay.open { display: flex; }
    .modal-box {
      background: var(--bg-card); border-radius: 16px; width: 100%; max-width: 500px;
      max-height: 85vh; overflow-y: auto; margin: 20px;
      animation: popIn .2s ease;
    }
    @keyframes popIn { from { transform: scale(.95); opacity: 0; } to { transform: scale(1); opacity: 1; } }
    .modal-banner { height: 140px; display: flex; align-items: center; justify-content: center; font-size: 50px; border-radius: 16px 16px 0 0; }
    .modal-banner.academic { background: #eaf3fb; color: #3b82f6; }
    .modal-banner.social { background: #f3edfb; color: #9333ea; }
    .modal-banner.sports { background: var(--red-light); color: var(--red); }
    .modal-banner.org { background: #fefae0; color: #ca8a04; }
    .modal-body { padding: 22px 24px 28px; }
    .modal-cat-badge { margin-bottom: 8px; display: inline-flex; }
    .modal-title { font-size: 20px; font-weight: 700; color: var(--text-primary); margin-bottom: 12px; }
    .modal-meta-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 10px; margin-bottom: 16px; }
    .modal-meta-item { display: flex; align-items: flex-start; gap: 8px; font-size: 13px; color: var(--text-secondary); }
    .modal-meta-item i { margin-top: 2px; color: var(--red); }
    .modal-desc { font-size: 13px; color: var(--text-secondary); line-height: 1.7; margin-bottom: 20px; }
    .modal-footer { display: flex; gap: 10px; }
    .btn-join { flex: 1; padding: 11px; border-radius: 9px; background: var(--red); color: #fff; border: none; font-size: 14px; font-weight: 600; cursor: pointer; transition: background .15s; }
    .btn-join:hover { background: var(--red-dark); }
    .btn-join.joined { background: #ecfdf5; color: #059669; border: 1.5px solid #059669; }
    .btn-modal-save { padding: 11px 18px; border-radius: 9px; border: 1.5px solid var(--border); background: none; color: var(--text-secondary); font-size: 14px; font-weight: 500; cursor: pointer; transition: all .15s; }
    .btn-modal-save:hover { border-color: var(--red); color: var(--red); }
    .btn-modal-close { position: absolute; top: 12px; right: 12px; width: 32px; height: 32px; border-radius: 50%; background: rgba(0,0,0,0.35); border: none; color: #fff; font-size: 16px; cursor: pointer; display: flex; align-items: center; justify-content: center; }
    .modal-banner-wrap { position: relative; }

    /* ── TOAST ── */
    .toast-container { position: fixed; bottom: 24px; right: 24px; z-index: 400; display: flex; flex-direction: column; gap: 8px; }
    .toast { background: #1f2937; color: #fff; padding: 12px 18px; border-radius: 10px; font-size: 13px; font-weight: 500; display: flex; align-items: center; gap: 10px; animation: slideIn .25s ease; box-shadow: 0 4px 16px rgba(0,0,0,0.2); min-width: 220px; }
    .toast.success i { color: #34d399; }
    .toast.info i { color: #60a5fa; }
    .toast.warning i { color: #fbbf24; }
    @keyframes slideIn { from { transform: translateX(100%); opacity: 0; } to { transform: translateX(0); opacity: 1; } }

    /* ── CALENDAR EVENT POPUP ── */
    .fc-daygrid-event {
      cursor: pointer !important; border-radius: 5px !important;
      font-size: 11px !important; font-weight: 600 !important;
      padding: 2px 6px !important; transition: transform .15s, box-shadow .15s !important;
    }
    .fc-daygrid-event:hover { transform: translateY(-1px) !important; box-shadow: 0 3px 10px rgba(0,0,0,0.18) !important; }
    .cal-event-popup {
      position: absolute; background: #fff; border: 1px solid var(--border);
      border-radius: 12px; box-shadow: 0 8px 32px rgba(0,0,0,0.14);
      padding: 14px 16px; width: 240px; z-index: 500;
      animation: popIn .18s ease; pointer-events: auto;
    }
    .cal-event-popup::after {
      content: ''; position: absolute; bottom: -8px; left: 50%; transform: translateX(-50%);
      width: 14px; height: 8px; background: #fff;
      clip-path: polygon(0 0, 100% 0, 50% 100%);
      filter: drop-shadow(0 2px 2px rgba(0,0,0,0.08));
    }
    .cal-popup-banner { width: 100%; height: 64px; border-radius: 8px; display: flex; align-items: center; justify-content: center; font-size: 28px; margin-bottom: 10px; }
    .cal-popup-banner.academic { background: #eaf3fb; }
    .cal-popup-banner.social   { background: #f3edfb; }
    .cal-popup-banner.sports   { background: var(--red-light); }
    .cal-popup-banner.org      { background: #fefae0; }
    .cal-popup-cat { display: inline-flex; align-items: center; height: 20px; padding: 0 8px; border-radius: 20px; font-size: 10px; font-weight: 600; margin-bottom: 6px; }
    .cal-popup-title { font-size: 13px; font-weight: 700; color: var(--text-primary); margin-bottom: 7px; line-height: 1.35; }
    .cal-popup-meta { display: flex; flex-direction: column; gap: 3px; font-size: 11px; color: var(--text-muted); margin-bottom: 11px; }
    .cal-popup-meta span { display: flex; align-items: center; gap: 5px; }
    .cal-popup-btn { width: 100%; padding: 8px; border-radius: 7px; background: var(--red); color: #fff; border: none; font-size: 12px; font-weight: 600; cursor: pointer; transition: background .15s; }
    .cal-popup-btn:hover { background: var(--red-dark); }

    /* Mini-cal tooltip */
    .mini-cal-day.has-event { position: relative; }
    .mini-day-tooltip {
      position: absolute; bottom: calc(100% + 8px); left: 50%; transform: translateX(-50%);
      background: #1f2937; color: #fff; font-size: 10px; white-space: nowrap;
      padding: 4px 8px; border-radius: 6px; pointer-events: none; z-index: 600;
      opacity: 0; transition: opacity .15s;
    }
    .mini-cal-day.has-event:hover .mini-day-tooltip { opacity: 1; }

    /* ── RESPONSIVE ── */
    @media (max-width: 1100px) {
      .content-grid { grid-template-columns: 1fr; }
      .right-col { display: grid; grid-template-columns: 1fr 1fr; gap: 16px; }
    }
    @media (max-width: 768px) {
      .sidebar { display: none; }
      .stat-row { grid-template-columns: 1fr 1fr; }
      .right-col { grid-template-columns: 1fr; }
      .search-wrap { width: 200px; }
    }
    @media (max-width: 480px) {
      .stat-row { grid-template-columns: 1fr; }
      .main { padding: 16px; }
    }
  </style>
</head>