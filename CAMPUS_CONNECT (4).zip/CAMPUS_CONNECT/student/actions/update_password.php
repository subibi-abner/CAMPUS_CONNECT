<?php
session_start();
require_once '../../config.php';
require_once '../../db_functions.php';
header('Content-Type: application/json');

if (!isset($_SESSION['user_id'])) { echo json_encode(['success'=>false,'msg'=>'Not logged in']); exit; }
$user_id = (int)$_SESSION['user_id'];

$cur  = $_POST['current_password']  ?? '';
$new  = $_POST['new_password']      ?? '';
$conf = $_POST['confirm_password']  ?? '';

if (!$cur || !$new || !$conf) { echo json_encode(['success'=>false,'msg'=>'All fields are required']); exit; }
if ($new !== $conf)           { echo json_encode(['success'=>false,'msg'=>'Passwords do not match']); exit; }
if (strlen($new) < 6)        { echo json_encode(['success'=>false,'msg'=>'Password must be at least 6 characters']); exit; }

$stmt = $pdo->prepare("SELECT password FROM users WHERE id=?");
$stmt->execute([$user_id]);
$row = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$row || !password_verify($cur, $row['password'])) {
  echo json_encode(['success'=>false,'msg'=>'Current password is incorrect']); exit;
}

$hash = password_hash($new, PASSWORD_BCRYPT);
$upd  = $pdo->prepare("UPDATE users SET password=? WHERE id=?");
$upd->execute([$hash, $user_id]);
echo json_encode(['success'=>true,'msg'=>'Password updated successfully']);
