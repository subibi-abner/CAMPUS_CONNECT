<?php
/**
 * student/actions/get_my_events.php
 *
 * Returns the student's registered, saved, or attended events as JSON.
 *
 * GET params:
 *   tab     = 'registered' | 'saved' | 'attended'   (default: registered)
 *   filter  = 'all' | 'upcoming' | 'past'            (default: all)
 *
 * Response:
 *   {
 *     success: bool,
 *     events: [...],
 *     registered_count: int,
 *     saved_count: int,
 *     attended_count: int
 *   }
 */

if (session_status() === PHP_SESSION_NONE) session_start();
require_once '../../config.php';
require_once '../../db_functions.php';

header('Content-Type: application/json');

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'student') {
    echo json_encode(['success' => false, 'msg' => 'Not logged in']);
    exit;
}

$user_id = (int)$_SESSION['user_id'];
$tab     = $_GET['tab']    ?? 'registered';
$filter  = $_GET['filter'] ?? 'all';

// ── Date filter clause ──────────────────────────────────────
$dateClause = '';
if ($filter === 'upcoming') {
    $dateClause = "AND e.event_date >= NOW()";
} elseif ($filter === 'past') {
    $dateClause = "AND e.event_date < NOW()";
}

// ── Counts (always return all three regardless of tab) ──────
$cntStmt = $pdo->prepare("SELECT COUNT(*) FROM registrations r JOIN events e ON r.event_id = e.id WHERE r.user_id = ? AND e.status = 'approved'");
$cntStmt->execute([$user_id]);
$registered_count = (int)$cntStmt->fetchColumn();

$savStmt = $pdo->prepare("SELECT COUNT(*) FROM saved_events s JOIN events e ON s.event_id = e.id WHERE s.user_id = ? AND e.status = 'approved'");
$savStmt->execute([$user_id]);
$saved_count = (int)$savStmt->fetchColumn();

$attStmt = $pdo->prepare("SELECT COUNT(*) FROM attendance a JOIN events e ON a.event_id = e.id WHERE a.user_id = ? AND a.time_in IS NOT NULL");
$attStmt->execute([$user_id]);
$attended_count = (int)$attStmt->fetchColumn();

// ── Fetch events for the active tab ─────────────────────────
$events = [];

if ($tab === 'registered') {
    $stmt = $pdo->prepare("
        SELECT
            e.id, e.title, e.description, e.category,
            e.event_date, e.location, e.status,
            e.max_attendees, e.registration_deadline,
            o.name AS org_name, o.acronym AS org_acronym,
            d.name AS department_name, d.code AS dept_code,
            r.registered_at,
            a.time_in, a.time_out,
            (SELECT COUNT(*) FROM registrations rc WHERE rc.event_id = e.id) AS attendee_count
        FROM registrations r
        JOIN events e ON r.event_id = e.id
        LEFT JOIN organizations o ON e.org_id = o.id
        LEFT JOIN departments   d ON e.department_id = d.id
        LEFT JOIN attendance    a ON a.event_id = e.id AND a.user_id = r.user_id
        WHERE r.user_id = ?
          AND e.status = 'approved'
          $dateClause
        ORDER BY e.event_date ASC
    ");
    $stmt->execute([$user_id]);
    $events = $stmt->fetchAll(PDO::FETCH_ASSOC);

} elseif ($tab === 'saved') {
    $stmt = $pdo->prepare("
        SELECT
            e.id, e.title, e.description, e.category,
            e.event_date, e.location, e.status,
            e.max_attendees, e.registration_deadline,
            o.name AS org_name, o.acronym AS org_acronym,
            d.name AS department_name, d.code AS dept_code,
            s.saved_at,
            EXISTS(SELECT 1 FROM registrations r WHERE r.event_id = e.id AND r.user_id = ?) AS is_registered,
            (SELECT COUNT(*) FROM registrations rc WHERE rc.event_id = e.id) AS attendee_count
        FROM saved_events s
        JOIN events e ON s.event_id = e.id
        LEFT JOIN organizations o ON e.org_id = o.id
        LEFT JOIN departments   d ON e.department_id = d.id
        WHERE s.user_id = ?
          AND e.status = 'approved'
          $dateClause
        ORDER BY e.event_date ASC
    ");
    $stmt->execute([$user_id, $user_id]);
    $events = $stmt->fetchAll(PDO::FETCH_ASSOC);

} elseif ($tab === 'attended') {
    $stmt = $pdo->prepare("
        SELECT
            e.id, e.title, e.description, e.category,
            e.event_date, e.location, e.status,
            o.name AS org_name, o.acronym AS org_acronym,
            d.name AS department_name, d.code AS dept_code,
            a.time_in, a.time_out, a.certificate_sent,
            (SELECT COUNT(*) FROM registrations rc WHERE rc.event_id = e.id) AS attendee_count
        FROM attendance a
        JOIN events e ON a.event_id = e.id
        LEFT JOIN organizations o ON e.org_id = o.id
        LEFT JOIN departments   d ON e.department_id = d.id
        WHERE a.user_id = ?
          AND a.time_in IS NOT NULL
          $dateClause
        ORDER BY e.event_date DESC
    ");
    $stmt->execute([$user_id]);
    $events = $stmt->fetchAll(PDO::FETCH_ASSOC);
}

echo json_encode([
    'success'          => true,
    'events'           => $events,
    'registered_count' => $registered_count,
    'saved_count'      => $saved_count,
    'attended_count'   => $attended_count,
]);
