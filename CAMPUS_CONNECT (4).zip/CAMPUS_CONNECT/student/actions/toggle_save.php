<?php
session_start();
require_once '../../config.php';
require_once '../../db_functions.php';
header('Content-Type: application/json');

if (!isset($_SESSION['user_id'])) { echo json_encode(['success'=>false,'msg'=>'Not logged in']); exit; }
$user_id  = (int)$_SESSION['user_id'];
$event_id = (int)($_POST['event_id'] ?? 0);
if (!$event_id) { echo json_encode(['success'=>false,'msg'=>'Invalid event']); exit; }

// Check if already saved
$check = $pdo->prepare("SELECT id FROM saved_events WHERE user_id=? AND event_id=?");
$check->execute([$user_id, $event_id]);

if ($check->fetch()) {
  $del = $pdo->prepare("DELETE FROM saved_events WHERE user_id=? AND event_id=?");
  $del->execute([$user_id, $event_id]);
  echo json_encode(['success'=>true,'saved'=>false,'msg'=>'Event removed from saved']);
} else {
  $ins = $pdo->prepare("INSERT IGNORE INTO saved_events (user_id, event_id) VALUES (?,?)");
  $ins->execute([$user_id, $event_id]);
  echo json_encode(['success'=>true,'saved'=>true,'msg'=>'Event saved!']);
}
