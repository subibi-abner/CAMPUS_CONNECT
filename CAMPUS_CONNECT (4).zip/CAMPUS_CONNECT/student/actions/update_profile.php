<?php
session_start();
require_once '../../config.php';
require_once '../../db_functions.php';
header('Content-Type: application/json');
if (!isset($_SESSION['user_id'])) { echo json_encode(['success'=>false,'msg'=>'Not logged in']); exit; }

$user_id       = (int)$_SESSION['user_id'];
$full_name     = trim($_POST['full_name']     ?? '');
$year_level    = trim($_POST['year_level']    ?? '');
$department_id = (int)($_POST['department_id'] ?? 0);
$course        = trim($_POST['course']        ?? '');
$bio           = trim($_POST['bio']           ?? '');

if (!$full_name) { echo json_encode(['success'=>false,'msg'=>'Full name is required']); exit; }

$stmt = $pdo->prepare("UPDATE users SET full_name=?, year_level=?, department_id=?, course=?, bio=? WHERE id=?");
$stmt->execute([$full_name, $year_level ?: null, $department_id ?: null, $course ?: null, $bio ?: null, $user_id]);
$_SESSION['full_name'] = $full_name;

$upd = $pdo->prepare("SELECT u.*, d.name AS department_name, d.code AS dept_code FROM users u LEFT JOIN departments d ON u.department_id=d.id WHERE u.id=?");
$upd->execute([$user_id]);
$row = $upd->fetch(PDO::FETCH_ASSOC);

echo json_encode([
  'success'      => true,
  'msg'          => 'Profile updated successfully',
  'full_name'    => $row['full_name'],
  'initial'      => strtoupper(substr($row['full_name'], 0, 1)),
  'year_level'   => $row['year_level'] ?? '',
  'course'       => $row['course'] ?? '',
  'college_code' => $row['dept_code'] ?? 'WMSU',  // kept for JS compat
]);
