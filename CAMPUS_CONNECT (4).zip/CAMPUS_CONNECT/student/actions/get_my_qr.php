<?php
session_start();
require_once '../../config.php';
require_once '../../db_functions.php';
header('Content-Type: application/json');

if (!isset($_SESSION['user_id'])) {
  echo json_encode(['success' => false, 'msg' => 'Not logged in']); exit;
}

$user_id  = (int)$_SESSION['user_id'];
$event_id = (int)($_GET['event_id'] ?? 0);

if (!$event_id) {
  echo json_encode(['success' => false, 'msg' => 'Invalid event']); exit;
}

// Confirm student is registered for this event
$stmt = $pdo->prepare("SELECT 1 FROM registrations WHERE user_id = ? AND event_id = ?");
$stmt->execute([$user_id, $event_id]);
if (!$stmt->fetch()) {
  echo json_encode(['success' => false, 'msg' => 'Not registered for this event']); exit;
}

// Get or create token
$stmt = $pdo->prepare("SELECT token FROM attendance_tokens WHERE user_id = ? AND event_id = ?");
$stmt->execute([$user_id, $event_id]);
$row = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$row) {
  // Create token if missing (e.g. old registration before feature was added)
  $token = bin2hex(random_bytes(32));
  $ins = $pdo->prepare("INSERT IGNORE INTO attendance_tokens (event_id, user_id, token) VALUES (?, ?, ?)");
  $ins->execute([$event_id, $user_id, $token]);
} else {
  $token = $row['token'];
}

// Get attendance status too
$stmt = $pdo->prepare("SELECT time_in, time_out FROM attendance WHERE event_id = ? AND user_id = ?");
$stmt->execute([$event_id, $user_id]);
$att = $stmt->fetch(PDO::FETCH_ASSOC);

echo json_encode([
  'success'   => true,
  'token'     => $token,
  'time_in'   => $att['time_in']  ?? null,
  'time_out'  => $att['time_out'] ?? null,
]);
