<?php
/**
 * student/actions/toggle_join.php
 *
 * Registers or un-registers the logged-in student for an event.
 *
 * SECURITY: All business rules (college restriction, deadline, capacity)
 * are enforced SERVER-SIDE via join_event_safe(). The UI cannot bypass them.
 *
 * POST params:
 *   event_id  (int, required)
 *
 * JSON response:
 *   { success: bool, joined: bool|null, msg: string }
 */

session_start();
require_once '../../config.php';      // provides $pdo
require_once '../../db_functions.php'; // provides join_event_safe()

header('Content-Type: application/json');

// ── Auth guard ──────────────────────────────────────────────
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'student') {
    echo json_encode(['success' => false, 'joined' => null, 'msg' => 'Not logged in or not a student']);
    exit;
}

// ── Input validation ────────────────────────────────────────
$user_id  = (int)$_SESSION['user_id'];
$event_id = (int)($_POST['event_id'] ?? 0);

if (!$event_id) {
    echo json_encode(['success' => false, 'joined' => null, 'msg' => 'Invalid event']);
    exit;
}

// ── Delegate ALL business-rule checks to the safe helper ────
// join_event_safe() checks, in order:
//   1. Event exists & is approved
//   2. Student's department matches event's college restriction
//   3. Registration deadline has not passed
//   4. Event is not at capacity
//   5. Toggle registration on/off
$result = join_event_safe($pdo, $user_id, $event_id);

echo json_encode($result);
