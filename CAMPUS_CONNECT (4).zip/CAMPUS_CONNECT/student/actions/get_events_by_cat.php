<?php
session_start();
require_once '../../config.php';
header('Content-Type: application/json');

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'msg' => 'Not logged in']);
    exit;
}

$user_id = $_SESSION['user_id'];
$cat = $_GET['cat'] ?? 'all';
$limit = (int)($_GET['limit'] ?? 20);

try {
    $where = "e.status = 'approved' AND e.event_date > NOW()";
    $params = [];

    if ($cat !== 'all') {
        // Map UI cats to SQL conditions via keywords (matches catInfo logic)
        $catConditions = [
            'academic' => "e.category LIKE '%academic%' OR e.category LIKE '%seminar%' OR e.category LIKE '%research%' OR e.category LIKE '%forum%' OR e.category LIKE '%workshop%' OR e.category LIKE '%review%'",
            'social' => "e.category LIKE '%social%' OR e.category LIKE '%cultural%' OR e.category LIKE '%music%' OR e.category LIKE '%night%'",
            'sports' => "e.category LIKE '%sport%' OR e.category LIKE '%athletic%' OR e.category LIKE '%intramural%' OR e.category LIKE '%game%'",
            'org' => "e.category LIKE '%org%' OR e.category LIKE '%organization%'"
        ];
        if (isset($catConditions[$cat])) {
            $where .= " AND (" . $catConditions[$cat] . ")";
        }
    }

    $stmt = $pdo->prepare("
        SELECT e.*,
               u.full_name AS organizer_name,
               o.name AS org_name,
               o.acronym AS org_acronym,
               (SELECT COUNT(*) FROM registrations r WHERE r.event_id = e.id) AS attendee_count,
               EXISTS(SELECT 1 FROM registrations r WHERE r.event_id=e.id AND r.user_id=?) AS is_joined,
               EXISTS(SELECT 1 FROM saved_events s WHERE s.event_id=e.id AND s.user_id=?) AS is_saved
        FROM events e
        LEFT JOIN users u ON e.organizer_id = u.id
        LEFT JOIN organizations o ON e.org_id = o.id
        WHERE $where
        ORDER BY e.event_date ASC
        LIMIT ?
    ");
    $stmt->execute(array_merge([$user_id, $user_id], [$limit]));
    $events = $stmt->fetchAll(PDO::FETCH_ASSOC);

    echo json_encode([
        'success' => true,
        'events' => $events,
        'category' => $cat,
        'count' => count($events)
    ]);

} catch (Exception $e) {
    echo json_encode(['success' => false, 'msg' => 'Database error']);
}
?>

