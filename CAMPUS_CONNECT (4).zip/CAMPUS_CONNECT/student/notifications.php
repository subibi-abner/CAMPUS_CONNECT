<?php
// Student notifications panel (stub - expand as needed)
?>
<div class="notif-panel" id="notifPanel">
  <div class="notif-header">
    <h4>Notifications</h4>
    <span class="notif-count">3</span>
  </div>
  <div class="notif-list">
    <div class="notif-item">
      <div class="notif-icon">
        <i class="bi bi-bell"></i>
      </div>
      <div class="notif-content">
        <strong>New event: Tech Seminar</strong>
        <span>2 hours ago</span>
      </div>
    </div>
    <!-- Add more notifications -->
  </div>
</div>
