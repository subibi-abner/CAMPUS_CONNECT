<?php
/**
 * Navbar.php — CampusConnect Top Navigation Bar
 *
 * Customize the student name/year/course by setting before including:
 *   $studentName     = 'Juan dela Cruz';
 *   $studentInitial  = 'J';
 *   $studentYear     = '3rd Year · BSCS';
 */

$studentName    = $studentName    ?? 'Juan dela Cruz';
$studentInitial = $studentInitial ?? 'J';
$studentYear    = $studentYear    ?? '3rd Year · BSCS';
?>

<nav class="topbar">

  <!-- Left: Logo + Search -->
  <div class="topbar-left">
    <div class="logo-wrap">
      <div class="logo-circle">C</div>
      <span class="brand">CampusConnect</span>
    </div>
    <div class="search-wrap">
      <i class="bi bi-search"></i>
      <input
        type="text"
        placeholder="Search events, orgs... (Ctrl+K)"
        id="searchInput"
        oninput="handleSearch(this.value)"
      >
      <button id="searchClearBtn" onclick="clearSearch()" title="Clear search"
        style="background:none;border:none;cursor:pointer;color:var(--text-muted);font-size:14px;padding:0;display:none;">
        <i class="bi bi-x-circle-fill"></i>
      </button>
    </div>
  </div>

  <!-- Right: Notifications + Avatar -->
  <div class="topbar-right">

    <!-- Notification Bell -->
    <button class="icon-btn" onclick="toggleNotif()" title="Notifications (press Esc to close)" id="notifBtn">
      <i class="bi bi-bell"></i>
      <span class="notif-dot" id="notifDot"></span>
    </button>

    <!-- Avatar Dropdown -->
    <div class="dropdown">
      <button class="avatar-btn dropdown-toggle" data-bs-toggle="dropdown" aria-expanded="false">
        <div class="avatar"><?= htmlspecialchars($studentInitial) ?></div>
        <div style="text-align:left">
          <div class="avatar-name"><?= htmlspecialchars($studentName) ?></div>
          <div class="avatar-role"><?= htmlspecialchars($studentYear) ?></div>
        </div>
        <i class="bi bi-chevron-down" style="font-size:11px;color:var(--text-muted);margin-left:2px"></i>
      </button>
      <ul class="dropdown-menu dropdown-menu-end" style="font-size:13px;min-width:190px;">
        <li>
          <a class="dropdown-item" href="#" onclick="openProfile(); return false;">
            <i class="bi bi-person me-2"></i>My Profile
          </a>
        </li>
        <li>
          <a class="dropdown-item" href="#" onclick="openSettings(); return false;">
            <i class="bi bi-gear me-2"></i>Settings
          </a>
        </li>
        <li>
          <a class="dropdown-item" href="My events.php">
            <i class="bi bi-bookmark me-2"></i>Saved Events
            <span id="savedEventsBadge" style="margin-left:auto;background:var(--red);color:#fff;font-size:10px;font-weight:700;padding:1px 6px;border-radius:10px;"></span>
          </a>
        </li>
        <li><hr class="dropdown-divider"></li>
        <li>
          <a class="dropdown-item text-danger" href="#" onclick="confirmLogout(); return false;">
            <i class="bi bi-box-arrow-right me-2"></i>Logout
          </a>
        </li>
      </ul>
    </div>

  </div>
</nav>

<script>
/* Show/hide clear button on search input */
document.addEventListener('DOMContentLoaded', function() {
  var si = document.getElementById('searchInput');
  var cb = document.getElementById('searchClearBtn');
  if (si && cb) {
    si.addEventListener('input', function() {
      cb.style.display = this.value ? 'block' : 'none';
    });
  }
  fetch('actions/get_my_events.php?tab=saved')
    .then(r => r.json())
    .then(data => {
      var badge = document.getElementById('savedEventsBadge');
      if (badge && data.success) badge.textContent = data.events.length || '';
    });
});

</script>
