/**
 * app.js — CampusConnect Student Portal
 * All shared JavaScript: events data, section switching,
 * modals, calendar, toast, search, notifications, mini-cal,
 * profile, settings, share, and more.
 */

/* ══════════════════════════════════════════
   EVENT DATA  — loaded from DB via Dashboard.php
═══════════════════════════════════════════ */
// window.CC_EVENTS is injected by Dashboard.php as an array; convert to id-keyed map
const events = {};
(window.CC_EVENTS || []).forEach(function(ev) {
  var catMap = {academic:'badge-academic',social:'badge-social',sports:'badge-sports',org:'badge-org',organizations:'badge-org'};
  var bannerMap = {academic:'academic',social:'social',sports:'sports',org:'org',organizations:'org'};
  var iconMap   = {academic:'bi-mortarboard',social:'bi-music-note',sports:'bi-trophy',org:'bi-people',organizations:'bi-people'};
  var emojiMap  = {academic:'🎓',social:'🎵',sports:'🏆',org:'🏛️',organizations:'🏛️'};
  var ck = (ev.catKey || 'org').toLowerCase();
  events[ev.id] = {
    title:         ev.title,
    cat:           ck,
    catLabel:      ev.category || 'General',
    badgeClass:    catMap[ck]   || 'badge-org',
    bannerClass:   bannerMap[ck]|| 'org',
    icon:          iconMap[ck]  || 'bi-people',
    emoji:         emojiMap[ck] || '📅',
    date:          ev.date,
    dateRaw:       ev.dateRaw   || '',
    time:          ev.time,
    venue:         ev.venue,
    attendees:     ev.attendees,
    desc:          ev.desc,
    isJoined:      !!ev.isJoined,
    isSaved:       !!ev.isSaved,
    maxSlots:      ev.maxSlots || 100,
    org:           ev.org || 'WMSU',
    orgId:         ev.orgId || 0,
    canRegister:   !!ev.canRegister,
    isRestricted:  !!ev.isRestricted,
    restrictLabel: ev.restrictLabel || '',
    deadlinePassed:!!ev.deadlinePassed,
    isFull:        !!ev.isFull,
    regDeadline:   ev.regDeadline || null,
  };
});

/* ── Runtime state (seeded from DB flags injected above) ── */
const saved      = new Set();
const joined     = new Set();
const joinedOrgs = new Set();
const readNotifs = new Set();

// Seed joined/saved from DB data so UI is correct on page load
(window.CC_EVENTS || []).forEach(function(ev) {
  if (ev.isJoined) joined.add(ev.id);
  if (ev.isSaved)  saved.add(ev.id);
});

function persistState() { /* state now lives in DB — no-op */ }


/* ══════════════════════════════════════════
   SECTION SWITCHING
═══════════════════════════════════════════ */
function showSection(name) {
  document.querySelectorAll('.section').forEach(s => s.classList.remove('active'));
  document.querySelectorAll('.nav-link-item').forEach(n => n.classList.remove('active'));

  const sec = document.getElementById(name + 'Section');
  if (sec) sec.classList.add('active');

  const nav = document.getElementById('nav-' + name);
  if (nav) nav.classList.add('active');

  if (name === 'calendar' && !window._calInit) {
    window._calInit = true;
    setTimeout(initFullCalendar, 100);
  }

  if (name === 'myEvents') renderMyEvents();
}


/* ══════════════════════════════════════════
   CATEGORY FILTER
═══════════════════════════════════════════ */
function updateCatHeader(cat) {
  const header = document.getElementById('catHeader');
  const labelEl = document.getElementById('catLabel');
  const countEl = document.getElementById('catCount');
  if (!header) return;

  const labels = {
    all: 'All',
    academic: 'Academic',
    social: 'Social', 
    sports: 'Sports',
    org: 'Organizations'
  };

  if (cat === 'all') {
    header.style.display = 'none';
  } else {
    header.style.display = 'block';
    labelEl.textContent = labels[cat] || cat;
    const count = window.CC_CAT_COUNTS?.[cat] || 0;
    countEl.textContent = count;
  }
}

/* Active category state */
var _activeCat = 'all';

function filterCat(el, cat) {
  _activeCat = cat || 'all';
  document.querySelectorAll('.cat-pill').forEach(p => p.classList.remove('active'));
  if (el) {
    el.classList.add('active');
  } else {
    const pill = document.getElementById('pill-' + _activeCat);
    if (pill) pill.classList.add('active');
  }
  applyFilters();
  updateCatHeader(_activeCat);
}

function applyFilters() {
  const dateFilter = (document.getElementById('filterDate') || {}).value || '';
  const orgFilter  = (document.getElementById('filterOrg')  || {}).value || '';

  const now       = new Date();
  const todayStr  = now.toISOString().slice(0,10);
  const weekEnd   = new Date(now); weekEnd.setDate(now.getDate() + 7);
  const monthEnd  = new Date(now.getFullYear(), now.getMonth() + 1, 0);
  const nextStart = new Date(now.getFullYear(), now.getMonth() + 1, 1);
  const nextEnd   = new Date(now.getFullYear(), now.getMonth() + 2, 0);

  document.querySelectorAll('.event-card').forEach(function(card) {
    const cat      = card.dataset.cat  || '';
    const orgId    = card.dataset.org  || '0';
    const dateStr  = card.dataset.date || '';

    // Category filter
    const catOk = (_activeCat === 'all' || cat === _activeCat);

    // Date filter
    let dateOk = true;
    if (dateFilter && dateStr) {
      const d = new Date(dateStr + 'T00:00:00');
      if      (dateFilter === 'today')      dateOk = dateStr === todayStr;
      else if (dateFilter === 'week')       dateOk = d >= now && d <= weekEnd;
      else if (dateFilter === 'month')      dateOk = d >= now && d <= monthEnd;
      else if (dateFilter === 'next_month') dateOk = d >= nextStart && d <= nextEnd;
    }

    // Org filter
    const orgOk = !orgFilter || orgId === orgFilter;

    card.style.display = (catOk && dateOk && orgOk) ? 'flex' : 'none';
  });

  // Show empty state if nothing visible
  var feed = document.getElementById('eventsFeed');
  if (feed) {
    var visible = feed.querySelectorAll('.event-card[style*="flex"]').length +
                  feed.querySelectorAll('.event-card:not([style])').length;
    // recount properly
    visible = 0;
    feed.querySelectorAll('.event-card').forEach(function(c){ if(c.style.display !== 'none') visible++; });
    var noRes = document.getElementById('noResults');
    if (visible === 0) {
      if (!noRes) {
        noRes = document.createElement('div');
        noRes.id = 'noResults';
        noRes.style.cssText = 'text-align:center;padding:40px;color:var(--text-muted);font-size:14px;';
        noRes.innerHTML = '<i class="bi bi-funnel" style="font-size:32px;display:block;margin-bottom:10px;"></i>No events match your filters.';
        feed.after(noRes);
      }
    } else if (noRes) { noRes.remove(); }
  }
}

function resetFilters() {
  _activeCat = 'all';
  document.querySelectorAll('.cat-pill').forEach(p => p.classList.remove('active'));
  var allPill = document.getElementById('pill-all');
  if (allPill) allPill.classList.add('active');
  var fd = document.getElementById('filterDate');
  var fo = document.getElementById('filterOrg');
  if (fd) fd.value = '';
  if (fo) fo.value = '';
  applyFilters();
  updateCatHeader('all');
}


/* ══════════════════════════════════════════
   LIST / GRID VIEW TOGGLE
═══════════════════════════════════════════ */
function setView(type, btn) {
  document.querySelectorAll('.view-btn').forEach(b => b.classList.remove('active'));
  btn.classList.add('active');

  const feed = document.getElementById('eventsFeed');
  if (!feed) return;

  if (type === 'grid') {
    feed.style.display = 'grid';
    feed.style.gridTemplateColumns = 'repeat(auto-fill,minmax(260px,1fr))';
    feed.style.gap = '14px';
    document.querySelectorAll('.event-card').forEach(c => {
      c.style.flexDirection = 'column';
      const actions = c.querySelector('.event-actions');
      const iconCol = c.querySelector('.event-icon-col');
      if (actions) { actions.style.flexDirection = 'row'; actions.style.padding = '0 14px 14px'; }
      if (iconCol) { iconCol.style.width = '100%'; iconCol.style.height = '80px'; }
    });
  } else {
    feed.style.display = 'flex';
    feed.style.gridTemplateColumns = '';
    document.querySelectorAll('.event-card').forEach(c => {
      c.style.flexDirection = 'row';
      const actions = c.querySelector('.event-actions');
      const iconCol = c.querySelector('.event-icon-col');
      if (actions) { actions.style.flexDirection = 'column'; actions.style.padding = '14px 16px 14px 0'; }
      if (iconCol) { iconCol.style.width = '70px'; iconCol.style.height = ''; }
    });
  }
}


/* ══════════════════════════════════════════
   EVENT DETAIL MODAL
═══════════════════════════════════════════ */
function openModal(id) {
  const e = events[id];
  if (!e) return;

  document.getElementById('modalBanner').className      = 'modal-banner ' + e.bannerClass;
  document.getElementById('modalBanner').textContent    = e.emoji;
  document.getElementById('modalBadge').className       = 'event-cat-badge ' + e.badgeClass;
  document.getElementById('modalBadge').textContent     = e.catLabel;
  document.getElementById('modalTitle').textContent     = e.title;
  document.getElementById('modalDate').textContent      = e.date;
  document.getElementById('modalTime').textContent      = e.time;
  document.getElementById('modalVenue').textContent     = e.venue;
  document.getElementById('modalAttendees').textContent = e.attendees;
  document.getElementById('modalDesc').textContent      = e.desc;
  const orgEl = document.getElementById('modalOrg');
  if (orgEl) orgEl.textContent = e.org || 'WMSU';

  // Deadline notice
  var deadlineEl = document.getElementById('modalDeadline');
  if (deadlineEl) {
    if (e.regDeadline) {
      var dl = new Date(e.regDeadline + 'T23:59:59');
      var spanEl = deadlineEl.querySelector('span');
      if (spanEl) spanEl.textContent = 'Registration deadline: ' + dl.toLocaleDateString('en-US',{month:'short',day:'numeric',year:'numeric'});
      deadlineEl.style.display = 'flex';
    } else {
      deadlineEl.style.display = 'none';
    }
  }

  // Restriction notice banner
  var noticeEl = document.getElementById('modalRestrictionNotice');
  if (noticeEl) {
    if (e.isRestricted) {
      noticeEl.innerHTML = '<i class="bi bi-info-circle-fill" style="color:#92400e;font-size:16px;flex-shrink:0;"></i>'
        + '<div><strong>View Only</strong> — This event is exclusively for <strong>' + (e.restrictLabel || 'a specific department') + '</strong> students. You can view details but cannot register.</div>';
      noticeEl.style.display = 'flex';
    } else if (e.deadlinePassed) {
      noticeEl.innerHTML = '<i class="bi bi-calendar-x-fill" style="color:#b91c1c;font-size:16px;flex-shrink:0;"></i>'
        + '<div><strong>Registration Closed</strong> — The deadline for this event has passed.</div>';
      noticeEl.style.display = 'flex';
    } else if (e.isFull) {
      noticeEl.innerHTML = '<i class="bi bi-person-x-fill" style="color:#475569;font-size:16px;flex-shrink:0;"></i>'
        + '<div><strong>Event Full</strong> — All slots have been taken.</div>';
      noticeEl.style.display = 'flex';
    } else {
      noticeEl.style.display = 'none';
    }
  }

  // Join button state
  const joinBtn = document.getElementById('modalJoinBtn');
  joinBtn.dataset.id = id;
  joinBtn.disabled = false;
  joinBtn.style.opacity = '';
  joinBtn.style.cursor  = '';

  if (joined.has(id)) {
    joinBtn.classList.add('joined');
    joinBtn.innerHTML = '<i class="bi bi-check-circle me-1"></i>Registered!';
    joinBtn.disabled = false;
  } else if (!e.canRegister) {
    joinBtn.classList.remove('joined');
    if (e.isRestricted) {
      joinBtn.textContent = '🔒 Restricted – View Only';
    } else if (e.deadlinePassed) {
      joinBtn.textContent = '⏰ Registration Closed';
    } else if (e.isFull) {
      joinBtn.textContent = '❌ Event Full';
    } else {
      joinBtn.textContent = 'Cannot Register';
    }
    joinBtn.disabled = true;
    joinBtn.style.opacity = '0.6';
    joinBtn.style.cursor  = 'not-allowed';
  } else {
    joinBtn.classList.remove('joined');
    joinBtn.textContent = 'Register & Join';
  }

  const saveBtn = document.getElementById('modalSaveBtn');
  saveBtn.dataset.id = id;
  if (saved.has(id)) {
    saveBtn.innerHTML = '<i class="bi bi-bookmark-fill"></i> Saved';
    saveBtn.style.color = 'var(--red)';
    saveBtn.style.borderColor = 'var(--red)';
  } else {
    saveBtn.innerHTML = '<i class="bi bi-bookmark"></i> Save';
    saveBtn.style.color = '';
    saveBtn.style.borderColor = '';
  }

  const shareBtn = document.getElementById('modalShareBtn');
  if (shareBtn) shareBtn.dataset.id = id;

  document.getElementById('eventModal').classList.add('open');
  document.body.style.overflow = 'hidden';
}

function closeModal() {
  document.getElementById('eventModal').classList.remove('open');
  document.body.style.overflow = '';
}

function closeModalOutside(e) {
  if (e.target === document.getElementById('eventModal')) closeModal();
}

function toggleJoin(btn) {
  const id = Number(btn.dataset.id);
  btn.disabled = true;
  const fd = new FormData();
  fd.append('event_id', id);
  fetch('actions/toggle_join.php', { method: 'POST', body: fd })
    .then(r => r.json())
    .then(function(res) {
      if (!res.success) { showToast(res.msg || 'Error', 'warning', 'bi-exclamation-circle'); btn.disabled = false; return; }
      if (res.joined) {
        joined.add(id);
        btn.classList.add('joined');
        btn.innerHTML = '<i class="bi bi-check-circle me-1"></i>Registered!';
        showToast('Successfully registered! 🎉', 'success', 'bi-check-circle');
        // update attendee count in event data
        if (events[id]) {
          var cur = parseInt((events[id].attendees || '0'));
          events[id].attendees = (cur + 1) + ' attending';
          var el = document.getElementById('modalAttendees');
          if (el) el.textContent = events[id].attendees;
        }
      } else {
        joined.delete(id);
        btn.classList.remove('joined');
        btn.textContent = 'Register & Join';
        showToast('Registration cancelled', 'warning', 'bi-x-circle');
        if (events[id]) {
          var cur = parseInt((events[id].attendees || '1'));
          events[id].attendees = Math.max(0, cur - 1) + ' attending';
          var el = document.getElementById('modalAttendees');
          if (el) el.textContent = events[id].attendees;
        }
      }
      // sync card join button if visible
      var cardJoinBtn = document.querySelector('.event-card[data-id="' + id + '"] .btn-join');
      updateJoinedCount();
      renderMyEvents();
      btn.disabled = false;
    })
    .catch(function() { showToast('Network error', 'warning', 'bi-wifi-off'); btn.disabled = false; });
}

function updateJoinedCount() {
  const el = document.getElementById('statJoined');
  if (el) el.textContent = joined.size;
}

function toggleSaveModal(btn) {
  const id = Number(btn.dataset.id);
  _doToggleSave(id,
    function() { btn.innerHTML='<i class="bi bi-bookmark-fill"></i> Saved'; btn.style.color='var(--red)'; btn.style.borderColor='var(--red)'; },
    function() { btn.innerHTML='<i class="bi bi-bookmark"></i> Save'; btn.style.color=''; btn.style.borderColor=''; }
  );
}

/* Share event */
function shareEvent(btn) {
  const id = Number(btn.dataset.id);
  const e  = events[id];
  if (!e) return;
  const text = e.emoji + ' ' + e.title + '\n' +
    '\uD83D\uDCC5 ' + e.date + ' \u00B7 ' + e.time + '\n' +
    '\uD83D\uDCCD ' + e.venue + '\n\nCheck it out on CampusConnect!';
  if (navigator.share) {
    navigator.share({ title: e.title, text: text, url: window.location.href })
      .then(() => showToast('Event shared!', 'success', 'bi-share'))
      .catch(() => {});
  } else {
    navigator.clipboard.writeText(text).then(() => {
      showToast('Event details copied to clipboard!', 'success', 'bi-clipboard-check');
    }).catch(() => {
      showToast('Could not copy to clipboard', 'warning', 'bi-exclamation-circle');
    });
  }
}


/* ══════════════════════════════════════════
   SAVE / UNSAVE
═══════════════════════════════════════════ */
function _doToggleSave(id, onSaved, onUnsaved) {
  var fd = new FormData();
  fd.append('event_id', id);
  fetch('actions/toggle_save.php', { method: 'POST', body: fd })
    .then(function(r) { return r.json(); })
    .then(function(res) {
      if (!res.success) { showToast(res.msg || 'Error', 'warning', 'bi-exclamation-circle'); return; }
      if (res.saved) {
        saved.add(id);
        onSaved();
        const stat = document.getElementById('statSaved');
        if (stat) stat.textContent = saved.size;
        updateNavBadge(); renderMyEvents();
        showToast('Event saved!', 'success', 'bi-bookmark-check');
      } else {
        saved.delete(id);
        onUnsaved();
        const stat = document.getElementById('statSaved');
        if (stat) stat.textContent = saved.size;
        updateNavBadge(); renderMyEvents();
        showToast('Removed from saved events', 'warning', 'bi-bookmark-x');
      }
    })
    .catch(function() { showToast('Network error', 'warning', 'bi-wifi-off'); });
}

function saveEvent(id) {
  _doToggleSave(id,
    function() { var b=document.getElementById('save-'+id); if(b){b.classList.add('saved');b.innerHTML='<i class="bi bi-bookmark-fill"></i> Saved';} },
    function() { var b=document.getElementById('save-'+id); if(b){b.classList.remove('saved');b.innerHTML='<i class="bi bi-bookmark"></i> Save';} }
  );
}

function toggleSave(id, btn) {
  _doToggleSave(id,
    function() { if(btn){btn.classList.add('saved');btn.innerHTML='<i class="bi bi-bookmark-fill"></i> Saved';} },
    function() { if(btn){btn.classList.remove('saved');btn.innerHTML='<i class="bi bi-bookmark"></i> Save';} }
  );
}

function unsaveEvent(id) {
  _doToggleSave(id,
    function() { var b=document.getElementById('save-'+id); if(b){b.classList.add('saved');b.innerHTML='<i class="bi bi-bookmark-fill"></i> Saved';} },
    function() { var b=document.getElementById('save-'+id); if(b){b.classList.remove('saved');b.innerHTML='<i class="bi bi-bookmark"></i> Save';} }
  );
}

function updateNavBadge() {
  const badge = document.getElementById('myEventsCount');
  if (badge) badge.textContent = saved.size;
}


/* ══════════════════════════════════════════
   MY EVENTS — TABS & RENDER
═══════════════════════════════════════════ */
let myEventsTab = 'saved';

function switchMyTab(tab) {
  myEventsTab = tab;
  document.querySelectorAll('.my-tab-btn').forEach(b => b.classList.remove('active'));
  const btn = document.getElementById('tab-' + tab);
  if (btn) btn.classList.add('active');
  renderMyEvents();
}

function renderMyEvents() {
  const list  = document.getElementById('myEventsList');
  const empty = document.getElementById('emptyState');
  if (!list) return;

  fetch(`actions/get_my_events.php?tab=${myEventsTab}`)
    .then(r => r.json())
    .then(data => {
      // Update badges & stats
      const savedEl  = document.getElementById('tab-saved-count');
      const joinedEl = document.getElementById('tab-joined-count');
      const statSaved = document.getElementById('statSaved');
      const statJoined = document.getElementById('statJoined');
      if (data.success) {
        if (savedEl)  savedEl.textContent  = data.saved_count;
        if (joinedEl) joinedEl.textContent = data.joined_count;
        if (statSaved) statSaved.textContent = data.saved_count;
        if (statJoined) statJoined.textContent = data.joined_count;
      }

      if (!data.success || !data.events || data.events.length === 0) {
        if (empty) {
          empty.style.display = 'block';
          const emptyMsg = empty.querySelector('.empty-msg');
          if (emptyMsg) {
            emptyMsg.textContent = myEventsTab === 'joined'
              ? "You haven't registered for any events yet."
              : "No saved events yet. Browse Dashboard and click Save.";
          }
        }
        return;
      }

      if (empty) empty.style.display = 'none';

      list.querySelectorAll('.my-event-item').forEach(el => el.remove());

      data.events.forEach(e => {
        const catMap = {academic:'academic',social:'social',sports:'sports',org:'org'};
        const emojiMap = {academic:'🎓',social:'🎵',sports:'🏆',org:'🏛️'};
        const badgeClass = e.category ? (catMap[e.category.toLowerCase()] || 'org') : 'org';

        const div = document.createElement('div');
        div.className = 'my-event-item';
        div.innerHTML =
          '<div class="my-event-badge ' + badgeClass + '">' + (emojiMap[e.category?.toLowerCase()] || '📅') + '</div>' +
          '<div style="flex:1;min-width:0;">' +
            '<div class="my-event-name">' + e.title + '</div>' +
            '<div class="my-event-sub">' + new Date(e.event_date).toLocaleDateString('en-US', {weekday:'short', month:'short', day:'numeric'}) + 
            (e.event_time ? ' \u00B7 ' + e.event_time : '') + 
            ' \u00B7 ' + e.location + '</div>' +
    '<div style="margin-top:5px;display:flex;gap:6px;flex-wrap:wrap;">' +
      (myEventsTab === 'joined' ? '<span style="font-size:10px;padding:2px 8px;border-radius:10px;background:#ecfdf5;color:#059669;font-weight:600;"><i class="bi bi-check-circle me-1"></i>Registered</span>' : '') +
      (e.department_name ? '<span style="font-size:10px;padding:2px 8px;border-radius:10px;background:#dbeafe;color:#1d4ed8;font-weight:600;">' + e.department_name + ' Only</span>' : '') +
    '</div>' +

          '</div>' +
          '<div class="my-event-actions">' +
            '<button class="btn-details" onclick="openModal(' + e.id + ')"><i class="bi bi-eye me-1"></i>View</button>' +
            (myEventsTab === 'joined' ? '<button class="btn-details" style="background:#eff6ff;color:#3b82f6;border:1.5px solid #bfdbfe;" onclick="showMyQR(' + e.id + ', \'' + encodeURIComponent(e.title) + '\')"><i class="bi bi-qr-code"></i> My QR</button>' : '') +
            '<button class="btn-unsave" onclick="unsaveEvent(' + e.id + ')"><i class="bi bi-x-circle"></i> ' + (myEventsTab === 'joined' ? 'Cancel' : 'Remove') + '</button>' +
          '</div>';
        list.appendChild(div);
      });
    })
    .catch(err => {
      console.error('Failed to load my events:', err);
      showToast('Failed to load events', 'warning', 'bi-exclamation-circle');
    });
}



function cancelJoin(id) {
  var fd = new FormData(); fd.append('event_id', id);
  fetch('actions/toggle_join.php', { method: 'POST', body: fd })
    .then(function(r){ return r.json(); })
    .then(function(res){
      if (res.success) {
        joined.delete(id);
        updateJoinedCount(); renderMyEvents();
        showToast('Registration cancelled', 'warning', 'bi-x-circle');
      } else {
        showToast(res.msg || 'Error', 'warning', 'bi-exclamation-circle');
      }
    })
    .catch(function(){ showToast('Network error','warning','bi-wifi-off'); });
}

function clearAllSaved() {
  if (saved.size === 0) { showToast('Nothing to clear', 'info', 'bi-info-circle'); return; }
  if (!confirm('Remove all saved events?')) return;
  saved.forEach(id => {
    const btn = document.getElementById('save-' + id);
    if (btn) { btn.classList.remove('saved'); btn.innerHTML = '<i class="bi bi-bookmark"></i> Save'; }
  });
  saved.clear();
  persistState();
  updateNavBadge();
  renderMyEvents();
  showToast('All saved events cleared', 'warning', 'bi-trash');
}


/* ══════════════════════════════════════════
   ORG MODAL
═══════════════════════════════════════════ */
function openOrgModal(name, members, emoji, desc) {
  document.getElementById('orgModalBanner').textContent  = emoji;
  document.getElementById('orgModalName').textContent    = name;
  document.getElementById('orgModalMembers').textContent = members;
  document.getElementById('orgModalDesc').textContent    = desc;

  const btn = document.getElementById('orgJoinBtn');
  btn.dataset.org = name;

  if (joinedOrgs.has(name)) {
    btn.classList.add('joined');
    btn.innerHTML = '<i class="bi bi-check-circle me-1"></i>Member';
  } else {
    btn.classList.remove('joined');
    btn.textContent = 'Join Organization';
  }

  document.getElementById('orgModal').classList.add('open');
  document.body.style.overflow = 'hidden';
}

function closeOrgModal() {
  document.getElementById('orgModal').classList.remove('open');
  document.body.style.overflow = '';
}

function closeOrgModalOutside(e) {
  if (e.target === document.getElementById('orgModal')) closeOrgModal();
}

function toggleOrgJoin(btn) {
  const name = btn.dataset.org;
  if (joinedOrgs.has(name)) {
    joinedOrgs.delete(name);
    persistState();
    btn.classList.remove('joined');
    btn.textContent = 'Join Organization';
    showToast('Left ' + name, 'warning', 'bi-x-circle');
  } else {
    joinedOrgs.add(name);
    persistState();
    btn.classList.add('joined');
    btn.innerHTML = '<i class="bi bi-check-circle me-1"></i>Member';
    showToast('You joined ' + name + '! 🎉', 'success', 'bi-check-circle');
    setTimeout(closeOrgModal, 1200);
  }
}


/* ══════════════════════════════════════════
   NOTIFICATIONS
═══════════════════════════════════════════ */
function toggleNotif() {
  const panel = document.getElementById('notifPanel');
  panel.classList.toggle('open');
  if (panel.classList.contains('open')) updateNotifDot();
}

function markAllRead() {
  document.querySelectorAll('.notif-item').forEach(n => {
    const id = parseInt(n.id.replace('notif', ''));
    readNotifs.add(id);
    n.classList.remove('unread');
    const dot = n.querySelector('.notif-unread-dot');
    if (dot) dot.remove();
  });
  persistState();
  updateNotifDot();
  showToast('All notifications marked as read', 'success', 'bi-check-all');
}

function markOneRead(notifId) {
  readNotifs.add(notifId);
  persistState();
  const item = document.getElementById('notif' + notifId);
  if (item) {
    item.classList.remove('unread');
    const dot = item.querySelector('.notif-unread-dot');
    if (dot) dot.remove();
  }
  updateNotifDot();
}

function dismissNotif(notifId, e) {
  e.stopPropagation();
  const item = document.getElementById('notif' + notifId);
  if (item) {
    item.style.transition = 'opacity .25s, transform .25s';
    item.style.opacity = '0';
    item.style.transform = 'translateX(20px)';
    setTimeout(() => item.remove(), 260);
  }
  readNotifs.add(notifId);
  persistState();
  setTimeout(updateNotifDot, 300);
}

function updateNotifDot() {
  const unread = document.querySelectorAll('.notif-item.unread').length;
  const dot = document.getElementById('notifDot');
  if (dot) dot.style.display = unread > 0 ? 'block' : 'none';
}

function openNotifEvent(id) {
  toggleNotif();
  setTimeout(() => openModal(id), 200);
}


/* ══════════════════════════════════════════
   PROFILE MODAL
═══════════════════════════════════════════ */
function openProfile() {
  const modal = document.getElementById('profileModal');
  if (!modal) return;
  loadProfileValues();
  modal.classList.add('open');
  document.body.style.overflow = 'hidden';
}

function closeProfile() {
  const modal = document.getElementById('profileModal');
  if (!modal) return;
  modal.classList.remove('open');
  document.body.style.overflow = '';
}

function closeProfileOutside(e) {
  if (e.target === document.getElementById('profileModal')) closeProfile();
}

function loadProfileValues() {
  const stored = localStorage.getItem('cc_profile');
  if (!stored) return;
  try {
    const p = JSON.parse(stored);
    if (p.name)   document.getElementById('profileName').value   = p.name;
    if (p.course) document.getElementById('profileCourse').value = p.course;
    if (p.year)   document.getElementById('profileYear').value   = p.year;
    if (p.email)  document.getElementById('profileEmail').value  = p.email;
    if (p.bio)    document.getElementById('profileBio').value    = p.bio;
  } catch(err) {}
}

function saveProfile(e) {
  e.preventDefault();
  const name   = document.getElementById('profileName').value.trim();
  const course = document.getElementById('profileCourse').value.trim();
  const year   = document.getElementById('profileYear').value;
  const email  = document.getElementById('profileEmail').value.trim();
  const bio    = document.getElementById('profileBio').value.trim();

  if (!name)  { showToast('Name is required', 'warning', 'bi-exclamation-circle'); return; }
  if (!email) { showToast('Email is required', 'warning', 'bi-exclamation-circle'); return; }
  if (!email.includes('@')) { showToast('Please enter a valid email', 'warning', 'bi-exclamation-circle'); return; }

  const profile = { name, course, year, email, bio };
  localStorage.setItem('cc_profile', JSON.stringify(profile));

  /* Update navbar */
  const avatarName = document.querySelector('.avatar-name');
  if (avatarName) avatarName.textContent = name;
  const avatarRole = document.querySelector('.avatar-role');
  if (avatarRole && year && course) avatarRole.textContent = year + ' \u00B7 ' + course;
  document.querySelectorAll('.avatar').forEach(a => { a.textContent = name.charAt(0).toUpperCase(); });

  closeProfile();
  showToast('Profile updated successfully!', 'success', 'bi-person-check');
}

function loadProfile() {
  const stored = localStorage.getItem('cc_profile');
  if (!stored) return;
  try {
    const p = JSON.parse(stored);
    const avatarName = document.querySelector('.avatar-name');
    if (avatarName && p.name) avatarName.textContent = p.name;
    const avatarRole = document.querySelector('.avatar-role');
    if (avatarRole && p.year && p.course) avatarRole.textContent = p.year + ' \u00B7 ' + p.course;
    document.querySelectorAll('.avatar').forEach(a => { if (p.name) a.textContent = p.name.charAt(0).toUpperCase(); });
  } catch(err) {}
}


/* ══════════════════════════════════════════
   SETTINGS MODAL
═══════════════════════════════════════════ */
function openSettings() {
  const modal = document.getElementById('settingsModal');
  if (!modal) return;
  loadSettingsValues();
  modal.classList.add('open');
  document.body.style.overflow = 'hidden';
}

function closeSettings() {
  const modal = document.getElementById('settingsModal');
  if (!modal) return;
  modal.classList.remove('open');
  document.body.style.overflow = '';
}

function closeSettingsOutside(e) {
  if (e.target === document.getElementById('settingsModal')) closeSettings();
}

function loadSettingsValues() {
  const prefs = JSON.parse(localStorage.getItem('cc_settings') || '{}');
  const ids = ['settingEmailNotif','settingPushNotif','settingDarkMode','settingEventRemind','settingPrivProfile'];
  const defaults = { settingEmailNotif: true, settingPushNotif: true, settingDarkMode: false, settingEventRemind: true, settingPrivProfile: false };
  ids.forEach(id => {
    const el = document.getElementById(id);
    const key = id.replace('setting','').replace(/^./, c => c.toLowerCase());
    if (el) el.checked = prefs[key] !== undefined ? prefs[key] : defaults[id];
  });
}

function saveSettings(e) {
  e.preventDefault();
  const prefs = {
    emailNotif:  document.getElementById('settingEmailNotif')?.checked  ?? true,
    pushNotif:   document.getElementById('settingPushNotif')?.checked   ?? true,
    darkMode:    document.getElementById('settingDarkMode')?.checked    ?? false,
    eventRemind: document.getElementById('settingEventRemind')?.checked ?? true,
    privProfile: document.getElementById('settingPrivProfile')?.checked ?? false,
  };
  localStorage.setItem('cc_settings', JSON.stringify(prefs));
  if (prefs.darkMode) {
    document.body.classList.add('dark-mode');
  } else {
    document.body.classList.remove('dark-mode');
  }
  closeSettings();
  showToast('Settings saved!', 'success', 'bi-gear-fill');
}

function applySettings() {
  const prefs = JSON.parse(localStorage.getItem('cc_settings') || '{}');
  if (prefs.darkMode) document.body.classList.add('dark-mode');
}


/* ══════════════════════════════════════════
   TOAST
═══════════════════════════════════════════ */
function showToast(msg, type, icon) {
  type = type || 'success';
  icon = icon || 'bi-check-circle';
  const c = document.getElementById('toastContainer');
  if (!c) return;
  const t = document.createElement('div');
  t.className = 'toast ' + type;
  t.innerHTML = '<i class="bi ' + icon + '"></i>' + msg;
  c.appendChild(t);
  setTimeout(function() {
    t.style.opacity    = '0';
    t.style.transition = 'opacity .3s';
    setTimeout(function() { t.remove(); }, 300);
  }, 2800);
}


/* ══════════════════════════════════════════
   SEARCH
═══════════════════════════════════════════ */
function handleSearch(val) {
  const q = val.toLowerCase().trim();

  // If search cleared, restore filters
  if (!q) {
    applyFilters();
    var noRes = document.getElementById('noResults');
    if (noRes) noRes.remove();
    return;
  }

  // Stack search on top of active filters
  const dateFilter = (document.getElementById('filterDate') || {}).value || '';
  const orgFilter  = (document.getElementById('filterOrg')  || {}).value || '';
  const now        = new Date();
  const todayStr   = now.toISOString().slice(0,10);
  const weekEnd    = new Date(now); weekEnd.setDate(now.getDate() + 7);
  const monthEnd   = new Date(now.getFullYear(), now.getMonth() + 1, 0);
  const nextStart  = new Date(now.getFullYear(), now.getMonth() + 1, 1);
  const nextEnd    = new Date(now.getFullYear(), now.getMonth() + 2, 0);

  let count = 0;
  document.querySelectorAll('.event-card').forEach(function(card) {
    const title   = (card.querySelector('.event-title-text') || {}).textContent || '';
    const meta    = (card.querySelector('.event-meta-row')   || {}).textContent || '';
    const cat     = card.dataset.cat  || '';
    const orgId   = card.dataset.org  || '0';
    const dateStr = card.dataset.date || '';

    const searchOk = title.toLowerCase().includes(q) || meta.toLowerCase().includes(q);
    const catOk    = (_activeCat === 'all' || cat === _activeCat);
    let   dateOk   = true;
    if (dateFilter && dateStr) {
      const d = new Date(dateStr + 'T00:00:00');
      if      (dateFilter === 'today')      dateOk = dateStr === todayStr;
      else if (dateFilter === 'week')       dateOk = d >= now && d <= weekEnd;
      else if (dateFilter === 'month')      dateOk = d >= now && d <= monthEnd;
      else if (dateFilter === 'next_month') dateOk = d >= nextStart && d <= nextEnd;
    }
    const orgOk  = !orgFilter || orgId === orgFilter;
    const show   = searchOk && catOk && dateOk && orgOk;
    card.style.display = show ? 'flex' : 'none';
    if (show) count++;
  });

  var noRes = document.getElementById('noResults');
  if (count === 0) {
    if (!noRes) {
      noRes = document.createElement('div');
      noRes.id = 'noResults';
      noRes.style.cssText = 'text-align:center;padding:40px;color:var(--text-muted);font-size:14px;';
      noRes.innerHTML = '<i class="bi bi-search" style="font-size:32px;display:block;margin-bottom:10px;"></i>No events found for <strong>' + val + '</strong>';
      var feed = document.getElementById('eventsFeed');
      if (feed) feed.after(noRes);
    }
  } else if (noRes) {
    noRes.remove();
  }
}

function clearSearch() {
  var input = document.getElementById('searchInput');
  if (input) { input.value = ''; applyFilters(); input.focus(); }
}


/* ══════════════════════════════════════════
   LOGOUT
═══════════════════════════════════════════ */
function confirmLogout() {
  if (confirm('Are you sure you want to sign out?')) {
    showToast('Signing out...', 'info', 'bi-box-arrow-right');
    window.location.href = '../logout.php';
  }
}


/* ══════════════════════════════════════════
   CALENDAR EVENT POPUP
═══════════════════════════════════════════ */
function showCalPopup(triggerEl, eventId) {
  var old = document.getElementById('calPopup');
  if (old) old.remove();

  var e = events[eventId];
  if (!e) return;

  var badgeMap = {
    academic: '<span class="cal-popup-cat badge-academic">Academic</span>',
    social:   '<span class="cal-popup-cat badge-social">Social</span>',
    sports:   '<span class="cal-popup-cat badge-sports">Sports</span>',
    org:      '<span class="cal-popup-cat badge-org">Organizations</span>',
  };
  var badgeHtml = badgeMap[e.cat] || '';
  var isJoined  = joined.has(eventId);

  var popup = document.createElement('div');
  popup.id        = 'calPopup';
  popup.className = 'cal-event-popup';
  popup.innerHTML =
    '<div class="cal-popup-banner ' + e.bannerClass + '">' + e.emoji + '</div>' +
    badgeHtml +
    '<div class="cal-popup-title">' + e.title + '</div>' +
    '<div class="cal-popup-meta">' +
      '<span><i class="bi bi-calendar3" style="color:var(--red)"></i> ' + e.date + '</span>' +
      '<span><i class="bi bi-clock" style="color:var(--red)"></i> ' + e.time + '</span>' +
      '<span><i class="bi bi-geo-alt" style="color:var(--red)"></i> ' + e.venue + '</span>' +
      '<span><i class="bi bi-people" style="color:var(--red)"></i> ' + e.attendees + '</span>' +
    '</div>' +
    '<div style="display:flex;gap:6px;margin-top:4px;">' +
      '<button class="cal-popup-btn" style="flex:1;" onclick="openModal(' + eventId + ');document.getElementById(\'calPopup\').remove()">' +
        '<i class="bi bi-eye me-1"></i>View Details</button>' +
      '<button class="cal-popup-btn" id="calQuickJoin' + eventId + '" ' +
        'style="background:' + (isJoined ? '#ecfdf5' : 'var(--red)') + ';color:' + (isJoined ? '#059669' : '#fff') + ';" ' +
        'onclick="quickJoinFromCal(' + eventId + ',this)" title="' + (isJoined ? 'Cancel registration' : 'Register') + '">' +
        '<i class="bi bi-' + (isJoined ? 'check-circle' : 'plus-circle') + '"></i>' +
      '</button>' +
    '</div>';

  document.body.appendChild(popup);

  var rect = triggerEl.getBoundingClientRect();
  var pw   = popup.offsetWidth;
  var left = rect.left + rect.width / 2 - pw / 2 + window.scrollX;
  var top  = rect.top  - popup.offsetHeight - 12  + window.scrollY;

  left = Math.max(10, Math.min(left, window.innerWidth - pw - 10));
  if (top < window.scrollY + 10) top = rect.bottom + 12 + window.scrollY;

  popup.style.left     = left + 'px';
  popup.style.top      = top  + 'px';
  popup.style.position = 'absolute';
}

function quickJoinFromCal(id, btn) {
  if (joined.has(id)) {
    joined.delete(id);
    persistState();
    btn.style.background = 'var(--red)';
    btn.style.color = '#fff';
    btn.innerHTML = '<i class="bi bi-plus-circle"></i>';
    btn.title = 'Register';
    updateJoinedCount();
    showToast('Registration cancelled', 'warning', 'bi-x-circle');
  } else {
    joined.add(id);
    persistState();
    btn.style.background = '#ecfdf5';
    btn.style.color = '#059669';
    btn.innerHTML = '<i class="bi bi-check-circle"></i>';
    btn.title = 'Cancel registration';
    updateJoinedCount();
    showToast('Registered for ' + events[id].title + '! 🎉', 'success', 'bi-check-circle');
  }
}


/* ══════════════════════════════════════════
   MINI CALENDAR
═══════════════════════════════════════════ */
var calYear  = 2026;
var calMonth = 3; // April (0-indexed)

var miniCalEvents = {
  '2026-2-18': { id: 1, title: 'Research Summit 2025' },
  '2026-2-20': { id: 2, title: 'Campus Music Fest' },
  '2026-2-22': { id: 3, title: 'Intramurals Opening' },
  '2026-3-2':  { id: 4, title: 'Scholarship Fair' },
  '2026-3-5':  { id: 5, title: 'CSS Society GA' },
};

var monthNames = [
  'January','February','March','April','May','June',
  'July','August','September','October','November','December'
];

function renderMiniCal() {
  var grid = document.getElementById('miniCalGrid');
  if (!grid) return;

  document.getElementById('miniCalMonth').textContent = monthNames[calMonth] + ' ' + calYear;

  var firstDay    = new Date(calYear, calMonth, 1).getDay();
  var daysInMonth = new Date(calYear, calMonth + 1, 0).getDate();
  var today       = new Date();

  var html = ['Su','Mo','Tu','We','Th','Fr','Sa']
    .map(function(d) { return '<div class="mini-cal-day-label">' + d + '</div>'; })
    .join('');

  for (var i = 0; i < firstDay; i++) html += '<div></div>';

  for (var d = 1; d <= daysInMonth; d++) {
    var key     = calYear + '-' + calMonth + '-' + d;
    var isToday = today.getFullYear() === calYear && today.getMonth() === calMonth && today.getDate() === d;
    var ev      = miniCalEvents[key];

    if (ev) {
      html += '<div class="mini-cal-day' + (isToday ? ' today' : '') + ' has-event" ' +
        'onclick="openModal(' + ev.id + ')" title="' + ev.title + '" style="cursor:pointer">' +
        d + '<span class="mini-day-tooltip">' + ev.title + '</span></div>';
    } else {
      html += '<div class="mini-cal-day' + (isToday ? ' today' : '') + '" title="' + d + ' ' + monthNames[calMonth] + '">' + d + '</div>';
    }
  }

  grid.innerHTML = html;
}

function calPrev() {
  calMonth--;
  if (calMonth < 0) { calMonth = 11; calYear--; }
  renderMiniCal();
}

function calNext() {
  calMonth++;
  if (calMonth > 11) { calMonth = 0; calYear++; }
  renderMiniCal();
}


/* ══════════════════════════════════════════
   KEYBOARD SHORTCUTS
═══════════════════════════════════════════ */
document.addEventListener('keydown', function(e) {
  if (e.key === 'Escape') {
    closeModal();
    closeOrgModal();
    closeProfile();
    closeSettings();
    var notif = document.getElementById('notifPanel');
    if (notif) notif.classList.remove('open');
    var popup = document.getElementById('calPopup');
    if (popup) popup.remove();
  }
  if ((e.ctrlKey || e.metaKey) && e.key === 'k') {
    e.preventDefault();
    var input = document.getElementById('searchInput');
    if (input) input.focus();
  }
});

document.addEventListener('click', function(e) {
  var popup = document.getElementById('calPopup');
  if (popup && !popup.contains(e.target) && !e.target.closest('.fc-event')) popup.remove();
});


/* ══════════════════════════════════════════
   INIT
═══════════════════════════════════════════ */
function initPageState() {
  saved.forEach(function(id) {
    var btn = document.getElementById('save-' + id);
    if (btn) { btn.classList.add('saved'); btn.innerHTML = '<i class="bi bi-bookmark-fill"></i> Saved'; }
  });
  var statSaved  = document.getElementById('statSaved');
  var statJoined = document.getElementById('statJoined');
  if (statSaved)  statSaved.textContent  = saved.size;
  if (statJoined) statJoined.textContent = joined.size;

  updateNavBadge();
  updateNotifDot();
  loadProfile();
  applySettings();

  readNotifs.forEach(function(id) {
    var item = document.getElementById('notif' + id);
    if (item) {
      item.classList.remove('unread');
      var dot = item.querySelector('.notif-unread-dot');
      if (dot) dot.remove();
    }
  });
}

document.addEventListener('DOMContentLoaded', function() {
  initPageState();
  renderMiniCal();
  if (document.getElementById('myEventsSection')) renderMyEvents();
  
  // Auto-filter from URL ?cat=academic
  const urlParams = new URLSearchParams(window.location.search);
  const cat = urlParams.get('cat');
  if (cat && ['all','academic','social','sports','org'].includes(cat)) {
    setTimeout(() => filterCat(null, cat), 100);
  }
});

// ── QR CODE DISPLAY ──────────────────────────────────────────
function showMyQR(eventId, eventTitle) {
  fetch("actions/get_my_qr.php?event_id=" + eventId)
    .then(r => r.json())
    .then(data => {
      if (!data.success || !data.token) {
        showToast("No QR code found for this event.", "warning", "bi-exclamation-circle");
        return;
      }
      // Build scan URL
      var scanUrl = window.location.origin + "/CAMPUS_CONNECT/staff/actions/scan_qr.php?token=" + data.token;
      var qrApiUrl = "https://chart.googleapis.com/chart?chs=240x240&cht=qr&chl=" + encodeURIComponent(scanUrl) + "&choe=UTF-8";

      // Show in a simple modal
      var overlay = document.getElementById("qrModalOverlay");
      var img     = document.getElementById("qrModalImage");
      var title   = document.getElementById("qrModalTitle");
      if (!overlay) {
        overlay = document.createElement("div");
        overlay.id = "qrModalOverlay";
        overlay.style.cssText = "position:fixed;inset:0;background:rgba(0,0,0,.6);z-index:9000;display:flex;align-items:center;justify-content:center;";
        overlay.innerHTML =
          "<div style=\"background:#fff;border-radius:20px;padding:32px;text-align:center;max-width:360px;width:92%;position:relative;\">" +
          "<button onclick=\"document.getElementById(qrModalOverlay).remove()\" style=\"position:absolute;top:12px;right:14px;background:none;border:none;font-size:22px;cursor:pointer;color:#6b7280;\">&times;</button>" +
          "<h3 id=\"qrModalTitle\" style=\"font-size:15px;font-weight:700;color:#111827;margin-bottom:4px;\"></h3>" +
          "<p style=\"font-size:12px;color:#9ca3af;margin-bottom:18px;\">Show this QR code to the event staff</p>" +
          "<div style=\"display:inline-block;border:1px solid #e5e7eb;border-radius:12px;padding:12px;\"><img id=\"qrModalImage\" src=\"\" style=\"width:240px;height:240px;display:block;\"></div>" +
          "<p style=\"font-size:11px;color:#9ca3af;margin-top:14px;\">Your personal attendance token — keep it safe</p>" +
          "</div>";
        document.body.appendChild(overlay);
      }
      document.getElementById("qrModalTitle").textContent = decodeURIComponent(eventTitle);
      document.getElementById("qrModalImage").src = qrApiUrl;
      overlay.style.display = "flex";
    })
    .catch(function() { showToast("Failed to load QR code", "warning", "bi-exclamation-circle"); });
}

