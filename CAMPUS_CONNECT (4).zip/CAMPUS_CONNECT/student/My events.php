<?php
/**
 * My events.php — Student My Events Page (fully server-driven)
 *
 * Tabs:  Registered | Saved | Attended
 * Filter: All | Upcoming | Past
 * Actions: View Details | My QR (registered) | Remove/Unsave | Cancel Registration
 */

if (session_status() === PHP_SESSION_NONE) session_start();
require_once '../config.php';
require_once '../db_functions.php';
require_login('student');

$user_id = (int)$_SESSION['user_id'];
$student = get_user($pdo, $user_id);

if (!$student) { session_destroy(); header('Location: ../login.php'); exit; }

$studentName      = $student['full_name'] ?? 'Student';
$studentFirstName = explode(' ', $studentName)[0];
$studentInitial   = strtoupper(substr($studentName, 0, 1));

$deptCode  = $student['dept_code'] ?? '';
$yearLevel = $student['year_level'] ?? '';
$course    = $student['course'] ?? '';
if ($deptCode === 'CICT') $deptCode = 'CCS';
$courseMap = ['information technology'=>'BSIT','computer science'=>'BSCS','information systems'=>'BSIS','nursing'=>'BSN','education'=>'BSED','criminology'=>'BSCrim','engineering'=>'BSENG','social work'=>'BSSW','medicine'=>'MD','law'=>'JD'];
$courseLabel = '';
if ($course) {
    $cl = strtolower($course);
    foreach ($courseMap as $kw => $ab) { if (strpos($cl,$kw)!==false){$courseLabel=$ab;break;} }
    if (!$courseLabel) { preg_match_all('/\b[A-Z]/',$course,$m); $courseLabel=implode('',$m[0])?:$deptCode?:'WMSU'; }
} else { $courseLabel=$deptCode?:'WMSU'; }
$studentYear = trim($yearLevel.($yearLevel&&$courseLabel?' · ':'').$courseLabel,' · ');
$activePage  = 'myEvents';
?>
<?php include 'Header.php'; ?>
<body>
<div class="toast-container" id="toastContainer"></div>
<?php include 'Modals.php'; ?>
<?php include 'Navbar.php'; ?>
<?php include 'Notification.php'; ?>

<div class="layout">
  <?php include 'Sidebar.php'; ?>

  <main class="main">
  <div id="myEventsSection" class="section active">

    <!-- ── Page header ───────────────────────────────────── -->
    <div class="page-header" style="margin-bottom:20px;">
      <div>
        <div class="page-title"><i class="bi bi-bookmark-heart me-2" style="color:var(--red)"></i>My Events</div>
        <div class="page-sub">Your registered, saved, and attended events</div>
      </div>
    </div>

    <!-- ── Stat cards ─────────────────────────────────────── -->
    <div class="stat-row" style="margin-bottom:24px;">
      <div class="stat-card" style="cursor:pointer" onclick="switchTab('registered')">
        <div class="stat-icon green"><i class="bi bi-check-circle"></i></div>
        <div>
          <div class="stat-num" id="statRegistered">—</div>
          <div class="stat-label">Registered</div>
        </div>
      </div>
      <div class="stat-card" style="cursor:pointer" onclick="switchTab('saved')">
        <div class="stat-icon blue"><i class="bi bi-bookmark-check"></i></div>
        <div>
          <div class="stat-num" id="statSaved">—</div>
          <div class="stat-label">Saved</div>
        </div>
      </div>
      <div class="stat-card" style="cursor:pointer" onclick="switchTab('attended')">
        <div class="stat-icon purple"><i class="bi bi-patch-check"></i></div>
        <div>
          <div class="stat-num" id="statAttended">—</div>
          <div class="stat-label">Attended</div>
        </div>
      </div>
    </div>

    <!-- ── Tabs + filter bar ──────────────────────────────── -->
    <div style="display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:12px;margin-bottom:0;">

      <!-- Tab buttons -->
      <div style="display:flex;gap:0;border-bottom:2px solid var(--border);flex:1;min-width:260px;">
        <button id="tab-btn-registered" class="me-tab active" onclick="switchTab('registered')">
          <i class="bi bi-check-circle me-1"></i>Registered
          <span class="me-count" id="cnt-registered">0</span>
        </button>
        <button id="tab-btn-saved" class="me-tab" onclick="switchTab('saved')">
          <i class="bi bi-bookmark me-1"></i>Saved
          <span class="me-count" id="cnt-saved">0</span>
        </button>
        <button id="tab-btn-attended" class="me-tab" onclick="switchTab('attended')">
          <i class="bi bi-patch-check me-1"></i>Attended
          <span class="me-count" id="cnt-attended">0</span>
        </button>
      </div>

      <!-- Date filter -->
      <div style="display:flex;align-items:center;gap:8px;flex-shrink:0;">
        <select id="meFilter" onchange="applyFilter()" style="padding:7px 12px;border:1.5px solid var(--border);border-radius:8px;font-size:12.5px;font-family:Poppins,sans-serif;background:#fff;color:var(--text-primary);cursor:pointer;">
          <option value="all">📅 All Dates</option>
          <option value="upcoming">🔜 Upcoming</option>
          <option value="past">🕐 Past</option>
        </select>
      </div>
    </div>

    <!-- ── Event list ─────────────────────────────────────── -->
    <div id="meList" style="margin-top:18px;">
      <!-- Skeleton while loading -->
      <div id="meSkeleton">
        <?php for($i=0;$i<3;$i++): ?>
        <div style="background:#fff;border:1.5px solid var(--border);border-radius:12px;padding:18px;margin-bottom:12px;display:flex;gap:14px;align-items:center;animation:pulse 1.5s infinite;">
          <div style="width:48px;height:48px;border-radius:10px;background:#f1f5f9;flex-shrink:0;"></div>
          <div style="flex:1;">
            <div style="height:14px;background:#f1f5f9;border-radius:6px;width:60%;margin-bottom:8px;"></div>
            <div style="height:11px;background:#f1f5f9;border-radius:6px;width:40%;"></div>
          </div>
        </div>
        <?php endfor; ?>
      </div>

      <div id="meCards" style="display:none;"></div>

      <!-- Empty state -->
      <div id="meEmpty" style="display:none;text-align:center;padding:60px 20px;">
        <i class="bi bi-calendar-x" style="font-size:48px;color:var(--text-muted);display:block;margin-bottom:12px;"></i>
        <h3 style="font-size:16px;font-weight:600;color:var(--text-primary);margin-bottom:6px;" id="meEmptyTitle">Nothing here yet</h3>
        <p style="font-size:13px;color:var(--text-muted);" id="meEmptyMsg">
          Go to the <a href="student.php" style="color:var(--red);font-weight:500;">Dashboard</a> to discover events.
        </p>
      </div>
    </div>

  </div><!-- /#myEventsSection -->
  </main>
</div>

<!-- ── Inline styles ──────────────────────────────────────── -->
<style>
@keyframes pulse { 0%,100%{opacity:1} 50%{opacity:.5} }

/* Tabs */
.me-tab {
  padding: 10px 20px;
  border: none; border-bottom: 2.5px solid transparent;
  background: none; font-size: 13px; font-weight: 600;
  cursor: pointer; color: var(--text-secondary);
  margin-bottom: -2px; transition: all .15s;
  display: flex; align-items: center; gap: 5px;
}
.me-tab.active { color: var(--red); border-bottom-color: var(--red); }
.me-tab:hover:not(.active) { color: var(--text-primary); }

.me-count {
  font-size: 10px; font-weight: 700;
  padding: 1px 7px; border-radius: 10px;
  background: #e5e7eb; color: #374151;
}
.me-tab.active .me-count { background: var(--red); color: #fff; }

/* Event card */
.me-card {
  background: #fff;
  border: 1.5px solid var(--border);
  border-radius: 12px;
  padding: 16px 18px;
  margin-bottom: 10px;
  display: flex; gap: 14px; align-items: flex-start;
  transition: box-shadow .2s;
}
.me-card:hover { box-shadow: 0 4px 16px rgba(0,0,0,.07); }

.me-icon {
  width: 46px; height: 46px; border-radius: 10px;
  display: flex; align-items: center; justify-content: center;
  font-size: 20px; flex-shrink: 0;
}
.me-icon.academic { background:#ede9fe; color:#7c3aed; }
.me-icon.social   { background:#fce7f3; color:#db2777; }
.me-icon.sports   { background:#fef3c7; color:#d97706; }
.me-icon.org      { background:#dbeafe; color:#2563eb; }
.me-icon.default  { background:#f1f5f9; color:#64748b; }

.me-info { flex: 1; min-width: 0; }
.me-title { font-size: 14px; font-weight: 700; color: var(--text-primary); margin-bottom: 4px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
.me-meta  { font-size: 12px; color: var(--text-muted); display: flex; flex-wrap: wrap; gap: 10px; margin-bottom: 8px; }
.me-meta span { display: flex; align-items: center; gap: 3px; }

.me-badge {
  display: inline-flex; align-items: center; gap: 4px;
  font-size: 10.5px; font-weight: 600;
  padding: 2px 9px; border-radius: 99px;
}
.me-badge.registered { background:#dcfce7; color:#166534; }
.me-badge.saved      { background:#eff6ff; color:#1d4ed8; }
.me-badge.attended   { background:#f3e8ff; color:#7c3aed; }
.me-badge.absent     { background:#fee2e2; color:#b91c1c; }
.me-badge.upcoming   { background:#fef3c7; color:#92400e; }
.me-badge.cert       { background:#ecfdf5; color:#059669; }

/* Action buttons */
.me-actions { display: flex; flex-direction: column; gap: 6px; min-width: 110px; }
.me-btn {
  padding: 7px 12px; border-radius: 8px; font-size: 11.5px;
  font-weight: 600; border: 1.5px solid var(--border);
  cursor: pointer; display: flex; align-items: center;
  justify-content: center; gap: 5px; white-space: nowrap;
  transition: all .15s; background: #fff; color: var(--text-primary);
}
.me-btn:hover { background: #f9fafb; }
.me-btn.danger { color: #dc2626; border-color: #fecaca; }
.me-btn.danger:hover { background: #fef2f2; border-color: #dc2626; }
.me-btn.primary { background: var(--red); color: #fff; border-color: var(--red); }
.me-btn.primary:hover { opacity: .88; }
.me-btn.blue { background: #eff6ff; color: #2563eb; border-color: #bfdbfe; }
.me-btn.blue:hover { background: #dbeafe; }
</style>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="App.js"></script>
<script>
/* ══════════════════════════════════════════════
   MY EVENTS PAGE — fully server-driven
══════════════════════════════════════════════ */
var meTab    = 'registered';
var meFilter = 'all';

var catIcon = {
  academic: {icon:'bi-mortarboard', cls:'academic', emoji:'🎓'},
  social:   {icon:'bi-music-note',  cls:'social',   emoji:'🎵'},
  sports:   {icon:'bi-trophy',      cls:'sports',   emoji:'🏆'},
  org:      {icon:'bi-people',      cls:'org',      emoji:'🏛️'},
};
function getCatInfo(cat) {
  var c = (cat||'').toLowerCase();
  if (c.includes('academic')||c.includes('seminar')||c.includes('workshop')||c.includes('research')) return catIcon.academic;
  if (c.includes('social')||c.includes('cultural')||c.includes('music')) return catIcon.social;
  if (c.includes('sport')||c.includes('athletic')||c.includes('intramural')) return catIcon.sports;
  return catIcon.org;
}
function fmtDate(str) {
  if (!str) return '—';
  var d = new Date(str);
  return d.toLocaleDateString('en-US',{weekday:'short',month:'short',day:'numeric',year:'numeric'});
}
function fmtTime(str) {
  if (!str) return '';
  var d = new Date(str);
  return d.toLocaleTimeString('en-US',{hour:'numeric',minute:'2-digit'});
}
function fmtDateTime(str) {
  if (!str) return '—';
  var d = new Date(str);
  return d.toLocaleString('en-US',{month:'short',day:'numeric',hour:'numeric',minute:'2-digit'});
}
function isPast(dateStr) {
  return dateStr && new Date(dateStr) < new Date();
}

/* ── Tab switching ─────────────────────────────────────────── */
function switchTab(tab) {
  meTab = tab;
  document.querySelectorAll('.me-tab').forEach(function(b){ b.classList.remove('active'); });
  var btn = document.getElementById('tab-btn-' + tab);
  if (btn) btn.classList.add('active');
  loadEvents();
}

/* ── Date filter ───────────────────────────────────────────── */
function applyFilter() {
  meFilter = document.getElementById('meFilter').value;
  loadEvents();
}

/* ── Load events from server ───────────────────────────────── */
function loadEvents() {
  var skeleton = document.getElementById('meSkeleton');
  var cards    = document.getElementById('meCards');
  var empty    = document.getElementById('meEmpty');

  // Show skeleton while loading
  if (skeleton) skeleton.style.display = 'block';
  if (cards)    { cards.style.display  = 'none'; cards.innerHTML = ''; }
  if (empty)    empty.style.display = 'none';

  fetch('actions/get_my_events.php?tab=' + meTab + '&filter=' + meFilter)
    .then(function(r){ return r.json(); })
    .then(function(data) {
      if (skeleton) skeleton.style.display = 'none';

      // Update counts everywhere
      updateCounts(data.registered_count, data.saved_count, data.attended_count);

      if (!data.success || !data.events || data.events.length === 0) {
        if (empty) {
          empty.style.display = 'block';
          document.getElementById('meEmptyTitle').textContent = emptyTitle(meTab);
          document.getElementById('meEmptyMsg').innerHTML    = emptyMsg(meTab);
        }
        return;
      }

      if (cards) {
        cards.style.display = 'block';
        cards.innerHTML = '';
        data.events.forEach(function(ev) { cards.appendChild(buildCard(ev)); });
      }
    })
    .catch(function(err) {
      console.error(err);
      if (skeleton) skeleton.style.display = 'none';
      showToast('Failed to load events', 'warning', 'bi-exclamation-circle');
    });
}

/* ── Update counts on tabs + stat cards ─────────────────────── */
function updateCounts(reg, sav, att) {
  // Counts on tab badges
  setText('cnt-registered', reg);
  setText('cnt-saved',      sav);
  setText('cnt-attended',   att);
  // Big stat numbers
  setText('statRegistered', reg);
  setText('statSaved',      sav);
  setText('statAttended',   att);
}
function setText(id, val) {
  var el = document.getElementById(id);
  if (el) el.textContent = (val !== undefined && val !== null) ? val : '0';
}

/* ── Empty state copy ────────────────────────────────────────── */
function emptyTitle(tab) {
  return { registered:'No registered events', saved:'No saved events', attended:'No attended events' }[tab] || 'Nothing here';
}
function emptyMsg(tab) {
  if (tab === 'registered') return 'Go to the <a href="student.php" style="color:var(--red);font-weight:500;">Dashboard</a> and hit <strong>Register & Join</strong> on an event.';
  if (tab === 'saved')      return 'Go to the <a href="student.php" style="color:var(--red);font-weight:500;">Dashboard</a> and click <strong>Save</strong> on events you want to track.';
  if (tab === 'attended')   return 'Events where you were checked in by staff will appear here.';
  return '';
}

/* ── Build a single event card ──────────────────────────────── */
function buildCard(ev) {
  var ci       = getCatInfo(ev.category);
  var orgLabel = ev.org_acronym || ev.org_name || 'WMSU';
  var past     = isPast(ev.event_date);

  var card = document.createElement('div');
  card.className = 'me-card';

  /* Icon column */
  var iconCol = document.createElement('div');
  iconCol.className = 'me-icon ' + ci.cls;
  iconCol.innerHTML = '<i class="bi ' + ci.icon + '"></i>';

  /* Info column */
  var info = document.createElement('div');
  info.className = 'me-info';

  /* Status badges */
  var badges = '';
  if (meTab === 'registered') {
    if (ev.time_in) {
      badges += '<span class="me-badge attended"><i class="bi bi-patch-check-fill"></i> Attended</span> ';
    } else if (past) {
      badges += '<span class="me-badge absent"><i class="bi bi-x-circle"></i> Absent</span> ';
    } else {
      badges += '<span class="me-badge upcoming"><i class="bi bi-clock"></i> Upcoming</span> ';
    }
  } else if (meTab === 'saved') {
    badges += '<span class="me-badge saved"><i class="bi bi-bookmark-fill"></i> Saved</span> ';
    if (ev.is_registered == 1) {
      badges += '<span class="me-badge registered"><i class="bi bi-check-circle-fill"></i> Also Registered</span> ';
    }
  } else if (meTab === 'attended') {
    badges += '<span class="me-badge attended"><i class="bi bi-patch-check-fill"></i> Attended</span> ';
    if (ev.certificate_sent == 1) {
      badges += '<span class="me-badge cert"><i class="bi bi-award-fill"></i> Certificate Sent</span> ';
    }
  }
  if (ev.department_name) {
    badges += '<span style="font-size:10px;padding:2px 8px;border-radius:99px;background:#dbeafe;color:#1d4ed8;font-weight:600;">' + ev.department_name + ' Only</span>';
  }

  /* Meta row */
  var meta = '';
  meta += '<span><i class="bi bi-calendar3"></i> ' + fmtDate(ev.event_date) + '</span>';
  meta += '<span><i class="bi bi-clock"></i> ' + fmtTime(ev.event_date) + '</span>';
  meta += '<span><i class="bi bi-geo-alt"></i> ' + (ev.location || '—') + '</span>';
  meta += '<span><i class="bi bi-building"></i> ' + orgLabel + '</span>';

  /* Extra info for attended tab */
  var extra = '';
  if (meTab === 'attended' && ev.time_in) {
    extra = '<div style="font-size:11px;color:#059669;margin-top:4px;display:flex;gap:12px;">'
          + '<span><i class="bi bi-box-arrow-in-right me-1"></i>In: ' + fmtDateTime(ev.time_in) + '</span>'
          + (ev.time_out ? '<span><i class="bi bi-box-arrow-right me-1"></i>Out: ' + fmtDateTime(ev.time_out) + '</span>' : '')
          + '</div>';
  }
  /* Registration date for registered tab */
  if (meTab === 'registered' && ev.registered_at) {
    extra += '<div style="font-size:11px;color:var(--text-muted);margin-top:4px;">'
           + '<i class="bi bi-clock-history me-1"></i>Registered on ' + fmtDate(ev.registered_at)
           + '</div>';
  }
  /* Save date for saved tab */
  if (meTab === 'saved' && ev.saved_at) {
    extra += '<div style="font-size:11px;color:var(--text-muted);margin-top:4px;">'
           + '<i class="bi bi-bookmark me-1"></i>Saved on ' + fmtDate(ev.saved_at)
           + '</div>';
  }

  info.innerHTML =
    '<div style="display:flex;flex-wrap:wrap;gap:5px;margin-bottom:5px;">' + badges + '</div>' +
    '<div class="me-title">' + escHtml(ev.title) + '</div>' +
    '<div class="me-meta">' + meta + '</div>' +
    extra;

  /* Action buttons column */
  var actions = document.createElement('div');
  actions.className = 'me-actions';

  /* View Details button (always) */
  var viewBtn = document.createElement('button');
  viewBtn.className = 'me-btn';
  viewBtn.innerHTML = '<i class="bi bi-eye"></i> View';
  viewBtn.onclick = function() { if (typeof openModal === 'function') openModal(ev.id); };
  actions.appendChild(viewBtn);

  /* QR button — registered tab only, upcoming events */
  if (meTab === 'registered' && !past) {
    var qrBtn = document.createElement('button');
    qrBtn.className = 'me-btn blue';
    qrBtn.innerHTML = '<i class="bi bi-qr-code"></i> My QR';
    qrBtn.onclick = function() { if (typeof showMyQR === 'function') showMyQR(ev.id, encodeURIComponent(ev.title)); };
    actions.appendChild(qrBtn);
  }

  /* Remove / Cancel button */
  var removeBtn = document.createElement('button');
  removeBtn.className = 'me-btn danger';

  if (meTab === 'registered') {
    removeBtn.innerHTML = '<i class="bi bi-x-circle"></i> Cancel';
    removeBtn.title     = 'Cancel your registration';
    removeBtn.onclick   = function() { cancelRegistration(ev.id, card, removeBtn); };

  } else if (meTab === 'saved') {
    removeBtn.innerHTML = '<i class="bi bi-bookmark-x"></i> Unsave';
    removeBtn.title     = 'Remove from saved events';
    removeBtn.onclick   = function() { unsaveEvent(ev.id, card, removeBtn); };
  }

  /* No remove button on attended tab — read-only history */
  if (meTab !== 'attended') actions.appendChild(removeBtn);

  card.appendChild(iconCol);
  card.appendChild(info);
  card.appendChild(actions);
  return card;
}

/* ── Cancel registration ─────────────────────────────────────── */
function cancelRegistration(eventId, card, btn) {
  if (!confirm('Cancel your registration for this event?')) return;
  btn.disabled = true;
  btn.innerHTML = '<i class="bi bi-hourglass-split"></i> Cancelling…';

  var fd = new FormData();
  fd.append('event_id', eventId);
  fetch('actions/toggle_join.php', { method: 'POST', body: fd })
    .then(function(r){ return r.json(); })
    .then(function(res) {
      if (res.success && !res.joined) {
        card.style.transition = 'opacity .3s';
        card.style.opacity = '0';
        setTimeout(function(){ card.remove(); loadEvents(); }, 300);
        showToast('Registration cancelled', 'warning', 'bi-x-circle');
        // Sync dashboard join state if App.js joined Set is available
        if (typeof joined !== 'undefined') joined.delete(eventId);
      } else {
        showToast(res.msg || 'Could not cancel', 'warning', 'bi-exclamation-circle');
        btn.disabled = false;
        btn.innerHTML = '<i class="bi bi-x-circle"></i> Cancel';
      }
    })
    .catch(function(){
      showToast('Network error', 'warning', 'bi-wifi-off');
      btn.disabled = false;
      btn.innerHTML = '<i class="bi bi-x-circle"></i> Cancel';
    });
}

/* ── Unsave event ────────────────────────────────────────────── */
function unsaveEvent(eventId, card, btn) {
  btn.disabled = true;
  btn.innerHTML = '<i class="bi bi-hourglass-split"></i> Removing…';

  var fd = new FormData();
  fd.append('event_id', eventId);
  fetch('actions/toggle_save.php', { method: 'POST', body: fd })
    .then(function(r){ return r.json(); })
    .then(function(res) {
      if (res.success) {
        card.style.transition = 'opacity .3s';
        card.style.opacity = '0';
        setTimeout(function(){ card.remove(); loadEvents(); }, 300);
        showToast('Removed from saved events', 'info', 'bi-bookmark-x');
        // Sync dashboard save state
        if (typeof saved !== 'undefined') saved.delete(eventId);
        var saveCardBtn = document.getElementById('save-' + eventId);
        if (saveCardBtn) { saveCardBtn.classList.remove('saved'); saveCardBtn.innerHTML = '<i class="bi bi-bookmark"></i> Save'; }
      } else {
        showToast(res.msg || 'Could not remove', 'warning', 'bi-exclamation-circle');
        btn.disabled = false;
        btn.innerHTML = '<i class="bi bi-bookmark-x"></i> Unsave';
      }
    })
    .catch(function(){
      showToast('Network error', 'warning', 'bi-wifi-off');
      btn.disabled = false;
      btn.innerHTML = '<i class="bi bi-bookmark-x"></i> Unsave';
    });
}

/* ── HTML escape helper ──────────────────────────────────────── */
function escHtml(str) {
  var d = document.createElement('div');
  d.textContent = str || '';
  return d.innerHTML;
}

/* ── Boot ─────────────────────────────────────────────────────── */
document.addEventListener('DOMContentLoaded', function() {
  /* Highlight the active tab visually on first load */
  document.querySelectorAll('.me-tab').forEach(function(b){ b.classList.remove('active'); });
  var first = document.getElementById('tab-btn-registered');
  if (first) first.classList.add('active');

  loadEvents();
});
</script>

</body>
</html>
