<?php
/**
 * Dashboard.php — DB-connected student dashboard
 * Requires: $pdo, $user_id, $student (set by student.php)
 */

// Stats from DB
$stmtUpcoming = $pdo->prepare("SELECT COUNT(*) FROM events WHERE status='approved' AND event_date > NOW()");
$stmtUpcoming->execute();
$totalUpcoming = (int)$stmtUpcoming->fetchColumn();

$stmtSaved = $pdo->prepare("SELECT COUNT(*) FROM saved_events WHERE user_id=?");
$stmtSaved->execute([$user_id]);

// Attendance history
$stmtAtt = $pdo->prepare("
  SELECT e.title, e.event_date, a.time_in, a.time_out
  FROM registrations r
  JOIN events e ON r.event_id = e.id
  LEFT JOIN attendance a ON a.event_id = r.event_id AND a.user_id = r.user_id
  WHERE r.user_id = ?
  ORDER BY e.event_date DESC
  LIMIT 6
");
$stmtAtt->execute([$user_id]);
$attendanceHistory = $stmtAtt->fetchAll(PDO::FETCH_ASSOC);
$totalSaved = (int)$stmtSaved->fetchColumn();

$stmtJoined = $pdo->prepare("SELECT COUNT(*) FROM registrations WHERE user_id=?");
$stmtJoined->execute([$user_id]);
$totalJoined = (int)$stmtJoined->fetchColumn();

$stmtOrgs = $pdo->prepare("SELECT COUNT(*) FROM organizations");
$stmtOrgs->execute();
$totalOrgs = (int)$stmtOrgs->fetchColumn();

// Student's own department_id (for restriction check)
$studentDeptId = (int)($student['department_id'] ?? 0);

// Fetch ALL approved upcoming events (students can VIEW all, but may not register)
$stmtEvents = $pdo->prepare("
  SELECT e.*,
         u.full_name  AS organizer_name,
         o.name       AS org_name,
         o.acronym    AS org_acronym,
         o.id         AS org_id,
         d.name       AS dept_name,
         d.code       AS dept_code,
         (SELECT COUNT(*) FROM registrations r WHERE r.event_id = e.id) AS attendee_count,
         EXISTS(SELECT 1 FROM registrations  r WHERE r.event_id=e.id AND r.user_id=?) AS is_joined,
         EXISTS(SELECT 1 FROM saved_events   s WHERE s.event_id=e.id AND s.user_id=?) AS is_saved
  FROM events e
  LEFT JOIN users         u ON e.organizer_id = u.id
  LEFT JOIN organizations o ON e.org_id       = o.id
  LEFT JOIN departments   d ON e.department_id = d.id
  WHERE e.status = 'approved' AND e.event_date > NOW()
  ORDER BY e.event_date ASC
");
$stmtEvents->execute([$user_id, $user_id]);
$events = $stmtEvents->fetchAll(PDO::FETCH_ASSOC);

// Build can_register flag per event (department match + deadline check)
foreach ($events as &$ev) {
    $restricted = !empty($ev['department_id']);
    $deptMatch  = !$restricted || ((int)$ev['department_id'] === $studentDeptId);
    $deadlinePassed = !empty($ev['registration_deadline'])
        && strtotime($ev['registration_deadline'] . ' 23:59:59') < time();
    $isFull = (int)$ev['attendee_count'] >= max(1, (int)($ev['max_attendees'] ?? $ev['capacity'] ?? 100));
    $ev['can_register']   = $deptMatch && !$deadlinePassed && !$isFull;
    $ev['is_restricted']  = $restricted && !$deptMatch;
    $ev['restrict_label'] = $restricted ? ($ev['dept_name'] ?? $ev['dept_code'] ?? 'specific department') : '';
    $ev['deadline_passed']= $deadlinePassed;
    $ev['is_full']        = $isFull;
}
unset($ev);

// Organizations list for filter dropdown
$stmtOrgsFilter = $pdo->query("SELECT DISTINCT o.id, o.name, o.acronym FROM organizations o INNER JOIN events e ON e.org_id = o.id WHERE e.status='approved' AND e.event_date > NOW() ORDER BY o.name ASC");
$orgsForFilter  = $stmtOrgsFilter->fetchAll(PDO::FETCH_ASSOC);

// This Week
$stmtWeek = $pdo->prepare("
  SELECT * FROM events
  WHERE status='approved'
    AND event_date BETWEEN NOW() AND DATE_ADD(NOW(), INTERVAL 7 DAY)
  ORDER BY event_date ASC LIMIT 5
");
$stmtWeek->execute();
$weekEvents = $stmtWeek->fetchAll(PDO::FETCH_ASSOC);

// Category counts from DB (matches catInfo logic)
$stmtAcademic = $pdo->prepare("SELECT COUNT(*) FROM events WHERE status='approved' AND event_date > NOW() AND (category LIKE '%academic%' OR category LIKE '%seminar%' OR category LIKE '%research%' OR category LIKE '%forum%' OR category LIKE '%workshop%' OR category LIKE '%review%')");
$stmtAcademic->execute();
$countAcademic = (int)$stmtAcademic->fetchColumn();

$stmtSocial = $pdo->prepare("SELECT COUNT(*) FROM events WHERE status='approved' AND event_date > NOW() AND (category LIKE '%social%' OR category LIKE '%cultural%' OR category LIKE '%music%' OR category LIKE '%night%')");
$stmtSocial->execute();
$countSocial = (int)$stmtSocial->fetchColumn();

$stmtSports = $pdo->prepare("SELECT COUNT(*) FROM events WHERE status='approved' AND event_date > NOW() AND (category LIKE '%sport%' OR category LIKE '%athletic%' OR category LIKE '%intramural%' OR category LIKE '%game%')");
$stmtSports->execute();
$countSports = (int)$stmtSports->fetchColumn();

$stmtOrg = $pdo->prepare("SELECT COUNT(*) FROM events WHERE status='approved' AND event_date > NOW() AND (category LIKE '%org%' OR category LIKE '%organization%' OR category LIKE '%org event%')");
$stmtOrg->execute();
$countOrg = (int)$stmtOrg->fetchColumn();

// Organizations
$stmtOrgsAll = $pdo->prepare("
  SELECT o.*, d.name AS department_name
  FROM organizations o
  LEFT JOIN departments d ON o.department_id = d.id
  ORDER BY o.name ASC LIMIT 6
");
$stmtOrgsAll->execute();
$organizations = $stmtOrgsAll->fetchAll(PDO::FETCH_ASSOC);

function catInfo($cat) {
  $c = strtolower($cat);
  if (strpos($c,'academic')!==false||strpos($c,'seminar')!==false||strpos($c,'research')!==false||strpos($c,'forum')!==false||strpos($c,'workshop')!==false||strpos($c,'review')!==false)
    return ['key'=>'academic','icon'=>'bi-mortarboard','badge'=>'badge-academic','label'=>'Academic'];
  if (strpos($c,'social')!==false||strpos($c,'cultural')!==false||strpos($c,'music')!==false||strpos($c,'night')!==false)
    return ['key'=>'social','icon'=>'bi-music-note','badge'=>'badge-social','label'=>'Social'];
  if (strpos($c,'sport')!==false||strpos($c,'athletic')!==false||strpos($c,'intramural')!==false||strpos($c,'game')!==false)
    return ['key'=>'sports','icon'=>'bi-trophy','badge'=>'badge-sports','label'=>'Sports'];
  if (strpos($c,'org event')!==false)
    return ['key'=>'org','icon'=>'bi-people','badge'=>'badge-org','label'=>'Organizations'];
  return ['key'=>'org','icon'=>'bi-people','badge'=>'badge-org','label'=>'Organizations'];
}

function orgTypeIcon($type) {
  $icons = ['academic'=>'bi-mortarboard','religious'=>'bi-heart','cultural'=>'bi-palette','sports'=>'bi-trophy','civic'=>'bi-flag','student_gov'=>'bi-bank'];
  return $icons[$type] ?? 'bi-people';
}
?>

<div id="dashboardSection" class="section active">

  <div class="page-header">
    <div>
      <div class="page-title">Welcome back, <?= htmlspecialchars($studentFirstName) ?> 👋</div>
      <div class="page-sub">Here's what's happening at Western Mindanao State University</div>
    </div>
  </div>

  <div class="stat-row">
    <div class="stat-card">
      <div class="stat-icon red"><i class="bi bi-calendar-event"></i></div>
      <div><div class="stat-num"><?= $totalUpcoming ?></div><div class="stat-label">Upcoming Events</div></div>
    </div>
    <div class="stat-card">
      <div class="stat-icon blue"><i class="bi bi-bookmark-check"></i></div>
      <div><div class="stat-num" id="statSaved"><?= $totalSaved ?></div><div class="stat-label">Saved Events</div></div>
    </div>
    <div class="stat-card">
      <div class="stat-icon purple"><i class="bi bi-people"></i></div>
      <div><div class="stat-num"><?= $totalOrgs ?></div><div class="stat-label">Organizations</div></div>
    </div>
    <div class="stat-card">
      <div class="stat-icon green"><i class="bi bi-check-circle"></i></div>
      <div><div class="stat-num" id="statJoined"><?= $totalJoined ?></div><div class="stat-label">Registered</div></div>
    </div>
  </div>

  <div class="content-grid">

    <div>
      <div class="filter-bar" style="flex-wrap:wrap;gap:10px;align-items:center;">
        <!-- Category pills -->
        <div style="display:flex;gap:6px;flex-wrap:wrap;align-items:center;">
          <div class="cat-pill active" id="pill-all"      onclick="filterCat(this,'all')">All</div>
          <div class="cat-pill"        id="pill-academic" onclick="filterCat(this,'academic')">📚 Academic</div>
          <div class="cat-pill"        id="pill-social"   onclick="filterCat(this,'social')">🎵 Social</div>
          <div class="cat-pill"        id="pill-sports"   onclick="filterCat(this,'sports')">🏆 Sports</div>
          <div class="cat-pill"        id="pill-org"      onclick="filterCat(this,'org')">🏛️ Organizations</div>
        </div>

        <!-- Date + Org dropdowns -->
        <div style="display:flex;gap:8px;align-items:center;margin-left:auto;flex-wrap:wrap;">
          <select id="filterDate" onchange="applyFilters()" style="padding:7px 10px;border:1.5px solid var(--border);border-radius:8px;font-size:12.5px;font-family:Poppins,sans-serif;background:#fff;color:var(--text-primary);cursor:pointer;">
            <option value="">📅 Any Date</option>
            <option value="today">Today</option>
            <option value="week">This Week</option>
            <option value="month">This Month</option>
            <option value="next_month">Next Month</option>
          </select>
          <select id="filterOrg" onchange="applyFilters()" style="padding:7px 10px;border:1.5px solid var(--border);border-radius:8px;font-size:12.5px;font-family:Poppins,sans-serif;background:#fff;color:var(--text-primary);cursor:pointer;max-width:180px;">
            <option value="">🏢 All Organizations</option>
            <?php foreach ($orgsForFilter as $of): ?>
            <option value="<?= (int)$of['id'] ?>"><?= htmlspecialchars($of['acronym'] ?: $of['name']) ?></option>
            <?php endforeach; ?>
          </select>
          <button onclick="resetFilters()" style="padding:7px 11px;border:1.5px solid var(--border);border-radius:8px;font-size:12px;background:#fff;cursor:pointer;color:var(--text-muted);" title="Clear filters"><i class="bi bi-x-circle"></i></button>
          <div class="view-toggle">
            <button class="view-btn active" onclick="setView('list',this)" title="List view"><i class="bi bi-list-ul"></i></button>
            <button class="view-btn"        onclick="setView('grid',this)" title="Grid view"><i class="bi bi-grid-3x3-gap"></i></button>
          </div>
        </div>
      </div>

      <!-- Dynamic category header with real DB count -->
      <div class="cat-header" id="catHeader" style="font-size:16px;font-weight:600;margin:20px 0 12px;padding:0 4px;color:var(--text-primary);display:none;">
        <span id="catLabel"></span> Events (<span id="catCount">0</span>)
      </div>

      <div class="events-list" id="eventsFeed">
        <?php if (empty($events)): ?>
          <div class="empty-state">
            <i class="bi bi-calendar-x"></i>
            <h3>No Upcoming Events</h3>
            <p>No approved upcoming events right now. Check back soon!</p>
          </div>
        <?php else: ?>
          <?php foreach ($events as $ev):
            $ci      = catInfo($ev['category'] ?? 'Academic');
            $evDate  = new DateTime($ev['event_date']);
            $joined  = (bool)$ev['is_joined'];
            $saved   = (bool)$ev['is_saved'];
            $orgLabel= $ev['org_acronym'] ?: ($ev['org_name'] ?: ($ev['organizer_name'] ?: 'WMSU'));
          ?>
          <div class="event-card"
            data-cat="<?= htmlspecialchars($ci['key']) ?>"
            data-id="<?= $ev['id'] ?>"
            data-org="<?= (int)($ev['org_id'] ?? 0) ?>"
            data-date="<?= $evDate->format('Y-m-d') ?>"
            data-can-register="<?= $ev['can_register'] ? '1' : '0' ?>"
            data-restricted="<?= $ev['is_restricted'] ? '1' : '0' ?>"
          >
            <div class="event-color-bar <?= $ci['key'] ?>"></div>
            <div class="event-icon-col <?= $ci['key'] ?>"><i class="bi <?= $ci['icon'] ?>"></i></div>
            <div class="event-info">
              <div style="display:flex;align-items:center;gap:6px;flex-wrap:wrap;margin-bottom:4px;">
                <span class="event-cat-badge <?= $ci['badge'] ?>"><?= htmlspecialchars($ci['label']) ?></span>
                <?php if ($ev['is_restricted']): ?>
                <span style="background:#fef3c7;color:#92400e;font-size:10px;font-weight:600;padding:2px 8px;border-radius:99px;display:inline-flex;align-items:center;gap:3px;">
                  <i class="bi bi-eye"></i> View Only &middot; <?= htmlspecialchars($ev['restrict_label']) ?>
                </span>
                <?php elseif ($ev['deadline_passed']): ?>
                <span style="background:#fee2e2;color:#b91c1c;font-size:10px;font-weight:600;padding:2px 8px;border-radius:99px;">
                  <i class="bi bi-calendar-x"></i> Deadline Passed
                </span>
                <?php elseif ($ev['is_full']): ?>
                <span style="background:#f1f5f9;color:#475569;font-size:10px;font-weight:600;padding:2px 8px;border-radius:99px;">
                  <i class="bi bi-person-x"></i> Full
                </span>
                <?php endif; ?>
              </div>
              <div class="event-title-text"><?= htmlspecialchars($ev['title']) ?></div>
              <div class="event-meta-row">
                <span><i class="bi bi-calendar3"></i> <?= $evDate->format('M j, Y') ?></span>
                <span><i class="bi bi-clock"></i> <?= $evDate->format('g:i A') ?></span>
                <span><i class="bi bi-geo-alt"></i> <?= htmlspecialchars($ev['location'] ?? '—') ?></span>
                <span><i class="bi bi-people"></i> <?= (int)$ev['attendee_count'] ?> attending</span>
                <span><i class="bi bi-building"></i> <?= htmlspecialchars($orgLabel) ?></span>
              </div>
            </div>
            <div class="event-actions">
              <button class="btn-details" onclick="openModal(<?= $ev['id'] ?>)">View Details</button>
              <button class="btn-save <?= $saved ? 'saved' : '' ?>" id="save-<?= $ev['id'] ?>" onclick="toggleSave(<?= $ev['id'] ?>,this)">
                <i class="bi <?= $saved ? 'bi-bookmark-fill' : 'bi-bookmark' ?>"></i> <?= $saved ? 'Saved' : 'Save' ?>
              </button>
            </div>
          </div>
          <?php endforeach; ?>
        <?php endif; ?>
      </div>
    </div>

    <div class="right-col">

      <div class="panel">
        <div class="panel-header">
          <span class="panel-title">This Week</span>
          <span style="font-size:12px;color:var(--red);font-weight:600"><?= count($weekEvents) ?> event<?= count($weekEvents)!==1?'s':'' ?></span>
        </div>
        <?php if (empty($weekEvents)): ?>
          <div style="font-size:13px;color:var(--text-muted);padding:10px 0;">No events this week.</div>
        <?php else: ?>
          <?php foreach ($weekEvents as $we): $wd = new DateTime($we['event_date']); ?>
          <div class="week-item" onclick="openModal(<?= $we['id'] ?>)">
            <div class="week-badge"><?= $wd->format('j') ?></div>
            <div>
              <div class="week-name"><?= htmlspecialchars($we['title']) ?></div>
              <div class="week-sub"><?= $wd->format('g:i A') ?> · <?= htmlspecialchars($we['location'] ?? '—') ?></div>
            </div>
          </div>
          <?php endforeach; ?>
        <?php endif; ?>
      </div>

      <div class="panel">
        <div class="panel-header">
          <div style="display:flex;align-items:center;gap:8px">
            <button class="mini-cal-nav-btn" onclick="calPrev()"><i class="bi bi-chevron-left"></i></button>
            <span class="panel-title" id="miniCalMonth">April 2026</span>
            <button class="mini-cal-nav-btn" onclick="calNext()"><i class="bi bi-chevron-right"></i></button>
          </div>
          <a href="Calendar.php" class="panel-link">Full view</a>
        </div>
        <div class="mini-cal-grid" id="miniCalGrid"></div>
      </div>

      <div class="panel">
        <div class="panel-header">
          <span class="panel-title">WMSU Organizations</span>
          <a class="panel-link" onclick="filterCat(null,'org');showSection('dashboard')">View all</a>
        </div>
        <div class="org-grid">
          <?php foreach ($organizations as $org):
            $icon = orgTypeIcon($org['type']);
          ?>
          <div class="org-card" onclick="openOrgModal(
            '<?= addslashes(htmlspecialchars($org['acronym'] ?: $org['name'])) ?>',
            '<?= addslashes(htmlspecialchars($org['department_name'] ?? 'University-wide')) ?>',
            '🏛️',
            '<?= addslashes(htmlspecialchars($org['description'] ?? $org['name'])) ?>'
          )">
            <div class="org-icon-wrap"><i class="bi <?= $icon ?>"></i></div>
            <div>
              <div class="org-name-text"><?= htmlspecialchars($org['acronym'] ?: substr($org['name'],0,14)) ?></div>
              <div class="org-members-text"><?= htmlspecialchars($org['department_name'] ?? 'Univ-wide') ?></div>
            </div>
          </div>
          <?php endforeach; ?>
        </div>
      </div>

      <!-- ATTENDANCE HISTORY -->
      <div class="panel">
        <div class="panel-header">
          <span class="panel-title">My Attendance</span>
          <a href="My events.php" class="panel-link">View events</a>
        </div>
        <?php if (empty($attendanceHistory)): ?>
          <div style="font-size:13px;color:var(--text-muted);padding:10px 0;">No events registered yet.</div>
        <?php else: ?>
          <?php foreach ($attendanceHistory as $ah):
            $hasTin = !empty($ah['time_in']);
            $now    = new DateTime();
            $edt    = new DateTime($ah['event_date']);
            $isPast = $now > (clone $edt)->modify('+6 hours');
            if ($hasTin) {
              $statusIcon  = 'bi-check-circle-fill'; $statusColor = '#059669'; $statusText = 'Attended';
            } elseif ($isPast) {
              $statusIcon  = 'bi-x-circle-fill'; $statusColor = '#dc2626'; $statusText = 'Absent';
            } else {
              $statusIcon  = 'bi-clock'; $statusColor = '#d97706'; $statusText = 'Upcoming';
            }
          ?>
          <div style="display:flex;align-items:center;gap:10px;padding:8px 0;border-bottom:1px solid #f5f5f5;">
            <i class="bi <?= $statusIcon ?>" style="color:<?= $statusColor ?>;font-size:17px;flex-shrink:0;"></i>
            <div style="flex:1;min-width:0;">
              <div style="font-size:12.5px;font-weight:600;color:var(--text-primary);white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">
                <?= htmlspecialchars($ah['title']) ?>
              </div>
              <div style="font-size:11px;color:var(--text-muted);"><?= $edt->format('M d, Y') ?></div>
            </div>
            <span style="font-size:10.5px;font-weight:600;color:<?= $statusColor ?>;white-space:nowrap;"><?= $statusText ?></span>
          </div>
          <?php endforeach; ?>
        <?php endif; ?>
      </div>

    </div>
  </div>

</div>

<?php
// Expose event data to JS for modals
$eventsJson = json_encode(array_map(function($ev) {
  $ci = catInfo($ev['category'] ?? 'Academic');
  $d  = new DateTime($ev['event_date']);
  return [
    'id'            => (int)$ev['id'],
    'title'         => $ev['title'],
    'category'      => $ci['label'],
    'catKey'        => $ci['key'],
    'date'          => $d->format('F j, Y'),
    'dateRaw'       => $d->format('Y-m-d'),
    'time'          => $d->format('g:i A'),
    'venue'         => $ev['location'] ?? '—',
    'attendees'     => (int)$ev['attendee_count'] . ' attending',
    'desc'          => $ev['description'] ?? 'No description provided.',
    'org'           => $ev['org_acronym'] ?: ($ev['org_name'] ?: ($ev['organizer_name'] ?: 'WMSU')),
    'orgId'         => (int)($ev['org_id'] ?? 0),
    'isJoined'      => (bool)$ev['is_joined'],
    'isSaved'       => (bool)$ev['is_saved'],
    'maxSlots'      => (int)($ev['max_attendees'] ?? $ev['capacity'] ?? 100),
    'canRegister'   => (bool)$ev['can_register'],
    'isRestricted'  => (bool)$ev['is_restricted'],
    'restrictLabel' => $ev['restrict_label'] ?? '',
    'deadlinePassed'=> (bool)$ev['deadline_passed'],
    'isFull'        => (bool)$ev['is_full'],
    'regDeadline'   => $ev['registration_deadline'] ?? null,
  ];
}, $events));
?>
<script>
window.CC_EVENTS  = <?= $eventsJson ?>;
window.CC_USER_ID = <?= (int)$user_id ?>;

// Category counts from PHP
window.CC_CAT_COUNTS = {
  academic: <?= $countAcademic ?>,
  social: <?= $countSocial ?>,
  sports: <?= $countSports ?>,
  org: <?= $countOrg ?>
};
</script>
