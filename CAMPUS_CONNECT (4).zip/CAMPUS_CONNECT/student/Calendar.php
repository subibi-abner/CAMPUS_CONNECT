<?php
/**
 * Calendar.php — CampusConnect Calendar Page
 * Real DB events + custom calendar with easy month/year navigation
 */

if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
require_once '../config.php';
require_once '../db_functions.php';
require_login('student');

$user_id = $_SESSION['user_id'];
$student = get_user($pdo, $user_id);

if (!$student) {
    session_destroy();
    header('Location: ../login.php');
    exit;
}

$studentName      = $student['full_name'] ?? 'Student';
$studentFirstName = explode(' ', $studentName)[0] ?? 'Student';
$studentInitial   = strtoupper(substr($studentFirstName, 0, 1));

// Build year display
$deptCode  = $student['dept_code'] ?? '';
$yearLevel = $student['year_level'] ?? '';
$course    = $student['course'] ?? '';

// Remap CICT -> CCS per user's request
if ($deptCode === 'CICT') $deptCode = 'CCS';

$courseMap = [
    'information technology' => 'BSIT',
    'computer science'       => 'BSCS',
    'information systems'    => 'BSIS',
    'nursing'                => 'BSN',
    'education'              => 'BSED',
    'criminology'            => 'BSCrim',
    'engineering'            => 'BSENG',
    'social work'            => 'BSSW',
    'medicine'               => 'MD',
    'law'                    => 'JD',
];
$courseLabel = '';
if ($course) {
    $courseLower = strtolower($course);
    foreach ($courseMap as $keyword => $abbr) {
        if (strpos($courseLower, $keyword) !== false) { $courseLabel = $abbr; break; }
    }
    if (!$courseLabel) {
        preg_match_all('/\b[A-Z]/', $course, $m);
        $courseLabel = implode('', $m[0]) ?: $deptCode ?: 'WMSU';
    }
} else {
    $courseLabel = $deptCode ?: 'WMSU';
}

$studentYear = trim($yearLevel . ($yearLevel && $courseLabel ? ' · ' : '') . $courseLabel, ' · ');
$activePage  = 'calendar';

// ── Fetch ALL approved events from DB (past + future for full calendar) ──
$stmtCal = $pdo->prepare("
    SELECT
        e.id,
        e.title,
        e.event_date,
        e.location,
        e.category,
        e.description,
        e.max_attendees,
        o.name    AS org_name,
        o.acronym AS org_acronym,
        (SELECT COUNT(*) FROM registrations r WHERE r.event_id = e.id) AS attendee_count,
        EXISTS(SELECT 1 FROM registrations r WHERE r.event_id = e.id AND r.user_id = ?) AS is_joined,
        EXISTS(SELECT 1 FROM saved_events  s WHERE s.event_id = e.id AND s.user_id = ?) AS is_saved
    FROM events e
    LEFT JOIN organizations o ON e.org_id = o.id
    WHERE e.status = 'approved'
    ORDER BY e.event_date ASC
");
$stmtCal->execute([$user_id, $user_id]);
$dbEvents = $stmtCal->fetchAll(PDO::FETCH_ASSOC);

function calCategoryColor($cat) {
    $c = strtolower($cat ?? '');
    if (strpos($c,'academic')!==false||strpos($c,'seminar')!==false||strpos($c,'research')!==false||strpos($c,'workshop')!==false) return '#3b82f6';
    if (strpos($c,'social')!==false||strpos($c,'cultural')!==false||strpos($c,'music')!==false||strpos($c,'night')!==false) return '#9333ea';
    if (strpos($c,'sport')!==false||strpos($c,'intramural')!==false||strpos($c,'game')!==false) return '#C0272D';
    return '#ca8a04';
}
function calCategoryKey($cat) {
    $c = strtolower($cat ?? '');
    if (strpos($c,'academic')!==false||strpos($c,'seminar')!==false||strpos($c,'research')!==false||strpos($c,'workshop')!==false) return 'academic';
    if (strpos($c,'social')!==false||strpos($c,'cultural')!==false||strpos($c,'music')!==false||strpos($c,'night')!==false) return 'social';
    if (strpos($c,'sport')!==false||strpos($c,'intramural')!==false||strpos($c,'game')!==false) return 'sports';
    return 'org';
}

$calEvents = [];
foreach ($dbEvents as $ev) {
    $calEvents[] = [
        'id'        => (int)$ev['id'],
        'title'     => $ev['title'],
        'date'      => date('Y-m-d', strtotime($ev['event_date'])),
        'time'      => date('g:i A', strtotime($ev['event_date'])),
        'location'  => $ev['location'] ?? '',
        'color'     => calCategoryColor($ev['category']),
        'catKey'    => calCategoryKey($ev['category']),
        'catLabel'  => $ev['category'] ?? 'General',
        'org'       => $ev['org_acronym'] ?? $ev['org_name'] ?? 'WMSU',
        'desc'      => $ev['description'] ?? '',
        'attendees' => (int)$ev['attendee_count'],
        'maxSlots'  => (int)$ev['max_attendees'],
        'isJoined'  => (bool)$ev['is_joined'],
        'isSaved'   => (bool)$ev['is_saved'],
    ];
}
?>
<?php include 'Header.php'; ?>
<body>

<div class="toast-container" id="toastContainer"></div>
<?php include 'Modals.php'; ?>
<?php include 'Navbar.php'; ?>
<?php include 'Notification.php'; ?>

<div class="layout">
  <?php include 'Sidebar.php'; ?>

  <main class="main">
    <div class="section active">

      <div class="section-header" style="margin-bottom:24px;">
        <h2 style="font-size:22px;font-weight:700;color:var(--text-primary);">
          <i class="bi bi-calendar3 me-2" style="color:var(--red)"></i>Event Calendar
        </h2>
        <p style="font-size:13px;color:var(--text-muted);margin-top:4px;">
          Browse all campus events — click any event or date for details
        </p>
      </div>

      <div style="background:var(--bg-card);border:1px solid var(--border);border-radius:14px;overflow:hidden;box-shadow:0 1px 8px rgba(0,0,0,0.06);">

        <!-- ─── Custom toolbar ─────────────────────── -->
        <div style="display:flex;align-items:center;justify-content:space-between;padding:14px 20px;border-bottom:1px solid var(--border);flex-wrap:wrap;gap:10px;">

          <!-- Prev / Today / Next -->
          <div style="display:flex;align-items:center;gap:6px;">
            <button onclick="calMove(-1)" title="Previous"
              class="cal-nav-btn"><i class="bi bi-chevron-left"></i></button>
            <button onclick="goToday()"
              class="cal-today-btn">Today</button>
            <button onclick="calMove(1)" title="Next"
              class="cal-nav-btn"><i class="bi bi-chevron-right"></i></button>
          </div>

          <!-- Month + Year selectors -->
          <div style="display:flex;align-items:center;gap:8px;">
            <select id="calMonthSel" onchange="calJump()" class="cal-sel">
              <?php
              $months = ['January','February','March','April','May','June','July','August','September','October','November','December'];
              foreach ($months as $mi => $mn) echo "<option value=\"$mi\">$mn</option>";
              ?>
            </select>
            <select id="calYearSel" onchange="calJump()" class="cal-sel">
              <?php
              $cy = (int)date('Y');
              for ($y = $cy - 2; $y <= $cy + 4; $y++) echo "<option value=\"$y\">$y</option>";
              ?>
            </select>
          </div>

          <!-- View toggles -->
          <div style="display:flex;gap:4px;">
            <button onclick="setCalView('month',this)" id="vBtnMonth" class="cal-view-btn active-view">Month</button>
            <button onclick="setCalView('week',this)"  id="vBtnWeek"  class="cal-view-btn">Week</button>
            <button onclick="setCalView('list',this)"  id="vBtnList"  class="cal-view-btn">List</button>
          </div>
        </div>

        <!-- FullCalendar -->
        <div id="calendarEl" style="padding:12px 16px 20px;"></div>

      </div><!-- /card -->
    </div>
  </main>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/fullcalendar@6.1.11/index.global.min.js"></script>
<script src="App.js"></script>

<script>
/* ── Events from PHP/DB ── */
const calendarEvents = <?= json_encode(array_map(function($e) {
    return [
        'id'            => (string)$e['id'],
        'title'         => $e['title'],
        'start'         => $e['date'],
        'color'         => $e['color'],
        'extendedProps' => [
            'eventId'   => $e['id'],
            'time'      => $e['time'],
            'location'  => $e['location'],
            'catKey'    => $e['catKey'],
            'catLabel'  => $e['catLabel'],
            'org'       => $e['org'],
            'desc'      => $e['desc'],
            'attendees' => $e['attendees'],
            'maxSlots'  => $e['maxSlots'],
            'isJoined'  => $e['isJoined'],
            'isSaved'   => $e['isSaved'],
        ],
    ];
}, $calEvents)) ?>;

/* ── Init FullCalendar ── */
var cal;
document.addEventListener('DOMContentLoaded', function() {
    cal = new FullCalendar.Calendar(document.getElementById('calendarEl'), {
        initialView  : 'dayGridMonth',
        height       : 620,
        headerToolbar: false,
        eventDisplay : 'block',
        dayMaxEvents : 3,
        events       : calendarEvents,

        datesSet: function(info) {
            // Sync dropdowns when calendar navigates
            var d = info.view.currentStart;
            // For month view currentStart = 1st of that month; for week it's the week start
            // Use the date in the center of the view for week
            var mid = new Date((info.view.currentStart.getTime() + info.view.currentEnd.getTime()) / 2);
            document.getElementById('calMonthSel').value = mid.getMonth();
            document.getElementById('calYearSel').value  = mid.getFullYear();
        },

        eventClick: function(info) {
            info.jsEvent.stopPropagation();
            if (window.openModal) openModal(info.event.extendedProps.eventId);
        },

        dayCellDidMount: function(arg) {
            var ds = arg.date.toISOString().slice(0,10);
            var has = calendarEvents.some(function(e){ return e.start === ds; });
            if (has) {
                var n = arg.el.querySelector('.fc-daygrid-day-number');
                if (n) {
                    var dot = document.createElement('span');
                    dot.style.cssText = 'display:inline-block;width:6px;height:6px;border-radius:50%;background:var(--red);margin-left:4px;vertical-align:middle;margin-bottom:2px;';
                    n.appendChild(dot);
                }
            }
        },

        dateClick: function(info) {
            var ds  = info.dateStr;
            var evs = calendarEvents.filter(function(e){ return e.start === ds; });
            if (!evs.length) return;
            if (evs.length === 1) { openModal(evs[0].extendedProps.eventId); return; }
            showDayPopup(info.dayEl, ds, evs);
        }
    });

    cal.render();

    // Seed dropdowns
    var now = new Date();
    document.getElementById('calMonthSel').value = now.getMonth();
    document.getElementById('calYearSel').value  = now.getFullYear();

    document.addEventListener('click', function(e) {
        var p = document.getElementById('dayPopup');
        if (p && !p.contains(e.target)) p.remove();
    });
});

function calMove(dir) { if(cal) dir < 0 ? cal.prev() : cal.next(); }

function goToday() {
    if(!cal) return;
    cal.today();
    var n = new Date();
    document.getElementById('calMonthSel').value = n.getMonth();
    document.getElementById('calYearSel').value  = n.getFullYear();
}

function calJump() {
    if(!cal) return;
    var m = parseInt(document.getElementById('calMonthSel').value);
    var y = parseInt(document.getElementById('calYearSel').value);
    cal.gotoDate(new Date(y, m, 1));
}

function setCalView(v, btn) {
    if(!cal) return;
    var map = {month:'dayGridMonth', week:'timeGridWeek', list:'listMonth'};
    cal.changeView(map[v] || 'dayGridMonth');
    document.querySelectorAll('.cal-view-btn').forEach(function(b){
        b.classList.remove('active-view');
        b.style.background  = '#fff';
        b.style.color       = 'var(--text-secondary)';
        b.style.borderColor = 'var(--border)';
    });
    btn.classList.add('active-view');
    btn.style.background  = 'var(--red)';
    btn.style.color       = '#fff';
    btn.style.borderColor = 'var(--red)';
}

function showDayPopup(dayEl, dateStr, evs) {
    var old = document.getElementById('dayPopup');
    if(old) old.remove();
    var rect = dayEl.getBoundingClientRect();
    var div  = document.createElement('div');
    div.id   = 'dayPopup';
    div.style.cssText = 'position:fixed;z-index:600;background:#fff;border:1px solid var(--border);border-radius:12px;box-shadow:0 8px 32px rgba(0,0,0,0.14);padding:14px 16px;width:240px;';
    div.style.top  = Math.min(rect.bottom + 6, window.innerHeight - 260) + 'px';
    div.style.left = Math.min(rect.left + 4, window.innerWidth - 250) + 'px';

    var d = new Date(dateStr + 'T00:00:00');
    var label = d.toLocaleDateString('en-PH',{weekday:'long',month:'long',day:'numeric'});
    div.innerHTML = '<div style="font-size:11px;font-weight:700;color:var(--red);margin-bottom:10px;text-transform:uppercase;letter-spacing:.05em;">' + label + '</div>';

    evs.forEach(function(ev) {
        var row = document.createElement('div');
        row.style.cssText = 'display:flex;align-items:center;gap:8px;padding:7px 8px;border-radius:8px;cursor:pointer;transition:background .15s;';
        row.onmouseover = function(){ this.style.background='var(--bg-page)'; };
        row.onmouseout  = function(){ this.style.background='transparent'; };
        row.onclick = function(){ div.remove(); openModal(ev.extendedProps.eventId); };
        row.innerHTML =
            '<span style="width:9px;height:9px;border-radius:50%;background:'+ev.color+';flex-shrink:0;display:inline-block;"></span>' +
            '<div style="flex:1;min-width:0;">' +
              '<div style="font-size:12px;font-weight:600;color:var(--text-primary);overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">' + ev.title + '</div>' +
              '<div style="font-size:10px;color:var(--text-muted);">' + (ev.extendedProps.time||'') + (ev.extendedProps.location ? ' · '+ev.extendedProps.location : '') + '</div>' +
            '</div>';
        div.appendChild(row);
    });
    document.body.appendChild(div);
}
</script>

<style>
/* Toolbar buttons */
.cal-nav-btn {
    width:34px;height:34px;border-radius:8px;border:1.5px solid var(--border);
    background:#fff;cursor:pointer;display:flex;align-items:center;justify-content:center;
    font-size:15px;color:var(--text-secondary);transition:all .15s;
}
.cal-nav-btn:hover { border-color:var(--red);color:var(--red);background:var(--red-light); }

.cal-today-btn {
    height:34px;padding:0 16px;border-radius:8px;border:1.5px solid var(--border);
    background:#fff;cursor:pointer;font-size:13px;font-weight:600;color:var(--text-secondary);transition:all .15s;
}
.cal-today-btn:hover { background:var(--red);color:#fff;border-color:var(--red); }

.cal-sel {
    height:34px;padding:0 10px;border-radius:8px;border:1.5px solid var(--border);
    font-size:14px;font-weight:600;color:var(--text-primary);background:#fff;
    cursor:pointer;outline:none;transition:border-color .15s;
}
.cal-sel:focus { border-color:var(--red); }

.cal-view-btn {
    height:34px;padding:0 16px;border-radius:8px;border:1.5px solid var(--border);
    background:#fff;color:var(--text-secondary);font-size:12px;font-weight:600;cursor:pointer;transition:all .15s;
}
.cal-view-btn:hover:not(.active-view) { border-color:var(--red);color:var(--red); }
.cal-view-btn.active-view { background:var(--red);color:#fff;border-color:var(--red); }

/* FullCalendar overrides */
#calendarEl .fc-button-primary          { background:var(--red)!important;border-color:var(--red)!important; }
#calendarEl .fc-daygrid-event           { border-radius:5px!important;font-size:11px!important;font-weight:600!important;padding:2px 6px!important;cursor:pointer!important;transition:transform .15s,box-shadow .15s!important; }
#calendarEl .fc-daygrid-event:hover     { transform:translateY(-1px)!important;box-shadow:0 3px 8px rgba(0,0,0,0.15)!important; }
#calendarEl .fc-col-header-cell         { background:var(--bg-page);font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:.06em;color:var(--text-muted);padding:10px 0; }
#calendarEl .fc-daygrid-day-number      { font-size:13px;font-weight:600;color:var(--text-primary);padding:6px 8px; }
#calendarEl .fc-day-today               { background:rgba(192,39,45,0.04)!important; }
#calendarEl .fc-day-today .fc-daygrid-day-number { color:var(--red);font-weight:800; }
#calendarEl .fc-more-link               { font-size:11px;font-weight:600;color:var(--red); }
#calendarEl .fc-list-event:hover td     { background:var(--red-light)!important;cursor:pointer; }
#calendarEl .fc-list-event-dot          { border-color:var(--red)!important; }
#calendarEl .fc-list-day-cushion        { background:var(--bg-page)!important;font-size:12px;font-weight:700; }
#calendarEl .fc-timegrid-event          { border-radius:6px!important;font-size:11px!important;font-weight:600!important; }
</style>

</body>
</html>
