<?php
/**
 * Modals.php — All Student Modals (DB-connected)
 */
$modalDepts = [];
try {
  $sc = $pdo->query("SELECT id, name FROM departments ORDER BY name ASC");
  $modalDepts = $sc->fetchAll(PDO::FETCH_ASSOC);
} catch (Exception $e) { $modalDepts = []; }
?>

<!-- ══ EVENT DETAIL MODAL ══ -->
<div class="modal-overlay" id="eventModal" onclick="closeModalOutside(event)">
  <div class="modal-box" id="modalBox">
    <div class="modal-banner-wrap">
      <div class="modal-banner" id="modalBanner">🎓</div>
      <button class="btn-modal-close" onclick="closeModal()"><i class="bi bi-x"></i></button>
    </div>
    <div class="modal-body">
      <div class="modal-cat-badge"><span class="event-cat-badge" id="modalBadge">Academic</span></div>
      <div class="modal-title" id="modalTitle">Event Title</div>

      <!-- Restriction / Closed notice -->
      <div id="modalRestrictionNotice" style="display:none;align-items:flex-start;gap:10px;background:#fef3c7;border:1.5px solid #fcd34d;border-radius:10px;padding:12px 14px;font-size:12.5px;color:#78350f;margin-bottom:14px;line-height:1.5;"></div>

      <div class="modal-meta-grid">
        <div class="modal-meta-item"><i class="bi bi-calendar3"></i><div><div style="font-weight:500;color:#111" id="modalDate">—</div><div>Date</div></div></div>
        <div class="modal-meta-item"><i class="bi bi-clock"></i><div><div style="font-weight:500;color:#111" id="modalTime">—</div><div>Time</div></div></div>
        <div class="modal-meta-item"><i class="bi bi-geo-alt"></i><div><div style="font-weight:500;color:#111" id="modalVenue">—</div><div>Venue</div></div></div>
        <div class="modal-meta-item"><i class="bi bi-people"></i><div><div style="font-weight:500;color:#111" id="modalAttendees">—</div><div>Attending</div></div></div>
      </div>

      <!-- Registration deadline row -->
      <div id="modalDeadline" style="display:none;font-size:12px;color:#b45309;margin-bottom:10px;align-items:center;gap:6px;background:#fffbeb;border-radius:7px;padding:6px 10px;">
        <i class="bi bi-calendar-check" style="color:#d97706;"></i><span></span>
      </div>

      <div style="font-size:12px;color:var(--text-muted);margin-bottom:12px;display:flex;align-items:center;gap:6px;">
        <i class="bi bi-building" style="color:var(--red)"></i><span id="modalOrg">—</span>
      </div>
      <div class="modal-desc" id="modalDesc">—</div>
      <div class="modal-footer">
        <button class="btn-join"       id="modalJoinBtn"  onclick="toggleJoin(this)">Register &amp; Join</button>
        <button class="btn-modal-save" id="modalSaveBtn"  onclick="toggleSaveModal(this)"><i class="bi bi-bookmark"></i> Save</button>
        <button class="btn-modal-save" id="modalShareBtn" onclick="shareEvent(this)" title="Share event" style="padding:11px 13px;"><i class="bi bi-share"></i></button>
      </div>
    </div>
  </div>
</div>

<!-- ══ ORGANIZATION MODAL ══ -->
<div class="modal-overlay" id="orgModal" onclick="closeOrgModalOutside(event)">
  <div class="modal-box">
    <div class="modal-banner-wrap">
      <div class="modal-banner academic" id="orgModalBanner" style="font-size:44px">🏛️</div>
      <button class="btn-modal-close" onclick="closeOrgModal()"><i class="bi bi-x"></i></button>
    </div>
    <div class="modal-body">
      <div class="modal-title"   id="orgModalName">Organization</div>
      <div style="font-size:13px;color:var(--text-secondary);margin-bottom:16px" id="orgModalMembers">—</div>
      <div class="modal-desc"    id="orgModalDesc">—</div>
      <div class="modal-footer">
        <button class="btn-join"       id="orgJoinBtn" onclick="toggleOrgJoin(this)">Join Organization</button>
        <button class="btn-modal-save" onclick="closeOrgModal()">Close</button>
      </div>
    </div>
  </div>
</div>

<!-- ══ PROFILE MODAL ══ -->
<div class="modal-overlay" id="profileModal" onclick="closeProfileOutside(event)">
  <div class="modal-box" style="max-width:520px;">
    <div class="modal-banner-wrap">
      <div class="modal-banner" style="background:linear-gradient(135deg,#1a0a0b,#3a1a1d);">
        <div style="width:72px;height:72px;border-radius:50%;background:var(--red);color:#fff;font-size:30px;font-weight:700;display:flex;align-items:center;justify-content:center;" id="profileModalAvatar">
          <?= htmlspecialchars($studentInitial) ?>
        </div>
      </div>
      <button class="btn-modal-close" onclick="closeProfile()"><i class="bi bi-x"></i></button>
    </div>
    <div class="modal-body">
      <div class="modal-title" style="margin-bottom:4px;">Edit Profile</div>
      <div style="font-size:12px;color:var(--text-muted);margin-bottom:20px;">Update your personal and academic details</div>
      <div style="display:grid;gap:14px;">

        <div>
          <label class="modal-field-label">Full Name *</label>
          <input id="profileName" type="text" class="modal-input" placeholder="e.g. Juan dela Cruz"
            value="<?= htmlspecialchars($student['full_name'] ?? '') ?>">
        </div>

        <div>
          <label class="modal-field-label">Course / Program</label>
          <input id="profileCourse" type="text" class="modal-input"
            placeholder="e.g. Bachelor of Science in Information Technology"
            value="<?= htmlspecialchars($student['course'] ?? '') ?>">
        </div>

        <div>
          <label class="modal-field-label">Email Address</label>
          <input type="email" class="modal-input" value="<?= htmlspecialchars($student['email'] ?? '') ?>"
            disabled style="background:#fafafa;cursor:not-allowed;color:var(--text-muted);">
          <div style="font-size:11px;color:var(--text-muted);margin-top:4px;"><i class="bi bi-info-circle"></i> Email cannot be changed here.</div>
        </div>

        <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;">
          <div>
            <label class="modal-field-label">Department</label>
            <select id="profileDepartment" class="modal-input">
              <option value="">— Select Department —</option>
              <?php foreach ($modalDepts as $col): ?>
              <option value="<?= $col['id'] ?>" <?= ($student['department_id'] == $col['id']) ? 'selected' : '' ?>>
                <?= htmlspecialchars($col['name']) ?>
              </option>
              <?php endforeach; ?>
            </select>
          </div>
          <div>
            <label class="modal-field-label">Year Level</label>
            <select id="profileYear" class="modal-input">
              <option value="">Select Year</option>
              <?php foreach (['1st Year','2nd Year','3rd Year','4th Year','5th Year','Graduate'] as $yr): ?>
              <option value="<?= $yr ?>" <?= ($student['year_level'] === $yr) ? 'selected' : '' ?>><?= $yr ?></option>
              <?php endforeach; ?>
            </select>
          </div>
        </div>

        <div>
          <label class="modal-field-label">Bio <span style="font-weight:400;">(optional)</span></label>
          <textarea id="profileBio" class="modal-input" placeholder="Tell others a bit about yourself..." rows="3"
            style="resize:vertical;"><?= htmlspecialchars($student['bio'] ?? '') ?></textarea>
        </div>

      </div>
      <div class="modal-footer" style="margin-top:22px;">
        <button type="button" class="btn-join" onclick="saveProfile()"><i class="bi bi-person-check me-1"></i>Save Profile</button>
        <button type="button" class="btn-modal-save" onclick="closeProfile()">Cancel</button>
      </div>
    </div>
  </div>
</div>

<!-- ══ SETTINGS MODAL ══ -->
<div class="modal-overlay" id="settingsModal" onclick="closeSettingsOutside(event)">
  <div class="modal-box" style="max-width:460px;">
    <div class="modal-banner-wrap">
      <div class="modal-banner" style="background:linear-gradient(135deg,#1a0a0b,#3a1a1d);font-size:44px;">⚙️</div>
      <button class="btn-modal-close" onclick="closeSettings()"><i class="bi bi-x"></i></button>
    </div>
    <div class="modal-body">
      <div class="modal-title" style="margin-bottom:4px;">Settings</div>
      <div style="font-size:12px;color:var(--text-muted);margin-bottom:20px;">Manage your account preferences</div>

      <div style="margin-bottom:22px;">
        <div class="modal-section-label"><i class="bi bi-lock me-1"></i>Change Password</div>
        <div style="display:grid;gap:10px;">
          <div>
            <label class="modal-field-label">Current Password</label>
            <div style="position:relative;">
              <input type="password" id="settingCurPw" class="modal-input" placeholder="Current password" style="padding-right:40px;">
              <button type="button" class="pw-eye-btn" onclick="togglePwVis('settingCurPw',this)"><i class="bi bi-eye"></i></button>
            </div>
          </div>
          <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px;">
            <div>
              <label class="modal-field-label">New Password</label>
              <div style="position:relative;">
                <input type="password" id="settingNewPw" class="modal-input" placeholder="Min 6 characters" style="padding-right:40px;">
                <button type="button" class="pw-eye-btn" onclick="togglePwVis('settingNewPw',this)"><i class="bi bi-eye"></i></button>
              </div>
            </div>
            <div>
              <label class="modal-field-label">Confirm Password</label>
              <div style="position:relative;">
                <input type="password" id="settingConfPw" class="modal-input" placeholder="Repeat password" style="padding-right:40px;">
                <button type="button" class="pw-eye-btn" onclick="togglePwVis('settingConfPw',this)"><i class="bi bi-eye"></i></button>
              </div>
            </div>
          </div>
          <div id="pwMismatchAlert" style="display:none;font-size:12px;color:#dc2626;padding:8px 12px;background:#fee2e2;border-radius:7px;">
            <i class="bi bi-exclamation-circle me-1"></i>Passwords do not match.
          </div>
          <button type="button" class="btn-join" style="width:fit-content;" onclick="savePassword()">
            <i class="bi bi-check-lg me-1"></i>Update Password
          </button>
        </div>
      </div>

      <div style="margin-bottom:20px;">
        <div class="modal-section-label"><i class="bi bi-bell me-1"></i>Notifications</div>
        <div style="display:flex;flex-direction:column;gap:10px;">
          <label class="settings-toggle">
            <span><span style="font-size:13px;font-weight:500;color:var(--text-primary);">Email Notifications</span><span style="font-size:11px;color:var(--text-muted);display:block;">Receive event reminders by email</span></span>
            <input type="checkbox" id="settingEmailNotif" checked><span class="toggle-slider"></span>
          </label>
          <label class="settings-toggle">
            <span><span style="font-size:13px;font-weight:500;color:var(--text-primary);">Event Reminders</span><span style="font-size:11px;color:var(--text-muted);display:block;">Remind me 1 day before saved events</span></span>
            <input type="checkbox" id="settingEventRemind" checked><span class="toggle-slider"></span>
          </label>
        </div>
      </div>

      <div style="background:#fef2f2;border:1.5px solid #fecaca;border-radius:10px;padding:14px;display:flex;align-items:center;justify-content:space-between;">
        <div>
          <div style="font-size:13px;font-weight:600;color:#b91c1c;">Sign Out</div>
          <div style="font-size:12px;color:var(--text-muted);">End your current session</div>
        </div>
        <a href="../logout.php" style="background:#ef4444;color:#fff;border:none;padding:8px 16px;border-radius:8px;font-size:13px;font-weight:500;text-decoration:none;display:flex;align-items:center;gap:6px;">
          <i class="bi bi-box-arrow-right"></i> Sign Out
        </a>
      </div>
    </div>
  </div>
</div>

<style>
.modal-field-label { font-size:12px;font-weight:600;color:var(--text-secondary);display:block;margin-bottom:5px; }
.modal-input { width:100%;padding:9px 12px;border:1.5px solid var(--border);border-radius:8px;font-size:13px;outline:none;font-family:Poppins,sans-serif;background:#fff;transition:border-color .15s; }
.modal-input:focus { border-color:var(--red); }
.modal-section-label { font-size:11px;font-weight:700;color:var(--text-muted);text-transform:uppercase;letter-spacing:.08em;margin-bottom:12px; }
.settings-toggle { display:flex;align-items:center;justify-content:space-between;cursor:pointer;padding:10px 14px;border-radius:9px;border:1.5px solid var(--border);transition:border-color .15s; }
.settings-toggle:hover { border-color:var(--red); }
.settings-toggle input[type="checkbox"] { display:none; }
.toggle-slider { width:40px;height:22px;background:#d1d5db;border-radius:11px;position:relative;flex-shrink:0;transition:background .2s; }
.toggle-slider::after { content:'';position:absolute;top:3px;left:3px;width:16px;height:16px;border-radius:50%;background:#fff;transition:transform .2s;box-shadow:0 1px 3px rgba(0,0,0,0.2); }
.settings-toggle input:checked ~ .toggle-slider { background:var(--red); }
.settings-toggle input:checked ~ .toggle-slider::after { transform:translateX(18px); }
.pw-eye-btn { position:absolute;right:10px;top:50%;transform:translateY(-50%);background:none;border:none;cursor:pointer;color:var(--text-muted);font-size:15px;padding:0; }
.pw-eye-btn:hover { color:var(--text-primary); }
</style>

<script>
function saveProfile() {
  var name    = document.getElementById('profileName').value.trim();
  var college = document.getElementById('profileDepartment').value;
  var year    = document.getElementById('profileYear').value;
  var bio     = document.getElementById('profileBio').value.trim();
  if (!name) { showToast('Full name is required','warning','bi-exclamation-circle'); return; }
  var fd = new FormData();
  fd.append('full_name',  name);
  fd.append('department_id', college);
  fd.append('course',     document.getElementById('profileCourse')?.value?.trim() || '');
  fd.append('year_level', year);
  fd.append('bio',        bio);
  fetch('actions/update_profile.php', { method:'POST', body:fd })
    .then(r => r.json()).then(res => {
      if (res.success) {
        document.querySelectorAll('.avatar-name').forEach(el => el.textContent = res.full_name);
        document.querySelectorAll('.avatar').forEach(el => el.textContent = res.initial);
        document.getElementById('profileModalAvatar').textContent = res.initial;
        var course = res.course || res.college_code || '';
        var yr = (res.year_level || '') + (res.year_level && course ? ' · ' : '') + course;
        document.querySelectorAll('.avatar-role').forEach(el => el.textContent = yr);
        closeProfile();
        showToast(res.msg || 'Profile updated!','success','bi-check-circle');
      } else { showToast(res.msg || 'Update failed','warning','bi-exclamation-circle'); }
    }).catch(() => showToast('Network error','warning','bi-wifi-off'));
}

function savePassword() {
  var cur   = document.getElementById('settingCurPw').value;
  var np    = document.getElementById('settingNewPw').value;
  var conf  = document.getElementById('settingConfPw').value;
  var alrt  = document.getElementById('pwMismatchAlert');
  if (!cur || !np || !conf) { showToast('Fill all password fields','warning','bi-exclamation-circle'); return; }
  if (np !== conf) { alrt.style.display='block'; return; }
  alrt.style.display = 'none';
  if (np.length < 6) { showToast('Password must be at least 6 characters','warning','bi-exclamation-circle'); return; }
  var fd = new FormData();
  fd.append('current_password', cur);
  fd.append('new_password',     np);
  fd.append('confirm_password', conf);
  fetch('actions/update_password.php', { method:'POST', body:fd })
    .then(r => r.json()).then(res => {
      if (res.success) {
        document.getElementById('settingCurPw').value = '';
        document.getElementById('settingNewPw').value = '';
        document.getElementById('settingConfPw').value = '';
        showToast('Password updated!','success','bi-check-circle');
      } else { showToast(res.msg || 'Failed','warning','bi-exclamation-circle'); }
    }).catch(() => showToast('Network error','warning','bi-wifi-off'));
}

function togglePwVis(id, btn) {
  var input = document.getElementById(id);
  var icon  = btn.querySelector('i');
  input.type = input.type === 'password' ? 'text' : 'password';
  icon.className = input.type === 'password' ? 'bi bi-eye' : 'bi bi-eye-slash';
}
</script>
