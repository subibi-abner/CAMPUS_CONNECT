<?php
/**
 * Sidebar.php — CampusConnect Student Navigation
 */

$activePage = $activePage ?? 'dashboard';
?>

<style>
.sidebar { width: 240px; background: var(--sidebar-bg); min-height: calc(100vh - 60px); padding: 16px 0 24px; display: flex; flex-direction: column; flex-shrink: 0; position: sticky; top: 60px; height: calc(100vh - 60px); overflow-y: auto; }
.sidebar-section-label { font-size: 10px; font-weight: 600; color: rgba(255,255,255,0.3); letter-spacing: 0.1em; text-transform: uppercase; padding: 16px 20px 6px; }
.nav-link-item { display: flex; align-items: center; gap: 12px; padding: 10px 20px; font-size: 13px; font-weight: 500; color: rgba(255,255,255,0.65); cursor: pointer; border-radius: 0; transition: all .15s; text-decoration: none; border: none; background: none; width: 100%; text-align: left; }
.nav-link-item i { font-size: 16px; width: 18px; flex-shrink: 0; }
.nav-link-item:hover { background: var(--sidebar-hover); color: rgba(255,255,255,0.9); }
.nav-link-item.active { background: var(--sidebar-active); color: #fff; border-left: 3px solid var(--red); padding-left: 17px; }
.nav-badge { margin-left: auto; background: var(--red); color: #fff; font-size: 10px; font-weight: 700; padding: 1px 7px; border-radius: 10px; min-width: 20px; text-align: center; }
.sidebar-footer { margin-top: auto; padding: 16px 20px 0; border-top: 1px solid rgba(255,255,255,0.08); }
.logout-btn { display: flex; align-items: center; gap: 10px; font-size: 13px; color: rgba(255,255,255,0.45); cursor: pointer; background: none; border: none; transition: color .15s; padding: 0; }
.logout-btn:hover { color: #ff6b6b; }
</style>

<aside class="sidebar">
  <div class="sidebar-section-label">Main</div>

  <a href="student.php" class="nav-link-item <?= $activePage === 'dashboard' ? 'active' : '' ?>" id="nav-dashboard">
    <i class="bi bi-grid-1x2"></i> Dashboard
  </a>

  <a href="Calendar.php" class="nav-link-item <?= $activePage === 'calendar' ? 'active' : '' ?>" id="nav-calendar">
    <i class="bi bi-calendar3"></i> Calendar
  </a>

  <a href="My events.php" class="nav-link-item <?= $activePage === 'myEvents' ? 'active' : '' ?>" id="nav-myEvents">
    <i class="bi bi-bookmark-heart"></i> My Events
    <span class="nav-badge" id="myEventsCount">0</span>
  </a>

  <div class="sidebar-section-label">Explore</div>

  <a href="student.php?cat=academic" class="nav-link-item <?= (isset($_GET['cat']) && $_GET['cat']==='academic') ? 'active' : '' ?>">
    <i class="bi bi-mortarboard"></i> Academic
  </a>
  <a href="student.php?cat=social" class="nav-link-item <?= (isset($_GET['cat']) && $_GET['cat']==='social') ? 'active' : '' ?>">
    <i class="bi bi-music-note-beamed"></i> Social
  </a>
  <a href="student.php?cat=sports" class="nav-link-item <?= (isset($_GET['cat']) && $_GET['cat']==='sports') ? 'active' : '' ?>">
    <i class="bi bi-trophy"></i> Sports
  </a>
  <a href="student.php?cat=org" class="nav-link-item <?= (isset($_GET['cat']) && $_GET['cat']==='org') ? 'active' : '' ?>">
    <i class="bi bi-people"></i> Organizations
  </a>

  <div class="sidebar-footer">
    <button class="logout-btn" onclick="confirmLogout()">
      <i class="bi bi-box-arrow-right" style="font-size:15px"></i> Sign Out
    </button>
  </div>
</aside>
