<?php
session_start();
require_once '../config.php';
require_once '../db_functions.php';
require_login('student');

$user_id = $_SESSION['user_id'];

$stmt = $pdo->prepare("
  SELECT u.*, d.name AS department_name, d.code AS dept_code
  FROM users u
  LEFT JOIN departments d ON u.department_id = d.id
  WHERE u.id = ?
");
$stmt->execute([$user_id]);
$student = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$student) { session_destroy(); header('Location: ../login.php'); exit; }

$studentName      = $student['full_name'] ?? 'Student';
$studentFirstName = explode(' ', $studentName)[0];
$studentInitial   = strtoupper(substr($studentName, 0, 1));

// Badge: prefer course abbreviation, fall back to dept code
$course    = $student['course'] ?? '';
$deptCode  = $student['dept_code'] ?? '';
// Remap CICT -> CCS (College of Computing Studies)
if ($deptCode === 'CICT') $deptCode = 'CCS';
$yearLevel = $student['year_level'] ?? '';

// Build short course label  e.g. "BSIT" from "Bachelor of Science in Information Technology"
if ($course) {
  // Try to extract known acronyms first
  $courseMap = [
    'information technology' => 'BSIT',
    'computer science'       => 'BSCS',
    'information systems'    => 'BSIS',
    'nursing'                => 'BSN',
    'education'              => 'BSED',
    'criminology'            => 'BSCrim',
    'engineering'            => 'BSENG',
    'social work'            => 'BSSW',
    'medicine'               => 'MD',
    'law'                    => 'JD',
  ];
  $courseLabel = '';
  $courseLower = strtolower($course);
  foreach ($courseMap as $keyword => $abbr) {
    if (strpos($courseLower, $keyword) !== false) {
      $courseLabel = $abbr;
      break;
    }
  }
  if (!$courseLabel) {
    // Fallback: initials of uppercase words
    preg_match_all('/\b[A-Z]/', $course, $m);
    $courseLabel = implode('', $m[0]) ?: $deptCode ?: 'WMSU';
  }
} else {
  $courseLabel = $deptCode ?: 'WMSU';
}

$studentYear = trim($yearLevel . ($yearLevel && $courseLabel ? ' · ' : '') . $courseLabel, ' · ');
$activePage  = 'dashboard';
$filterCat   = isset($_GET['cat']) ? htmlspecialchars($_GET['cat']) : null;
?>
<?php include 'Header.php'; ?>
<body>
<div class="toast-container" id="toastContainer"></div>
<?php include 'Modals.php'; ?>
<?php include 'Navbar.php'; ?>
<?php include 'Notification.php'; ?>
<div class="layout">
  <?php include 'Sidebar.php'; ?>
  <main class="main">
    <?php include 'Dashboard.php'; ?>
  </main>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="App.js"></script>
<?php if ($filterCat): ?>
<script>
  document.addEventListener('DOMContentLoaded', function() { filterCat(null, '<?= $filterCat ?>'); });
</script>
<?php endif; ?>
</body>
</html>
