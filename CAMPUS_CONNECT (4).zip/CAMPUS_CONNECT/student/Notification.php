<?php
/**
 * Notification.php — CampusConnect Notification Panel
 * Shows real upcoming events as notifications (events starting within 7 days)
 */

// Fetch real upcoming events for notification panel
$notifEvents = [];
if (isset($pdo) && isset($user_id)) {
    $stmtNotif = $pdo->prepare("
        SELECT e.id, e.title, e.event_date, e.category,
               EXISTS(SELECT 1 FROM registrations r WHERE r.event_id = e.id AND r.user_id = ?) AS is_joined
        FROM events e
        WHERE e.status = 'approved'
          AND e.event_date >= NOW()
          AND e.event_date <= DATE_ADD(NOW(), INTERVAL 14 DAY)
        ORDER BY e.event_date ASC
        LIMIT 6
    ");
    $stmtNotif->execute([$user_id]);
    $notifEvents = $stmtNotif->fetchAll(PDO::FETCH_ASSOC);
}

function notifIcon($cat) {
    $c = strtolower($cat ?? '');
    if (strpos($c,'sport')!==false||strpos($c,'intramural')!==false) return ['bi-trophy','red'];
    if (strpos($c,'academic')!==false||strpos($c,'research')!==false||strpos($c,'workshop')!==false) return ['bi-mortarboard','blue'];
    if (strpos($c,'social')!==false||strpos($c,'cultural')!==false) return ['bi-music-note','purple'];
    return ['bi-calendar-event','green'];
}
function notifDaysLabel($dateStr) {
    $diff = (int)ceil((strtotime($dateStr) - time()) / 86400);
    if ($diff <= 0)  return 'Today!';
    if ($diff === 1) return 'Tomorrow';
    return "In $diff days";
}
?>

<div class="notif-panel" id="notifPanel">

  <div class="notif-panel-header">
    <span class="notif-panel-title">
      <i class="bi bi-bell me-2" style="color:var(--red)"></i>Upcoming Events
    </span>
    <div class="notif-panel-actions">
      <button class="notif-mark-all" onclick="markAllRead()" title="Mark all as read">
        <i class="bi bi-check-all me-1"></i>Mark all read
      </button>
      <button class="notif-close" onclick="toggleNotif()" title="Close"><i class="bi bi-x"></i></button>
    </div>
  </div>

  <div class="notif-list">
    <?php if (empty($notifEvents)): ?>
    <div style="padding:32px 18px;text-align:center;color:var(--text-muted);">
      <i class="bi bi-bell-slash" style="font-size:32px;display:block;margin-bottom:10px;"></i>
      <div style="font-size:13px;font-weight:500;">No upcoming events in the next 14 days</div>
    </div>
    <?php else: ?>
    <?php foreach ($notifEvents as $ni => $nev):
        [$icon, $color] = notifIcon($nev['category']);
        $daysLabel = notifDaysLabel($nev['event_date']);
        $timeStr   = date('M j, g:i A', strtotime($nev['event_date']));
        $isJoined  = (bool)$nev['is_joined'];
    ?>
    <div
      class="notif-item <?= $ni < 3 ? 'unread' : '' ?>"
      id="notif<?= $nev['id'] ?>"
      style="position:relative;"
    >
      <div style="display:flex;gap:12px;flex:1;cursor:pointer;"
           onclick="openNotifEvent(<?= $nev['id'] ?>); markOneRead(<?= $nev['id'] ?>);">
        <div class="notif-item-icon <?= $color ?>">
          <i class="bi <?= $icon ?>"></i>
        </div>
        <div style="flex:1">
          <div class="notif-item-text">
            <strong><?= htmlspecialchars($nev['title']) ?></strong>
            <?= $isJoined ? ' — <span style="color:#059669;font-size:11px;font-weight:600;"><i class="bi bi-check-circle-fill"></i> Registered</span>' : '' ?>
          </div>
          <div class="notif-item-time">
            <i class="bi bi-clock" style="font-size:10px;"></i>
            <?= htmlspecialchars($timeStr) ?> &nbsp;·&nbsp;
            <span style="color:var(--red);font-weight:600;"><?= htmlspecialchars($daysLabel) ?></span>
          </div>
        </div>
        <?php if ($ni < 3): ?>
          <div class="notif-unread-dot" style="margin-top:6px;"></div>
        <?php endif; ?>
      </div>
      <button
        onclick="dismissNotif(<?= $nev['id'] ?>, event)"
        title="Dismiss"
        style="position:absolute;top:8px;right:8px;background:none;border:none;cursor:pointer;color:var(--text-muted);font-size:13px;width:22px;height:22px;display:flex;align-items:center;justify-content:center;border-radius:4px;opacity:0;transition:opacity .15s;"
        class="notif-dismiss-btn"
      ><i class="bi bi-x"></i></button>
    </div>
    <?php endforeach; ?>
    <?php endif; ?>
  </div>

  <div style="padding:12px 18px;border-top:1px solid var(--border);text-align:center;">
    <a href="Calendar.php" style="font-size:12px;color:var(--red);text-decoration:none;font-weight:500;">
      <i class="bi bi-calendar3 me-1"></i>View Full Calendar
    </a>
  </div>

</div>

<style>
.notif-item:hover .notif-dismiss-btn { opacity: 1 !important; }
</style>
