<?php
session_start();
include 'db.php';

$officer_id = $_SESSION['officer_id'];

$title = $_POST['title'];
$desc = $_POST['description'];
$date = $_POST['date'];

$conn->query("INSERT INTO events (title, description, event_date, officer_id)
VALUES ('$title','$desc','$date',$officer_id)");

header("Location: officer.php");