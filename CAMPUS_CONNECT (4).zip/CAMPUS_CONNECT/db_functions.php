<?php
/**
 * db_functions.php — CampusConnect shared helpers
 *
 * FIXES applied:
 *  1. get_upcoming_events() now returns department_id so callers can
 *     enforce college restrictions without a second query.
 *  2. join_event() is replaced by join_event_safe() that validates:
 *       a) event exists and is approved
 *       b) department/college restriction
 *       c) registration deadline
 *       d) max_attendees cap
 *     It returns ['success'=>bool, 'msg'=>string, 'joined'=>bool].
 *  3. require_login() path is kept compatible with existing code.
 */

require_once 'config.php';  // provides $pdo

// ─────────────────────────────────────────────────────────────
// EVENT FETCHING
// ─────────────────────────────────────────────────────────────

/**
 * Fetch all upcoming approved events.
 * Includes department_id so the caller can determine registration eligibility.
 */
function get_upcoming_events($pdo) {
    $stmt = $pdo->prepare("
        SELECT e.*,
               o.name    AS org_name,
               o.acronym AS org_acronym,
               d.name    AS dept_name,
               d.code    AS dept_code,
               (SELECT COUNT(*) FROM registrations r WHERE r.event_id = e.id) AS attendee_count
        FROM   events e
        LEFT JOIN organizations o ON e.org_id       = o.id
        LEFT JOIN departments   d ON e.department_id = d.id
        WHERE  e.status = 'approved'
          AND  e.event_date > NOW()
        ORDER BY e.event_date ASC
        LIMIT 50
    ");
    $stmt->execute();
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

/**
 * Fetch upcoming approved events visible to a specific student.
 * All students can VIEW all events; registration eligibility is a
 * separate flag (can_register) that the caller must check.
 *
 * @param PDO $pdo
 * @param int $user_id      The logged-in student's id
 * @param int $student_dept The student's department_id (0 if unknown)
 * @return array  Each row has extra flags: is_joined, is_saved,
 *                can_register, is_restricted, restrict_label,
 *                deadline_passed, is_full
 */
function get_events_for_student($pdo, $user_id, $student_dept = 0) {
    $stmt = $pdo->prepare("
        SELECT e.*,
               u.full_name  AS organizer_name,
               o.name       AS org_name,
               o.acronym    AS org_acronym,
               o.id         AS org_id,
               d.name       AS dept_name,
               d.code       AS dept_code,
               (SELECT COUNT(*) FROM registrations r WHERE r.event_id = e.id)               AS attendee_count,
               EXISTS(SELECT 1 FROM registrations r WHERE r.event_id = e.id AND r.user_id=?) AS is_joined,
               EXISTS(SELECT 1 FROM saved_events  s WHERE s.event_id = e.id AND s.user_id=?) AS is_saved
        FROM   events e
        LEFT JOIN users         u ON e.organizer_id  = u.id
        LEFT JOIN organizations o ON e.org_id        = o.id
        LEFT JOIN departments   d ON e.department_id = d.id
        WHERE  e.status = 'approved'
          AND  e.event_date > NOW()
        ORDER BY e.event_date ASC
    ");
    $stmt->execute([$user_id, $user_id]);
    $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

    foreach ($rows as &$ev) {
        $restricted     = !empty($ev['department_id']);
        $deptMatch      = !$restricted || ((int)$ev['department_id'] === (int)$student_dept);
        $deadlinePassed = !empty($ev['registration_deadline'])
                          && strtotime($ev['registration_deadline'] . ' 23:59:59') < time();
        $maxSlots       = max(1, (int)($ev['max_attendees'] ?? $ev['capacity'] ?? 100));
        $isFull         = (int)$ev['attendee_count'] >= $maxSlots;

        $ev['can_register']   = $deptMatch && !$deadlinePassed && !$isFull;
        $ev['is_restricted']  = $restricted && !$deptMatch;
        $ev['restrict_label'] = $restricted ? ($ev['dept_name'] ?? $ev['dept_code'] ?? 'specific department') : '';
        $ev['deadline_passed']= $deadlinePassed;
        $ev['is_full']        = $isFull;
    }
    unset($ev);

    return $rows;
}

/**
 * Fetch events the student is registered for.
 */
function get_user_events($pdo, $user_id) {
    $stmt = $pdo->prepare("
        SELECT e.*,
               o.name    AS org_name,
               o.acronym AS org_acronym
        FROM   events e
        JOIN   registrations r ON e.id = r.event_id
        LEFT JOIN organizations o ON e.org_id = o.id
        WHERE  r.user_id = ?
          AND  e.event_date > NOW()
        ORDER BY e.event_date ASC
    ");
    $stmt->execute([$user_id]);
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

// ─────────────────────────────────────────────────────────────
// REGISTRATION  (backend-enforced college restriction)
// ─────────────────────────────────────────────────────────────

/**
 * Attempt to register (or un-register) a student for an event.
 *
 * All business rules are enforced HERE so they cannot be bypassed
 * even if the front-end is manipulated.
 *
 * @return array ['success'=>bool, 'joined'=>bool|null, 'msg'=>string]
 */
function join_event_safe($pdo, $user_id, $event_id) {
    $user_id  = (int)$user_id;
    $event_id = (int)$event_id;

    if (!$user_id || !$event_id) {
        return ['success' => false, 'joined' => null, 'msg' => 'Invalid parameters'];
    }

    // 1. Fetch event
    $stmt = $pdo->prepare("SELECT * FROM events WHERE id = ? AND status = 'approved'");
    $stmt->execute([$event_id]);
    $event = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$event) {
        return ['success' => false, 'joined' => null, 'msg' => 'Event not found or not approved'];
    }

    // 2. Fetch student's department
    $uStmt = $pdo->prepare("SELECT department_id FROM users WHERE id = ?");
    $uStmt->execute([$user_id]);
    $user = $uStmt->fetch(PDO::FETCH_ASSOC);

    if (!$user) {
        return ['success' => false, 'joined' => null, 'msg' => 'Student not found'];
    }

    // 3. College / department restriction check
    if (!empty($event['department_id'])) {
        if ((int)$user['department_id'] !== (int)$event['department_id']) {
            // Fetch the college name for a clear error message
            $dStmt = $pdo->prepare("SELECT name FROM departments WHERE id = ?");
            $dStmt->execute([$event['department_id']]);
            $dept = $dStmt->fetch(PDO::FETCH_ASSOC);
            $deptName = $dept['name'] ?? 'a specific college';
            return [
                'success' => false,
                'joined'  => null,
                'msg'     => "This event is restricted to {$deptName} students only."
            ];
        }
    }

    // 4. Registration deadline check
    if (!empty($event['registration_deadline'])) {
        if (time() > strtotime($event['registration_deadline'] . ' 23:59:59')) {
            return ['success' => false, 'joined' => null, 'msg' => 'Registration deadline has passed for this event'];
        }
    }

    // 5. Already registered? → unregister
    $check = $pdo->prepare("SELECT id FROM registrations WHERE user_id = ? AND event_id = ?");
    $check->execute([$user_id, $event_id]);

    if ($check->fetch()) {
        $del = $pdo->prepare("DELETE FROM registrations WHERE user_id = ? AND event_id = ?");
        $del->execute([$user_id, $event_id]);
        return ['success' => true, 'joined' => false, 'msg' => 'Registration cancelled'];
    }

    // 6. Capacity check
    $maxSlots = max(1, (int)($event['max_attendees'] ?? $event['capacity'] ?? 100));
    $cntStmt  = $pdo->prepare("SELECT COUNT(*) FROM registrations WHERE event_id = ?");
    $cntStmt->execute([$event_id]);
    if ((int)$cntStmt->fetchColumn() >= $maxSlots) {
        return ['success' => false, 'joined' => null, 'msg' => 'This event is already full'];
    }

    // 7. Register
    $ins = $pdo->prepare("INSERT IGNORE INTO registrations (user_id, event_id) VALUES (?, ?)");
    $ins->execute([$user_id, $event_id]);

    // Generate QR attendance token (safe to run even if table doesn't exist yet)
    try {
        $token  = bin2hex(random_bytes(32));
        $tokStmt = $pdo->prepare("INSERT IGNORE INTO attendance_tokens (event_id, user_id, token) VALUES (?, ?, ?)");
        $tokStmt->execute([$event_id, $user_id, $token]);
    } catch (PDOException $e) {
        // attendance_tokens table may not exist; registration still succeeds
    }

    return ['success' => true, 'joined' => true, 'msg' => 'Successfully registered!'];
}

/**
 * Legacy wrapper — kept for any existing callers.
 * Use join_event_safe() for new code.
 */
function join_event($pdo, $user_id, $event_id) {
    $result = join_event_safe($pdo, $user_id, $event_id);
    return $result['success'];
}

// ─────────────────────────────────────────────────────────────
// AUTH
// ─────────────────────────────────────────────────────────────

function authenticate($pdo, $email, $password) {
    $stmt = $pdo->prepare("SELECT * FROM users WHERE email = ?");
    $stmt->execute([$email]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);
    if ($user && password_verify($password, $user['password'])) {
        $_SESSION['user_id']      = $user['id'];
        $_SESSION['role']         = $user['role'];
        $_SESSION['full_name']    = $user['full_name'];
        $_SESSION['email']        = $user['email'];
        $_SESSION['department_id']= $user['department_id']; // store for restriction checks
        return $user;
    }
    return false;
}

function require_login($role = null) {
    if (!isset($_SESSION['user_id'])) {
        header('Location: /CAMPUS_CONNECT/login.php'); exit;
    }
    if ($role && $_SESSION['role'] !== $role) {
        switch ($_SESSION['role']) {
            case 'admin':     header('Location: /CAMPUS_CONNECT/admin/dashboard.php');   break;
            case 'organizer': header('Location: /CAMPUS_CONNECT/officer/dashboard.php'); break;
            case 'staff':     header('Location: /CAMPUS_CONNECT/staff/staff.php');       break;
            default:          header('Location: /CAMPUS_CONNECT/student/student.php');   break;
        }
        exit;
    }
}

// ─────────────────────────────────────────────────────────────
// MISC HELPERS (unchanged)
// ─────────────────────────────────────────────────────────────

function get_staff_event($pdo, $staff_id) {
    $stmt = $pdo->prepare("
        SELECT e.*, es.assigned_at, u.full_name AS assigned_by_name
        FROM   event_staff es
        JOIN   events e ON es.event_id = e.id
        JOIN   users  u ON es.assigned_by = u.id
        WHERE  es.staff_id = ?
        LIMIT 1
    ");
    $stmt->execute([$staff_id]);
    return $stmt->fetch(PDO::FETCH_ASSOC);
}

function get_user($pdo, $user_id) {
    $stmt = $pdo->prepare("
        SELECT u.*, d.name AS department_name, d.code AS dept_code
        FROM   users u
        LEFT JOIN departments d ON u.department_id = d.id
        WHERE  u.id = ?
    ");
    $stmt->execute([$user_id]);
    return $stmt->fetch(PDO::FETCH_ASSOC);
}

function get_departments($pdo) {
    return $pdo->query("SELECT id, name FROM departments ORDER BY name ASC")
               ->fetchAll(PDO::FETCH_ASSOC);
}
