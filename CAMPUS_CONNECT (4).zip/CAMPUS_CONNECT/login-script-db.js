// Complete login-script-db.js with full functions from original + backend fetch

function switchToSignUp() {
  document.getElementById('loginForm').style.display = 'none';
  document.getElementById('signupForm').style.display = 'block';
  document.getElementById('welcomeLogin').style.display = 'none';
  document.getElementById('welcomeSignup').style.display = 'block';
  clearLoginErrors();
}

function switchToLogin() {
  document.getElementById('loginForm').style.display = 'block';
  document.getElementById('signupForm').style.display = 'none';
  document.getElementById('welcomeLogin').style.display = 'block';
  document.getElementById('welcomeSignup').style.display = 'none';
  clearSignupErrors();
}

function togglePass(inputId, iconId) {
  const inp = document.getElementById(inputId);
  const icon = document.getElementById(iconId);
  const show = inp.type === 'password';
  inp.type = show ? 'text' : 'password';
  icon.className = show ? 'bi bi-eye-slash' : 'bi bi-eye';
}

function isValidEmail(v) { 
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v); 
}

function showErr(inputId, errId, msg) {
  document.getElementById(inputId).classList.add('is-invalid');
  const el = document.getElementById(errId);
  el.textContent = msg;
  el.style.display = 'block';
}

function clearErr(inputId, errId) {
  document.getElementById(inputId).classList.remove('is-invalid');
  const el = document.getElementById(errId);
  el.textContent = '';
  el.style.display = 'none';
}

function clearLoginErrors() {
  clearErr('login-email', 'login-email-error');
  clearErr('login-password', 'login-pass-error');
}

function clearSignupErrors() {
  clearErr('reg-name', 'reg-name-error');
  clearErr('reg-email', 'reg-email-error');
  clearErr('reg-password', 'reg-pass-error');
}

function setLoading(btnId, spinnerId, textId, msg) {
  const btn = document.getElementById(btnId);
  btn.disabled = true;
  document.getElementById(spinnerId).style.display = 'inline-block';
  document.getElementById(textId).textContent = msg;
}

function resetLoading(btnId, spinnerId, textId, msg) {
  const btn = document.getElementById(btnId);
  btn.disabled = false;
  document.getElementById(spinnerId).style.display = 'none';
  document.getElementById(textId).textContent = msg;
}

function showToast(msg) {
  document.getElementById('toast-msg').textContent = msg;
  const toast = new bootstrap.Toast(document.getElementById('appToast'));
  toast.show();
}

async function handleLogin() {
  clearLoginErrors();
  const email = document.getElementById('login-email').value.trim();
  const pass = document.getElementById('login-password').value;
  let valid = true;

  if (!isValidEmail(email)) { 
    showErr('login-email', 'login-email-error', 'Valid email required'); 
    valid = false; 
  }
  if (!pass) { 
    showErr('login-password', 'login-pass-error', 'Password required'); 
    valid = false; 
  }
  if (!valid) return;

  const formData = new FormData();
  formData.append('action', 'login');
  formData.append('email', email);
  formData.append('password', pass);

  setLoading('loginBtn', 'login-spinner', 'login-btn-text', 'Logging in...');

  try {
    const response = await fetch('login-backend.php', {
      method: 'POST',
      body: formData
    });
    const result = await response.json();

    if (result.success) {
      window.location.href = result.redirect || 'student.php';
    } else {
      showErr('login-email', 'login-email-error', result.message || 'Login failed');
    }
  } catch (e) {
    showErr('login-email', 'login-email-error', 'Network error');
  }

  resetLoading('loginBtn', 'login-spinner', 'login-btn-text', 'Log In');
}

async function handleSignUp() {
  clearSignupErrors();
  const name = document.getElementById('reg-name').value.trim();
  const email = document.getElementById('reg-email').value.trim();
  const pass = document.getElementById('reg-password').value;
  let valid = true;

  if (!name) { 
    showErr('reg-name', 'reg-name-error', 'Full name required'); 
    valid = false; 
  }
  if (!isValidEmail(email)) { 
    showErr('reg-email', 'reg-email-error', 'Valid email required'); 
    valid = false; 
  }
  if (pass.length < 6) { 
    showErr('reg-password', 'reg-pass-error', 'Password min 6 chars'); 
    valid = false; 
  }
  if (!valid) return;

  const formData = new FormData();
  formData.append('action', 'signup');
  formData.append('name', name);
  formData.append('email', email);
  formData.append('password', pass);

  setLoading('signupBtn', 'signup-spinner', 'signup-btn-text', 'Creating...');

  try {
    const response = await fetch('login-backend.php', {
      method: 'POST',
      body: formData
    });
    const result = await response.json();

    if (result.success) {
      showToast('Account created! Please log in.');
      switchToLogin();
      document.getElementById('reg-name').value = '';
      document.getElementById('reg-email').value = '';
      document.getElementById('reg-password').value = '';
    } else {
      showErr('reg-email', 'reg-email-error', result.message || 'Signup failed');
    }
  } catch (e) {
    showErr('reg-email', 'reg-email-error', 'Network error');
  }

  resetLoading('signupBtn', 'signup-spinner', 'signup-btn-text', 'Sign Up');
}

// Enter key
document.addEventListener('keydown', e => {
  if (e.key === 'Enter') {
    const loginForm = document.getElementById('loginForm');
    if (loginForm.style.display !== 'none') handleLogin();
    else handleSignUp();
  }
});

