<?php
session_start();
require_once '../config.php';
require_once '../db_functions.php';
require_login('organizer');

$user_id     = $_SESSION['user_id'];
$active_page = 'analytics';

// Fetch all events belonging to this officer
$stmt = $pdo->prepare("SELECT id, title, event_date, capacity, status FROM events WHERE organizer_id = ? ORDER BY event_date DESC");
$stmt->execute([$user_id]);
$eventsArr = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Build analytics per event
$analytics = [];
foreach ($eventsArr as $e) {
    $eid = (int)$e['id'];
    $cap = max(1, (int)($e['capacity'] ?? 100));

    // Total participants (approved registrations)
    $s = $pdo->prepare("SELECT COUNT(*) FROM registrations WHERE event_id = ? AND COALESCE(approval_status,'approved') = 'approved'");
    $s->execute([$eid]);
    $participants = (int)$s->fetchColumn();

    // Total registrations (all statuses)
    $s = $pdo->prepare("SELECT COUNT(*) FROM registrations WHERE event_id = ?");
    $s->execute([$eid]);
    $total_reg = (int)$s->fetchColumn();

    // Attendance: those who timed in
    $s = $pdo->prepare("SELECT COUNT(*) FROM attendance WHERE event_id = ? AND time_in IS NOT NULL");
    $s->execute([$eid]);
    $attended = (int)$s->fetchColumn();

    // Completed attendance (both time_in and time_out)
    $s = $pdo->prepare("SELECT COUNT(*) FROM attendance WHERE event_id = ? AND time_in IS NOT NULL AND time_out IS NOT NULL");
    $s->execute([$eid]);
    $completed = (int)$s->fetchColumn();

    // Attendance rate = attended / participants
    $attendance_rate = $participants > 0 ? round($attended / $participants * 100, 1) : 0;

    // Drop-off rate = those who timed in but NOT timed out (left early) / attended
    $dropped_off = $attended - $completed;
    $dropoff_rate = $attended > 0 ? round($dropped_off / $attended * 100, 1) : 0;

    // No-show = registered (approved) but never timed in
    $no_show = max(0, $participants - $attended);

    $analytics[] = [
        'id'              => $eid,
        'title'           => $e['title'],
        'event_date'      => $e['event_date'],
        'status'          => $e['status'],
        'capacity'        => $cap,
        'total_reg'       => $total_reg,
        'participants'    => $participants,
        'attended'        => $attended,
        'completed'       => $completed,
        'no_show'         => $no_show,
        'dropped_off'     => $dropped_off,
        'attendance_rate' => $attendance_rate,
        'dropoff_rate'    => $dropoff_rate,
    ];
}

// Summary totals for top stat cards
$sum_participants    = array_sum(array_column($analytics, 'participants'));
$sum_attended        = array_sum(array_column($analytics, 'attended'));
$sum_dropped         = array_sum(array_column($analytics, 'dropped_off'));
$overall_att_rate    = $sum_participants > 0 ? round($sum_attended / $sum_participants * 100, 1) : 0;
$overall_drop_rate   = $sum_attended   > 0 ? round($sum_dropped  / $sum_attended   * 100, 1) : 0;
$completed_events    = count(array_filter($eventsArr, fn($e) => $e['status'] === 'completed'));
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Event Analytics – CampusConnect</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="css/officer.css">
  <style>
    /* ── Summary stat cards ─────────────────────────────── */
    .analytics-stats {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
      gap: 16px;
      margin-bottom: 28px;
    }
    .a-stat {
      background: #fff;
      border-radius: 14px;
      padding: 20px 22px;
      box-shadow: 0 1px 4px rgba(0,0,0,.07);
      display: flex;
      align-items: center;
      gap: 16px;
    }
    .a-stat-icon {
      width: 46px; height: 46px;
      border-radius: 12px;
      display: flex; align-items: center; justify-content: center;
      font-size: 20px; flex-shrink: 0;
    }
    .a-stat-icon.blue   { background: #eff6ff; color: #1d4ed8; }
    .a-stat-icon.green  { background: #f0fdf4; color: #15803d; }
    .a-stat-icon.red    { background: #fef2f2; color: #b91c1c; }
    .a-stat-icon.purple { background: #f5f3ff; color: #6d28d9; }
    .a-stat-val  { font-size: 26px; font-weight: 700; color: var(--text-primary); line-height: 1; }
    .a-stat-lbl  { font-size: 12px; color: var(--text-muted); margin-top: 3px; }

    /* ── Toolbar ─────────────────────────────────────────── */
    .analytics-toolbar {
      display: flex; align-items: center; gap: 12px;
      flex-wrap: wrap; margin-bottom: 18px;
    }
    .analytics-toolbar select,
    .analytics-toolbar input[type=text] {
      padding: 8px 12px;
      border: 1px solid var(--border);
      border-radius: 8px;
      font-size: 13px;
      font-family: inherit;
      background: #fff;
      color: var(--text-primary);
    }
    .analytics-toolbar input[type=text] { min-width: 220px; }

    /* ── Analytics table ─────────────────────────────────── */
    .analytics-table { width: 100%; border-collapse: collapse; }
    .analytics-table thead th {
      font-size: 11.5px; font-weight: 600;
      color: var(--text-muted); text-transform: uppercase;
      letter-spacing: .04em; padding: 10px 14px;
      border-bottom: 1px solid var(--border);
      white-space: nowrap;
    }
    .analytics-table tbody tr { transition: background .15s; }
    .analytics-table tbody tr:hover { background: #f8fafc; }
    .analytics-table tbody td {
      padding: 13px 14px; font-size: 13px;
      border-bottom: 1px solid #f1f5f9;
      vertical-align: middle;
    }

    /* ── Progress bar (mini) ─────────────────────────────── */
    .mini-bar-wrap { display: flex; align-items: center; gap: 8px; min-width: 120px; }
    .mini-bar-track { flex: 1; height: 7px; background: #e2e8f0; border-radius: 99px; overflow: hidden; }
    .mini-bar-fill  { height: 100%; border-radius: 99px; transition: width .4s; }
    .mini-bar-fill.green  { background: #22c55e; }
    .mini-bar-fill.yellow { background: #f59e0b; }
    .mini-bar-fill.red    { background: #ef4444; }
    .mini-bar-pct { font-size: 12px; font-weight: 600; width: 38px; text-align: right; }

    /* ── Detail modal ────────────────────────────────────── */
    .modal-overlay { display: none; position: fixed; inset: 0;
      background: rgba(0,0,0,.45); z-index: 1000;
      align-items: center; justify-content: center; }
    .modal-overlay.open { display: flex; }
    .modal-box {
      background: #fff; border-radius: 16px; padding: 30px;
      width: 100%; max-width: 560px;
      box-shadow: 0 20px 60px rgba(0,0,0,.2);
      max-height: 90vh; overflow-y: auto;
    }
    .modal-title { font-size: 16px; font-weight: 700; margin: 0 0 4px; }
    .modal-sub   { font-size: 12px; color: var(--text-muted); margin-bottom: 22px; }
    .modal-close-btn {
      float: right; background: none; border: none;
      font-size: 20px; cursor: pointer; color: var(--text-muted);
      margin-top: -4px;
    }
    .detail-grid {
      display: grid; grid-template-columns: 1fr 1fr;
      gap: 14px; margin-bottom: 20px;
    }
    .detail-card {
      background: #f8fafc; border-radius: 10px; padding: 14px 16px;
    }
    .detail-card .dc-val { font-size: 24px; font-weight: 700; color: var(--text-primary); }
    .detail-card .dc-lbl { font-size: 11px; color: var(--text-muted); margin-top: 2px; }
    .detail-card.green-bg { background: #f0fdf4; }
    .detail-card.red-bg   { background: #fef2f2; }
    .detail-card.yellow-bg { background: #fffbeb; }
    .detail-card.purple-bg { background: #f5f3ff; }

    .detail-bar-section { margin-top: 8px; }
    .detail-bar-label { font-size: 12px; font-weight: 600; color: var(--text-secondary); margin-bottom: 6px; display: flex; justify-content: space-between; }
    .detail-bar-track { height: 10px; background: #e2e8f0; border-radius: 99px; overflow: hidden; margin-bottom: 10px; }
    .detail-bar-fill  { height: 100%; border-radius: 99px; }
    .detail-bar-fill.green  { background: #22c55e; }
    .detail-bar-fill.yellow { background: #f59e0b; }
    .detail-bar-fill.red    { background: #ef4444; }

    /* ── Empty state ─────────────────────────────────────── */
    .empty-analytics {
      text-align: center; padding: 60px 20px;
      color: var(--text-muted);
    }
    .empty-analytics i { font-size: 48px; display: block; margin-bottom: 12px; opacity: .4; }
    .empty-analytics p { font-size: 14px; }

    /* ── Badge colours (reuse existing classes if present) ── */
    .badge { display:inline-block; padding:2px 10px; border-radius:99px; font-size:11px; font-weight:600; }
    .badge-completed { background:#f0fdf4; color:#15803d; }
    .badge-approved  { background:#eff6ff; color:#1d4ed8; }
    .badge-ongoing   { background:#fdf4ff; color:#7e22ce; }
    .badge-pending   { background:#fefce8; color:#92400e; }
    .badge-draft     { background:#f1f5f9; color:#475569; }
    .badge-rejected  { background:#fef2f2; color:#b91c1c; }
  </style>
</head>
<body>

<?php include 'header.php'; ?>

<div class="layout">
<?php include 'sidebar.php'; ?>

<main class="main">

  <div class="page-header">
    <div>
      <div class="page-title">Event Analytics</div>
      <div class="page-sub"><?= count($eventsArr) ?> events &bull; performance overview</div>
    </div>
  </div>

  <!-- ── Summary Cards ─────────────────────────────────── -->
  <div class="analytics-stats">
    <div class="a-stat">
      <div class="a-stat-icon blue"><i class="bi bi-people-fill"></i></div>
      <div>
        <div class="a-stat-val"><?= number_format($sum_participants) ?></div>
        <div class="a-stat-lbl">Total Participants</div>
      </div>
    </div>
    <div class="a-stat">
      <div class="a-stat-icon green"><i class="bi bi-person-check-fill"></i></div>
      <div>
        <div class="a-stat-val"><?= $overall_att_rate ?>%</div>
        <div class="a-stat-lbl">Avg. Attendance Rate</div>
      </div>
    </div>
    <div class="a-stat">
      <div class="a-stat-icon red"><i class="bi bi-person-dash-fill"></i></div>
      <div>
        <div class="a-stat-val"><?= $overall_drop_rate ?>%</div>
        <div class="a-stat-lbl">Avg. Drop-off Rate</div>
      </div>
    </div>
    <div class="a-stat">
      <div class="a-stat-icon purple"><i class="bi bi-calendar-check-fill"></i></div>
      <div>
        <div class="a-stat-val"><?= $completed_events ?></div>
        <div class="a-stat-lbl">Completed Events</div>
      </div>
    </div>
  </div>

  <!-- ── Toolbar ───────────────────────────────────────── -->
  <div class="analytics-toolbar">
    <input type="text" id="searchInput" placeholder="🔍  Search event name…" oninput="filterTable()">
    <select id="statusFilter" onchange="filterTable()">
      <option value="">All Statuses</option>
      <option value="completed">Completed</option>
      <option value="ongoing">Ongoing</option>
      <option value="approved">Approved</option>
      <option value="pending">Pending</option>
      <option value="draft">Draft</option>
    </select>
    <select id="sortSelect" onchange="sortTable()">
      <option value="">Sort by…</option>
      <option value="att_desc">Attendance Rate ↓</option>
      <option value="att_asc">Attendance Rate ↑</option>
      <option value="drop_desc">Drop-off Rate ↓</option>
      <option value="drop_asc">Drop-off Rate ↑</option>
      <option value="participants_desc">Participants ↓</option>
      <option value="date_desc">Date (Newest)</option>
      <option value="date_asc">Date (Oldest)</option>
    </select>
  </div>

  <!-- ── Table ─────────────────────────────────────────── -->
  <div class="card" style="padding:0;overflow:hidden;">
    <?php if (empty($analytics)): ?>
    <div class="empty-analytics">
      <i class="bi bi-bar-chart-line"></i>
      <p>No events yet. Create your first event to see analytics here.</p>
    </div>
    <?php else: ?>
    <table class="analytics-table" id="analyticsTable">
      <thead>
        <tr>
          <th>Event</th>
          <th>Date</th>
          <th>Status</th>
          <th>Participants</th>
          <th>Attendance Rate</th>
          <th>Drop-off Rate</th>
          <th>Details</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($analytics as $a):
          $attClass  = $a['attendance_rate'] >= 70 ? 'green' : ($a['attendance_rate'] >= 40 ? 'yellow' : 'red');
          $dropClass = $a['dropoff_rate']    <= 20 ? 'green' : ($a['dropoff_rate']    <= 50 ? 'yellow' : 'red');
          $statusMap = [
            'completed' => 'badge-completed',
            'approved'  => 'badge-approved',
            'ongoing'   => 'badge-ongoing',
            'pending'   => 'badge-pending',
            'draft'     => 'badge-draft',
            'rejected'  => 'badge-rejected',
          ];
          $badgeCls = $statusMap[$a['status']] ?? 'badge-draft';
        ?>
        <tr
          data-title="<?= strtolower(htmlspecialchars($a['title'])) ?>"
          data-status="<?= $a['status'] ?>"
          data-att="<?= $a['attendance_rate'] ?>"
          data-drop="<?= $a['dropoff_rate'] ?>"
          data-participants="<?= $a['participants'] ?>"
          data-date="<?= $a['event_date'] ?>"
          data-id="<?= $a['id'] ?>"
        >
          <td>
            <strong style="font-size:13px;"><?= htmlspecialchars($a['title']) ?></strong>
          </td>
          <td style="font-size:12px;color:var(--text-muted);white-space:nowrap;">
            <?= $a['event_date'] ? date('M j, Y', strtotime($a['event_date'])) : '—' ?>
          </td>
          <td><span class="badge <?= $badgeCls ?>"><?= ucfirst($a['status']) ?></span></td>
          <td>
            <span style="font-weight:600;font-size:14px;"><?= $a['participants'] ?></span>
            <span style="font-size:11px;color:var(--text-muted);"> / <?= $a['capacity'] ?> cap</span>
          </td>
          <td>
            <div class="mini-bar-wrap">
              <div class="mini-bar-track">
                <div class="mini-bar-fill <?= $attClass ?>" style="width:<?= $a['attendance_rate'] ?>%"></div>
              </div>
              <span class="mini-bar-pct" style="color:var(--text-primary);"><?= $a['attendance_rate'] ?>%</span>
            </div>
          </td>
          <td>
            <div class="mini-bar-wrap">
              <div class="mini-bar-track">
                <div class="mini-bar-fill <?= $dropClass ?>" style="width:<?= $a['dropoff_rate'] ?>%"></div>
              </div>
              <span class="mini-bar-pct" style="color:var(--text-primary);"><?= $a['dropoff_rate'] ?>%</span>
            </div>
          </td>
          <td>
            <button
              class="action-btn"
              style="background:#6366f1;color:#fff;"
              title="View Details"
              onclick='openDetail(<?= json_encode($a) ?>)'
            >
              <i class="bi bi-bar-chart-line"></i>
            </button>
          </td>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
    <?php endif; ?>
  </div>

</main>
</div>

<!-- ── Detail Modal ───────────────────────────────────── -->
<div class="modal-overlay" id="detailModal">
  <div class="modal-box">
    <button class="modal-close-btn" onclick="closeDetail()">&times;</button>
    <div class="modal-title" id="dmTitle">—</div>
    <div class="modal-sub"  id="dmSub">—</div>

    <div class="detail-grid">
      <div class="detail-card blue-bg" style="background:#eff6ff;">
        <div class="dc-val" id="dmParticipants">—</div>
        <div class="dc-lbl">Registered Participants</div>
      </div>
      <div class="detail-card green-bg">
        <div class="dc-val" id="dmAttended">—</div>
        <div class="dc-lbl">Attended (Timed In)</div>
      </div>
      <div class="detail-card yellow-bg">
        <div class="dc-val" id="dmNoShow">—</div>
        <div class="dc-lbl">No-shows</div>
      </div>
      <div class="detail-card red-bg">
        <div class="dc-val" id="dmDropped">—</div>
        <div class="dc-lbl">Left Early (Drop-offs)</div>
      </div>
    </div>

    <div class="detail-bar-section">
      <div class="detail-bar-label">
        <span>Attendance Rate</span>
        <span id="dmAttRate">—</span>
      </div>
      <div class="detail-bar-track">
        <div class="detail-bar-fill green" id="dmAttBar" style="width:0%"></div>
      </div>

      <div class="detail-bar-label">
        <span>Drop-off Rate</span>
        <span id="dmDropRate">—</span>
      </div>
      <div class="detail-bar-track">
        <div class="detail-bar-fill red" id="dmDropBar" style="width:0%"></div>
      </div>

      <div class="detail-bar-label">
        <span>Capacity Fill</span>
        <span id="dmCapRate">—</span>
      </div>
      <div class="detail-bar-track">
        <div class="detail-bar-fill" id="dmCapBar" style="width:0%;background:#6366f1;"></div>
      </div>
    </div>

    <p style="font-size:11.5px;color:var(--text-muted);margin-top:18px;line-height:1.6;">
      <strong>How metrics are calculated:</strong><br>
      <strong>Attendance Rate</strong> = (students who timed in) ÷ (approved registrations) × 100<br>
      <strong>Drop-off Rate</strong> = (timed in but not timed out) ÷ (timed in) × 100<br>
      <strong>No-shows</strong> = approved registrations − students who timed in
    </p>
  </div>
</div>

<?php include 'footer.php'; ?>

<script>
/* ── Detail Modal ───────────────────────────────────── */
function openDetail(a) {
  document.getElementById('dmTitle').textContent       = a.title;
  document.getElementById('dmSub').textContent         = a.event_date
    ? new Date(a.event_date).toLocaleDateString('en-US',{month:'long',day:'numeric',year:'numeric'})
    : 'Date not set';
  document.getElementById('dmParticipants').textContent = a.participants;
  document.getElementById('dmAttended').textContent    = a.attended;
  document.getElementById('dmNoShow').textContent      = a.no_show;
  document.getElementById('dmDropped').textContent     = a.dropped_off;
  document.getElementById('dmAttRate').textContent     = a.attendance_rate + '%';
  document.getElementById('dmDropRate').textContent    = a.dropoff_rate    + '%';

  var capPct = a.capacity > 0 ? Math.min(100, Math.round(a.participants / a.capacity * 100)) : 0;
  document.getElementById('dmCapRate').textContent     = capPct + '%  (' + a.participants + ' / ' + a.capacity + ')';

  document.getElementById('dmAttBar').style.width  = a.attendance_rate + '%';
  document.getElementById('dmDropBar').style.width = a.dropoff_rate    + '%';
  document.getElementById('dmCapBar').style.width  = capPct            + '%';

  document.getElementById('detailModal').classList.add('open');
}

function closeDetail() {
  document.getElementById('detailModal').classList.remove('open');
}
document.getElementById('detailModal').addEventListener('click', function(e) {
  if (e.target === this) closeDetail();
});

/* ── Filter ─────────────────────────────────────────── */
function filterTable() {
  var q      = document.getElementById('searchInput').value.toLowerCase();
  var status = document.getElementById('statusFilter').value;
  document.querySelectorAll('#analyticsTable tbody tr').forEach(function(tr) {
    var ok = (!q      || tr.dataset.title.includes(q))
          && (!status || tr.dataset.status === status);
    tr.style.display = ok ? '' : 'none';
  });
}

/* ── Sort ───────────────────────────────────────────── */
function sortTable() {
  var val  = document.getElementById('sortSelect').value;
  var tbody = document.querySelector('#analyticsTable tbody');
  if (!tbody || !val) return;
  var rows = Array.from(tbody.querySelectorAll('tr'));
  rows.sort(function(a, b) {
    switch (val) {
      case 'att_desc': return parseFloat(b.dataset.att)          - parseFloat(a.dataset.att);
      case 'att_asc':  return parseFloat(a.dataset.att)          - parseFloat(b.dataset.att);
      case 'drop_desc':return parseFloat(b.dataset.drop)         - parseFloat(a.dataset.drop);
      case 'drop_asc': return parseFloat(a.dataset.drop)         - parseFloat(b.dataset.drop);
      case 'participants_desc': return parseInt(b.dataset.participants) - parseInt(a.dataset.participants);
      case 'date_desc':return (b.dataset.date||'').localeCompare(a.dataset.date||'');
      case 'date_asc': return (a.dataset.date||'').localeCompare(b.dataset.date||'');
      default: return 0;
    }
  });
  rows.forEach(function(tr){ tbody.appendChild(tr); });
}
</script>

</body>
</html>
