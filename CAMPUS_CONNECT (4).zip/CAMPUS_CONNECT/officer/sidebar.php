<?php
// sidebar.php — Shared sidebar for all officer pages
// Set $active_page = 'dashboard' | 'events' | 'registrations' | 'org_profile' | 'settings'
if (!isset($active_page)) $active_page = 'dashboard';
?>
<aside class="sidebar">
  <div class="sidebar-section-label">Main</div>

  <a href="dashboard.php" class="nav-link-item <?= $active_page === 'dashboard' ? 'active' : '' ?>">
    <i class="bi bi-grid-1x2"></i> Dashboard
  </a>

  <a href="my_events.php" class="nav-link-item <?= $active_page === 'events' ? 'active' : '' ?>">
    <i class="bi bi-calendar-event"></i> My Events
  </a>

  <a href="registrations.php" class="nav-link-item <?= $active_page === 'registrations' ? 'active' : '' ?>">
    <i class="bi bi-people"></i> Registrations
  </a>

  <a href="manage_staff.php" class="nav-link-item <?= $active_page === 'staff' ? 'active' : '' ?>">
    <i class="bi bi-person-badge"></i> Manage Staff
  </a>

  <a href="event_analytics.php" class="nav-link-item <?= $active_page === 'analytics' ? 'active' : '' ?>">
    <i class="bi bi-bar-chart-line"></i> Analytics
  </a>

  <div class="sidebar-footer">
    <button class="logout-btn" onclick="window.location.href='../logout.php'">
      <i class="bi bi-box-arrow-right" style="font-size:15px"></i> Sign Out
    </button>
  </div>
</aside>

