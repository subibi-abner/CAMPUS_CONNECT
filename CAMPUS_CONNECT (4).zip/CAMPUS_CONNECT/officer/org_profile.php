<?php
session_start();
require_once '../config.php';
require_once '../db_functions.php';
require_login('organizer');

$user_id     = $_SESSION['user_id'];
$active_page = 'org_profile';

$stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
$stmt->execute([$user_id]);
$officer = $stmt->fetch(PDO::FETCH_ASSOC);

$flash = $_SESSION['flash'] ?? null;
unset($_SESSION['flash']);

// Count events
$stmt2 = $pdo->prepare("SELECT COUNT(*) FROM events WHERE organizer_id = ?");
$stmt2->execute([$user_id]);
$eventCount = (int)$stmt2->fetchColumn();

$stmt3 = $pdo->prepare("SELECT COUNT(*) FROM registrations r JOIN events e ON r.event_id = e.id WHERE e.organizer_id = ?");
$stmt3->execute([$user_id]);
$regCount = (int)$stmt3->fetchColumn();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Org Profile – CampusConnect</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="css/officer.css">
</head>
<body>

<?php include 'header.php'; ?>

<div class="layout">
<?php include 'sidebar.php'; ?>

<main class="main">
  <?php if ($flash): ?>
  <div class="alert alert-<?= $flash['type'] === 'success' ? 'success' : ($flash['type'] === 'error' ? 'error' : 'info') ?>">
    <i class="bi bi-<?= $flash['type'] === 'success' ? 'check-circle' : 'exclamation-circle' ?>"></i>
    <?= htmlspecialchars($flash['msg']) ?>
  </div>
  <?php endif; ?>

  <div class="page-header">
    <div>
      <div class="page-title">Org Profile</div>
      <div class="page-sub">Manage your organization information</div>
    </div>
  </div>

  <div style="display:grid;grid-template-columns:1fr 280px;gap:20px;align-items:start;">

    <!-- Profile Form -->
    <div class="profile-card">
      <div class="profile-avatar-big">
        <?= strtoupper(substr($officer['full_name'] ?? 'O', 0, 1)) ?>
      </div>
      <h3><?= htmlspecialchars($officer['full_name'] ?? 'Organization Name') ?></h3>
      <div class="sub"><?= htmlspecialchars($officer['email'] ?? '') ?> &bull; Organizer</div>

      <form method="POST" action="actions/update_profile.php">
        <div class="form-group">
          <label>Organization / Officer Name *</label>
          <input type="text" name="org_name"
                 value="<?= htmlspecialchars($officer['full_name'] ?? '') ?>" required>
        </div>
        <div class="form-group">
          <label>Email Address</label>
          <input type="email" value="<?= htmlspecialchars($officer['email'] ?? '') ?>" disabled
                 style="background:#fafafa;cursor:not-allowed;">
          <small style="font-size:11px;color:var(--text-muted);">Email cannot be changed here.</small>
        </div>
        <div class="form-group">
          <label>Description / Bio</label>
          <textarea name="description" rows="4"
                    placeholder="Tell students about your organization..."><?= htmlspecialchars($officer['bio'] ?? '') ?></textarea>
        </div>
        <div class="form-group">
          <label>Contact / Facebook / Website</label>
          <input type="text" name="contact"
                 value="<?= htmlspecialchars($officer['contact'] ?? '') ?>"
                 placeholder="e.g. fb.com/csssociety or email@school.edu">
        </div>
        <button type="submit" class="btn-primary">
          <i class="bi bi-check-lg"></i> Save Changes
        </button>
      </form>
    </div>

    <!-- Right: Stats -->
    <div style="display:flex;flex-direction:column;gap:16px;">
      <div class="card card-body" style="padding:20px;">
        <div style="font-size:12px;font-weight:600;text-transform:uppercase;letter-spacing:.07em;color:var(--text-muted);margin-bottom:16px;">Organization Stats</div>
        <div style="display:flex;flex-direction:column;gap:14px;">
          <div style="display:flex;justify-content:space-between;align-items:center;">
            <div style="display:flex;align-items:center;gap:8px;font-size:13px;color:var(--text-secondary);">
              <i class="bi bi-calendar3" style="color:var(--red);"></i> Total Events
            </div>
            <strong style="font-size:16px;color:var(--text-primary);"><?= $eventCount ?></strong>
          </div>
          <div style="display:flex;justify-content:space-between;align-items:center;">
            <div style="display:flex;align-items:center;gap:8px;font-size:13px;color:var(--text-secondary);">
              <i class="bi bi-people" style="color:#3b82f6;"></i> Total Registrations
            </div>
            <strong style="font-size:16px;color:var(--text-primary);"><?= $regCount ?></strong>
          </div>
          <div style="display:flex;justify-content:space-between;align-items:center;">
            <div style="display:flex;align-items:center;gap:8px;font-size:13px;color:var(--text-secondary);">
              <i class="bi bi-shield-check" style="color:#059669;"></i> Account Role
            </div>
            <span class="badge badge-blue">Organizer</span>
          </div>
        </div>
      </div>

      <div class="card card-body" style="padding:20px;">
        <div style="font-size:12px;font-weight:600;text-transform:uppercase;letter-spacing:.07em;color:var(--text-muted);margin-bottom:14px;">Quick Links</div>
        <div style="display:flex;flex-direction:column;gap:8px;">
          <a href="my_events.php" style="font-size:13px;color:var(--red);text-decoration:none;display:flex;align-items:center;gap:8px;">
            <i class="bi bi-arrow-right-circle"></i> Manage Events
          </a>
          <a href="registrations.php" style="font-size:13px;color:var(--red);text-decoration:none;display:flex;align-items:center;gap:8px;">
            <i class="bi bi-arrow-right-circle"></i> View Registrations
          </a>
          <a href="settings.php" style="font-size:13px;color:var(--red);text-decoration:none;display:flex;align-items:center;gap:8px;">
            <i class="bi bi-arrow-right-circle"></i> Account Settings
          </a>
        </div>
      </div>
    </div>

  </div>
</main>
</div>

<?php include 'footer.php'; ?>
</body>
</html>
