<!-- DELETE EVENT MODAL -->
<div id="deleteModal" class="modal-overlay">
  <div class="modal-box">
    <div class="modal-header">
      <h4><i class="bi bi-exclamation-triangle" style="color:#f59e0b;margin-right:8px;"></i>Request Event Deletion</h4>

      <button class="modal-close" onclick="closeModal('deleteModal')">&times;</button>
    </div>
    <div id="deleteEventInfo">
      <div style="font-size:14px;font-weight:600;color:var(--text-primary);margin-bottom:8px;" id="deleteEventTitle"></div>
      <div id="deleteRegCount" style="font-size:12px;color:var(--text-secondary);"></div>
    </div>
    <div class="form-group" id="reasonGroup" style="display:none;">
      <label>Reason for deletion <span style="color:#ef4444;">*</span></label>
      <textarea id="deleteReason" name="reason" rows="3" placeholder="Explain why this event is being deleted (required if students registered)..." style="width:100%;padding:10px;border:1px solid var(--border);border-radius:8px;font-family:Poppins,sans-serif;" oninput="toggleDeleteBtn()"></textarea>

      <small style="font-size:11px;color:var(--text-muted);">This reason will be emailed to registered students</small>
    </div>
    <div class="modal-actions">
      <button type="button" class="btn-warning" onclick="submitDeletionRequest()" id="deleteConfirmBtn" disabled>Request Deletion</button>

      <button type="button" class="btn-cancel" onclick="closeModal('deleteModal')">Cancel</button>
    </div>
  </div>
</div>

