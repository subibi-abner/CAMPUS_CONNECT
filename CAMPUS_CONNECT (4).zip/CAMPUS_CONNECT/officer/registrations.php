<?php
session_start();
require_once '../config.php';
require_once '../db_functions.php';
require_login('organizer');

$user_id     = $_SESSION['user_id'];
$active_page = 'registrations';

// Fetch events for tabs/filter
$stmt = $pdo->prepare("SELECT id, title, status, event_date FROM events WHERE organizer_id = ? ORDER BY event_date ASC");
$stmt->execute([$user_id]);
$eventsArr = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Fetch all registrations with full student details
$stmt = $pdo->prepare("
  SELECT r.*,
         u.full_name  AS user_name,
         u.email      AS user_email,
         u.year_level AS user_year,
         u.username   AS user_username,
         d.name       AS user_dept,
         d.code       AS user_dept_code,
         e.title      AS event_title,
         e.id         AS event_id,
         r.registered_at AS reg_date,
         COALESCE(r.approval_status, 'approved') AS approval_status
  FROM registrations r
  JOIN users  u ON r.user_id  = u.id
  JOIN events e ON r.event_id = e.id
  LEFT JOIN departments d ON u.department_id = d.id
  WHERE e.organizer_id = ?
  ORDER BY r.registered_at DESC
");
$stmt->execute([$user_id]);
$regArr = $stmt->fetchAll(PDO::FETCH_ASSOC);

$flash = $_SESSION['flash'] ?? null;
unset($_SESSION['flash']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Registrations - CampusConnect</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="css/officer.css">
  <style>
    .toolbar-row { display:flex;gap:12px;align-items:flex-end;flex-wrap:wrap;margin-bottom:14px; }
    .toolbar-label { font-size:12px;font-weight:500;color:var(--text-muted);display:block;margin-bottom:3px; }
    .btn-export  { display:inline-flex;align-items:center;gap:6px;padding:8px 14px;background:#16a34a;color:#fff;border:none;border-radius:8px;font-size:13px;font-weight:500;cursor:pointer;text-decoration:none; }
    .btn-export:hover { background:#15803d; }
    .btn-announce { display:inline-flex;align-items:center;gap:6px;padding:8px 14px;background:#6366f1;color:#fff;border:none;border-radius:8px;font-size:13px;font-weight:500;cursor:pointer; }
    .btn-announce:hover { background:#4f46e5; }
    .btn-approve-sm { background:#dcfce7;color:#16a34a;border:none;border-radius:4px;padding:3px 8px;font-size:11px;font-weight:600;cursor:pointer; }
    .btn-approve-sm:hover { background:#16a34a;color:#fff; }
    .btn-reject-sm  { background:#fee2e2;color:#b91c1c;border:none;border-radius:4px;padding:3px 8px;font-size:11px;font-weight:600;cursor:pointer; }
    .btn-reject-sm:hover  { background:#b91c1c;color:#fff; }
    .btn-remove-reg { background:#ef4444;color:white;border:none;border-radius:4px;padding:3px 8px;font-size:11px;cursor:pointer;margin-left:4px; }
    .btn-remove-reg:hover { background:#dc2626; }
    .badge-approval-approved { background:#dcfce7;color:#16a34a;padding:2px 8px;border-radius:12px;font-size:10px;font-weight:600; }
    .badge-approval-pending  { background:#fef9c3;color:#b45309;padding:2px 8px;border-radius:12px;font-size:10px;font-weight:600; }
    .badge-approval-rejected { background:#fee2e2;color:#b91c1c;padding:2px 8px;border-radius:12px;font-size:10px;font-weight:600; }
    .modal-overlay { display:none;position:fixed;inset:0;background:rgba(0,0,0,.45);z-index:1000;align-items:center;justify-content:center; }
    .modal-overlay.open { display:flex; }
    .modal-box { background:#fff;border-radius:12px;padding:28px;width:100%;max-width:520px;box-shadow:0 20px 60px rgba(0,0,0,.2); }
    .modal-box h3 { margin:0 0 16px;font-size:16px;font-weight:600; }
    .modal-box label { font-size:13px;font-weight:500;display:block;margin-bottom:4px;color:#374151; }
    .modal-box input,.modal-box textarea,.modal-box select { width:100%;padding:8px 12px;border:1px solid #d1d5db;border-radius:8px;font-size:13px;font-family:inherit;box-sizing:border-box;margin-bottom:12px; }
    .modal-box textarea { min-height:100px;resize:vertical; }
    .modal-footer { display:flex;gap:8px;justify-content:flex-end;margin-top:4px; }
    .btn-cancel { padding:8px 16px;background:#f1f5f9;border:none;border-radius:8px;font-size:13px;cursor:pointer; }
    .btn-send   { padding:8px 16px;background:#6366f1;color:#fff;border:none;border-radius:8px;font-size:13px;font-weight:500;cursor:pointer; }
  </style>
</head>
<body>

<?php include 'header.php'; ?>

<div class="layout">
<?php include 'sidebar.php'; ?>

<main class="main">
  <?php if ($flash): ?>
  <div class="alert alert-<?= $flash['type'] === 'success' ? 'success' : 'error' ?>" style="margin-bottom:20px;">
    <i class="bi bi-<?= $flash['type'] === 'success' ? 'check-circle' : 'exclamation-circle' ?>"></i>
    <?= htmlspecialchars($flash['msg']) ?>
  </div>
  <?php endif; ?>

  <div class="page-header">
    <div>
      <div class="page-title">Registrations</div>
      <div class="page-sub"><?= count($regArr) ?> total registrations across all events</div>
    </div>
    <button class="btn-primary" onclick="openModal('createModal')">
      <i class="bi bi-plus-lg"></i> New Event
    </button>
  </div>

  <!-- Filter Row -->
  <div class="toolbar-row">
    <div>
      <span class="toolbar-label">Filter by Event</span>
      <select id="eventFilter" onchange="updateTable()" style="padding:8px 12px;border:1px solid var(--border);border-radius:8px;font-size:13px;min-width:240px;">
        <option value="">All Events (<?= count($regArr) ?>)</option>
        <?php foreach ($eventsArr as $e):
          $cnt = array_reduce($regArr, function($c,$r) use($e){ return $c + ($r['event_id']==$e['id']?1:0); }, 0);
        ?>
        <option value="<?= $e['id'] ?>"><?= htmlspecialchars(substr($e['title'],0,38)) ?> (<?= $cnt ?>)</option>
        <?php endforeach; ?>
      </select>
    </div>
    <div>
      <span class="toolbar-label">Approval Status</span>
      <select id="approvalFilter" onchange="updateTable()" style="padding:8px 12px;border:1px solid var(--border);border-radius:8px;font-size:13px;min-width:160px;">
        <option value="">All</option>
        <option value="approved">Approved</option>
        <option value="pending">Pending</option>
        <option value="rejected">Rejected</option>
      </select>
    </div>
  </div>

  <!-- Search + Action Row -->
  <div class="page-toolbar" style="margin-bottom:14px;justify-content:space-between;flex-wrap:wrap;gap:10px;">
    <div style="display:flex;gap:10px;align-items:center;">
      <div class="search-box">
        <i class="bi bi-search"></i>
        <input type="text" id="regSearch" placeholder="Search by name or email..." oninput="updateTable()">
      </div>
      <div style="font-size:13px;color:var(--text-muted);">
        Showing <span id="visibleCount"><?= count($regArr) ?></span> of <?= count($regArr) ?>
      </div>
    </div>
    <div style="display:flex;gap:8px;">
      <a id="exportBtn" href="actions/export_participants_csv.php" target="_blank" class="btn-export">
        <i class="bi bi-download"></i> Export CSV
      </a>
      <button class="btn-announce" onclick="openAnnounceModal()">
        <i class="bi bi-megaphone"></i> Announce
      </button>
    </div>
  </div>

  <div class="card">
    <?php if (empty($regArr)): ?>
    <div class="empty-state">
      <i class="bi bi-people"></i>
      <p>No registrations yet for your events.</p>
    </div>
    <?php else: ?>
    <table class="data-table" id="regTable">
      <thead>
        <tr>
          <th>#</th>
          <th>Student</th>
          <th>Department / Year</th>
          <th>Event</th>
          <th>Registered</th>
          <th>Status</th>
          <th>Actions</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($regArr as $i => $r):
          $apst = $r['approval_status'] ?? 'approved';
        ?>
        <tr data-event-id="<?= $r['event_id'] ?>"
            data-name="<?= strtolower(htmlspecialchars($r['user_name'])) ?>"
            data-email="<?= strtolower(htmlspecialchars($r['user_email'])) ?>"
            data-approval="<?= $apst ?>">
          <td style="color:var(--text-muted);width:40px;"><?= $i + 1 ?></td>
          <td>
            <div class="user-cell">
              <div class="user-avatar"><?= strtoupper(substr($r['user_name'], 0, 1)) ?></div>
              <div>
                <div class="user-name"><?= htmlspecialchars($r['user_name']) ?></div>
                <div class="user-email" style="font-size:11px;color:var(--text-muted);"><?= htmlspecialchars($r['user_email']) ?></div>
                <div style="font-size:10px;color:#aaa;">@<?= htmlspecialchars($r['user_username'] ?? '') ?></div>
              </div>
            </div>
          </td>
          <td>
            <?php if (!empty($r['user_dept_code'])): ?>
              <span style="background:#1a3a6b;color:#fff;font-size:10px;font-weight:700;padding:2px 6px;border-radius:4px;"><?= htmlspecialchars($r['user_dept_code']) ?></span>
            <?php endif; ?>
            <div style="font-size:11px;color:var(--text-secondary);margin-top:3px;"><?= htmlspecialchars($r['user_dept'] ?? 'N/A') ?></div>
            <?php if (!empty($r['user_year'])): ?>
              <div style="font-size:11px;color:var(--text-muted);"><?= htmlspecialchars($r['user_year']) ?></div>
            <?php endif; ?>
          </td>
          <td style="font-size:12px;"><?= htmlspecialchars($r['event_title']) ?></td>
          <td style="font-size:12px;"><?= $r['reg_date'] ? date('M j, Y', strtotime($r['reg_date'])) : '—' ?></td>
          <td>
            <span class="badge-approval-<?= $apst ?>">
              <?= $apst === 'approved' ? 'Approved' : ($apst === 'rejected' ? 'Rejected' : 'Pending') ?>
            </span>
          </td>
          <td>
            <div style="display:flex;gap:4px;align-items:center;flex-wrap:wrap;">
              <?php if ($apst === 'pending'): ?>
                <button class="btn-approve-sm" onclick="doApprove(<?= $r['id'] ?>, 'approve', '<?= addslashes(htmlspecialchars($r['user_name'])) ?>')">Approve</button>
                <button class="btn-reject-sm"  onclick="doApprove(<?= $r['id'] ?>, 'reject',  '<?= addslashes(htmlspecialchars($r['user_name'])) ?>')">Reject</button>
              <?php elseif ($apst === 'approved'): ?>
                <button class="btn-reject-sm"  onclick="doApprove(<?= $r['id'] ?>, 'reject',  '<?= addslashes(htmlspecialchars($r['user_name'])) ?>')">Revoke</button>
              <?php elseif ($apst === 'rejected'): ?>
                <button class="btn-approve-sm" onclick="doApprove(<?= $r['id'] ?>, 'approve', '<?= addslashes(htmlspecialchars($r['user_name'])) ?>')">Approve</button>
              <?php endif; ?>
              <button class="btn-remove-reg" onclick="confirmRemove(<?= $r['id'] ?>, '<?= addslashes(htmlspecialchars($r['user_name'])) ?>', '<?= addslashes(htmlspecialchars($r['event_title'])) ?>')" title="Remove registration">
                <i class="bi bi-trash"></i>
              </button>
            </div>
          </td>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
    <?php endif; ?>
  </div>
</main>
</div>

<!-- Announcement Modal -->
<div class="modal-overlay" id="announceModal">
  <div class="modal-box">
    <h3><i class="bi bi-megaphone" style="color:#6366f1;margin-right:8px;"></i>Send Announcement to Participants</h3>
    <form method="POST" action="actions/send_participant_announcement.php">
      <label>Event</label>
      <select name="event_id" id="announceEventId" required>
        <option value="">— Select Event —</option>
        <?php foreach ($eventsArr as $e): ?>
        <option value="<?= $e['id'] ?>"><?= htmlspecialchars($e['title']) ?></option>
        <?php endforeach; ?>
      </select>

      <label>Send To</label>
      <select name="target">
        <option value="all">All registered participants</option>
        <option value="approved">Approved participants only</option>
        <option value="pending">Pending (awaiting approval)</option>
      </select>

      <label>Subject</label>
      <input type="text" name="subject" placeholder="e.g. Venue change for tomorrow" required maxlength="200">

      <label>Message</label>
      <textarea name="message" placeholder="Type your announcement here..." required></textarea>

      <div class="modal-footer">
        <button type="button" class="btn-cancel" onclick="closeAnnounceModal()">Cancel</button>
        <button type="submit" class="btn-send"><i class="bi bi-send"></i> Send</button>
      </div>
    </form>
  </div>
</div>

<?php include 'create_event_modal.php'; ?>
<?php include 'footer.php'; ?>

<script>
function updateTable() {
  var q        = (document.getElementById('regSearch').value || '').toLowerCase();
  var eventId  = document.getElementById('eventFilter').value;
  var approval = document.getElementById('approvalFilter').value;
  var rows     = document.querySelectorAll('#regTable tbody tr');
  var visible  = 0;
  rows.forEach(function(tr) {
    var ok = (!eventId  || tr.dataset.eventId  === eventId)
          && (!approval || tr.dataset.approval === approval)
          && (!q || tr.dataset.name.includes(q) || tr.dataset.email.includes(q) || tr.textContent.toLowerCase().includes(q));
    tr.style.display = ok ? '' : 'none';
    if (ok) visible++;
  });
  var vc = document.getElementById('visibleCount');
  if (vc) vc.textContent = visible;

  // Keep export link in sync
  var exportBtn = document.getElementById('exportBtn');
  if (exportBtn) {
    var p = [];
    if (eventId)  p.push('event_id=' + encodeURIComponent(eventId));
    if (approval) p.push('filter='   + encodeURIComponent(approval));
    exportBtn.href = 'actions/export_participants_csv.php' + (p.length ? '?' + p.join('&') : '');
  }
}

function doApprove(regId, action, name) {
  var note = '';
  if (action === 'reject') {
    note = prompt('Optional note for ' + name + ':') || '';
    if (note === null) return;
  }
  var fd = new FormData();
  fd.append('registration_id', regId);
  fd.append('action', action);
  fd.append('note', note);
  fetch('actions/approve_registration.php', { method:'POST', body:fd })
    .then(function(){ location.reload(); })
    .catch(function(e){ alert('Error: ' + e); });
}

function confirmRemove(regId, name, title) {
  if (!confirm('Remove ' + name + ' from "' + title + '"?')) return;
  var fd = new FormData();
  fd.append('registration_id', regId);
  fd.append('message', '');
  fetch('actions/remove_registration.php', { method:'POST', body:fd })
    .then(function(){ location.reload(); })
    .catch(function(e){ alert('Error: ' + e); });
}

function openAnnounceModal() {
  var eventId = document.getElementById('eventFilter').value;
  if (eventId) document.getElementById('announceEventId').value = eventId;
  document.getElementById('announceModal').classList.add('open');
}
function closeAnnounceModal() {
  document.getElementById('announceModal').classList.remove('open');
}
document.getElementById('announceModal').addEventListener('click', function(e) {
  if (e.target === this) closeAnnounceModal();
});
</script>
</body>
</html>
