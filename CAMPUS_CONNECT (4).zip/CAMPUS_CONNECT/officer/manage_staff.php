<?php
session_start();
require_once '../config.php';
require_once '../db_functions.php';
require_login('organizer');

$user_id     = $_SESSION['user_id'];
$active_page = 'staff';

// Flash message
$flash = $_SESSION['flash'] ?? null;
unset($_SESSION['flash']);

// Organizer's events
$stmt = $pdo->prepare("SELECT id, title, event_date, status FROM events WHERE organizer_id = ? ORDER BY event_date DESC");
$stmt->execute([$user_id]);
$events = $stmt->fetchAll(PDO::FETCH_ASSOC);

// All staff accounts
$stmt = $pdo->query("SELECT id, full_name, email, department_id FROM users WHERE role = 'staff' ORDER BY full_name ASC");
$staffUsers = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Current assignments for this organizer's events
$stmt = $pdo->prepare("
  SELECT es.event_id, es.staff_id, es.assigned_at,
         u.full_name AS staff_name, u.email AS staff_email,
         e.title     AS event_title
  FROM event_staff es
  JOIN users  u ON es.staff_id  = u.id
  JOIN events e ON es.event_id  = e.id
  WHERE es.assigned_by = ?
  ORDER BY es.assigned_at DESC
");
$stmt->execute([$user_id]);
$assignments = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Manage Staff – CampusConnect</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="css/officer.css">
</head>
<body>

<?php include 'header.php'; ?>

<div class="layout">
<?php include 'sidebar.php'; ?>

<main class="main">

  <?php if ($flash): ?>
  <div class="alert alert-<?= $flash['type'] === 'success' ? 'success' : 'error' ?>" style="margin-bottom:20px;">
    <i class="bi bi-<?= $flash['type'] === 'success' ? 'check-circle' : 'exclamation-circle' ?>"></i>
    <?= htmlspecialchars($flash['msg']) ?>
  </div>
  <?php endif; ?>

  <div class="page-header">
    <div>
      <div class="page-title">Manage Staff</div>
      <div class="page-sub">Assign staff members to your events to handle attendance</div>
    </div>
    <button class="btn-primary" onclick="document.getElementById('createStaffModal').classList.add('active')">
      <i class="bi bi-person-plus"></i> Create Staff Account
    </button>
  </div>

  <!-- CURRENT ASSIGNMENTS -->
  <div class="card" style="margin-bottom:24px;">
    <div class="card-header"><h4><i class="bi bi-person-check" style="color:var(--red)"></i>&nbsp; Current Assignments</h4></div>
    <?php if (empty($assignments)): ?>
    <div style="padding:40px;text-align:center;color:var(--text-muted);">
      <i class="bi bi-person-badge" style="font-size:32px;display:block;margin-bottom:8px;opacity:.3;"></i>
      <p style="font-size:13px;">No staff assigned yet. Use the form below to assign someone.</p>
    </div>
    <?php else: ?>
    <table class="data-table">
      <thead>
        <tr>
          <th>Staff Member</th>
          <th>Assigned Event</th>
          <th>Assigned At</th>
          <th>Action</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($assignments as $a): ?>
        <tr>
          <td>
            <div style="font-weight:500;"><?= htmlspecialchars($a['staff_name']) ?></div>
            <div style="font-size:11px;color:var(--text-muted);"><?= htmlspecialchars($a['staff_email']) ?></div>
          </td>
          <td><?= htmlspecialchars($a['event_title']) ?></td>
          <td style="font-size:12px;color:var(--text-muted);"><?= (new DateTime($a['assigned_at']))->format('M d, Y g:i A') ?></td>
          <td>
            <form method="POST" action="actions/assign_staff.php" onsubmit="return confirm('Remove this staff assignment?')">
              <input type="hidden" name="action"   value="remove">
              <input type="hidden" name="event_id" value="<?= $a['event_id'] ?>">
              <input type="hidden" name="staff_id" value="<?= $a['staff_id'] ?>">
              <button type="submit" class="btn-outline btn-sm" style="color:#dc2626;border-color:#dc2626;">
                <i class="bi bi-x-lg"></i> Remove
              </button>
            </form>
          </td>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
    <?php endif; ?>
  </div>

  <!-- ASSIGN STAFF FORM -->
  <div class="card">
    <div class="card-header"><h4><i class="bi bi-person-plus" style="color:var(--red)"></i>&nbsp; Assign Staff to Event</h4></div>
    <div class="card-body">
      <?php if (empty($events)): ?>
      <p style="font-size:13px;color:var(--text-muted);">You have no events yet. <a href="my_events.php">Create an event first.</a></p>
      <?php elseif (empty($staffUsers)): ?>
      <p style="font-size:13px;color:var(--text-muted);">No staff accounts exist yet. Use the <strong>Create Staff Account</strong> button above to create one.</p>
      <?php else: ?>
      <form method="POST" action="actions/assign_staff.php" style="display:flex;gap:14px;flex-wrap:wrap;align-items:flex-end;">
        <input type="hidden" name="action" value="assign">
        <div style="flex:1;min-width:200px;">
          <label style="font-size:12px;font-weight:600;color:var(--text-muted);display:block;margin-bottom:6px;">Select Event</label>
          <select name="event_id" required style="width:100%;border:1px solid var(--border);border-radius:8px;padding:9px 12px;font-size:13px;">
            <option value="">— Choose an event —</option>
            <?php foreach ($events as $e): ?>
            <option value="<?= $e['id'] ?>">
              <?= htmlspecialchars($e['title']) ?> (<?= (new DateTime($e['event_date']))->format('M d') ?>)
            </option>
            <?php endforeach; ?>
          </select>
        </div>
        <div style="flex:1;min-width:200px;">
          <label style="font-size:12px;font-weight:600;color:var(--text-muted);display:block;margin-bottom:6px;">Select Staff Member</label>
          <select name="staff_id" required style="width:100%;border:1px solid var(--border);border-radius:8px;padding:9px 12px;font-size:13px;">
            <option value="">— Choose staff —</option>
            <?php foreach ($staffUsers as $s): ?>
            <option value="<?= $s['id'] ?>"><?= htmlspecialchars($s['full_name']) ?> — <?= htmlspecialchars($s['email']) ?></option>
            <?php endforeach; ?>
          </select>
        </div>
        <button type="submit" class="btn-primary">
          <i class="bi bi-person-check"></i> Assign
        </button>
      </form>
      <?php endif; ?>
    </div>
  </div>

</main>
</div>

<!-- CREATE STAFF MODAL -->
<div class="modal-overlay" id="createStaffModal">
  <div style="background:#fff;border-radius:16px;padding:32px;max-width:460px;width:92%;position:relative;">
    <button onclick="document.getElementById('createStaffModal').classList.remove('active')"
      style="position:absolute;top:14px;right:14px;background:none;border:none;font-size:20px;cursor:pointer;color:var(--text-muted);">&times;</button>
    <h3 style="font-size:17px;font-weight:700;margin-bottom:4px;">Create Staff Account</h3>
    <p style="font-size:13px;color:var(--text-muted);margin-bottom:20px;">The new staff member will receive login credentials via email.</p>
    <form method="POST" action="actions/create_staff_account.php">
      <div style="margin-bottom:14px;">
        <label style="font-size:12px;font-weight:600;color:var(--text-muted);display:block;margin-bottom:5px;">Full Name</label>
        <input type="text" name="full_name" required placeholder="e.g. Mark A. Villanueva"
          style="width:100%;border:1px solid var(--border);border-radius:8px;padding:9px 12px;font-size:13px;">
      </div>
      <div style="margin-bottom:14px;">
        <label style="font-size:12px;font-weight:600;color:var(--text-muted);display:block;margin-bottom:5px;">Email Address</label>
        <input type="email" name="email" required placeholder="staff@wmsu.edu.ph"
          style="width:100%;border:1px solid var(--border);border-radius:8px;padding:9px 12px;font-size:13px;">
      </div>
      <div style="margin-bottom:20px;">
        <label style="font-size:12px;font-weight:600;color:var(--text-muted);display:block;margin-bottom:5px;">Username</label>
        <input type="text" name="username" required placeholder="e.g. m.villanueva"
          style="width:100%;border:1px solid var(--border);border-radius:8px;padding:9px 12px;font-size:13px;">
      </div>
      <button type="submit" class="btn-primary" style="width:100%;justify-content:center;">
        <i class="bi bi-person-plus"></i> Create Account &amp; Send Credentials
      </button>
    </form>
  </div>
</div>

<style>
.modal-overlay { position:fixed;inset:0;background:rgba(0,0,0,.55);z-index:500;display:none;align-items:center;justify-content:center; }
.modal-overlay.active { display:flex; }
.alert { padding:12px 16px;border-radius:8px;font-size:13px;display:flex;align-items:center;gap:8px; }
.alert-success { background:#ecfdf5;border:1px solid #6ee7b7;color:#065f46; }
.alert-error   { background:#fef2f2;border:1px solid #fca5a5;color:#991b1b; }
.btn-sm { padding:5px 12px;font-size:12px;border-radius:6px; }
</style>
</body>
</html>
