<?php
session_start();
require_once '../config.php';
require_once '../db_functions.php';
require_login('organizer');

$user_id     = $_SESSION['user_id'];
$active_page = 'settings';

$stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
$stmt->execute([$user_id]);
$officer = $stmt->fetch(PDO::FETCH_ASSOC);

$flash = $_SESSION['flash'] ?? null;
unset($_SESSION['flash']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Settings – CampusConnect</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="css/officer.css">
  <style>
    .settings-section {
      background: var(--bg-card);
      border: 1px solid var(--border);
      border-radius: 12px;
      padding: 28px;
      max-width: 600px;
      margin-bottom: 20px;
    }
    .settings-section h4 {
      font-size: 15px;
      font-weight: 600;
      color: var(--text-primary);
      margin-bottom: 6px;
      display: flex;
      align-items: center;
      gap: 8px;
    }
    .settings-section .section-desc {
      font-size: 12.5px;
      color: var(--text-muted);
      margin-bottom: 22px;
      padding-bottom: 16px;
      border-bottom: 1px solid var(--border);
    }
    .password-toggle {
      position: relative;
    }
    .password-toggle input { padding-right: 40px; }
    .password-toggle .eye-btn {
      position: absolute;
      right: 10px;
      top: 50%;
      transform: translateY(-50%);
      background: none;
      border: none;
      cursor: pointer;
      color: var(--text-muted);
      font-size: 16px;
      padding: 0;
    }
    .password-toggle .eye-btn:hover { color: var(--text-primary); }
    .danger-zone {
      border-color: #fecaca;
    }
    .danger-zone h4 { color: #ef4444; }
    .btn-danger {
      background: #ef4444;
      color: #fff;
      border: none;
      padding: 9px 18px;
      border-radius: 8px;
      font-size: 13px;
      font-weight: 500;
      cursor: pointer;
      display: inline-flex;
      align-items: center;
      gap: 6px;
    }
    .btn-danger:hover { background: #dc2626; }
  </style>
</head>
<body>

<?php include 'header.php'; ?>

<div class="layout">
<?php include 'sidebar.php'; ?>

<main class="main">
  <?php if ($flash): ?>
  <div class="alert alert-<?= $flash['type'] === 'success' ? 'success' : ($flash['type'] === 'error' ? 'error' : 'info') ?>">
    <i class="bi bi-<?= $flash['type'] === 'success' ? 'check-circle' : ($flash['type'] === 'error' ? 'exclamation-circle' : 'info-circle') ?>"></i>
    <?= htmlspecialchars($flash['msg']) ?>
  </div>
  <?php endif; ?>

  <div class="page-header">
    <div>
      <div class="page-title">Settings</div>
      <div class="page-sub">Manage your account and preferences</div>
    </div>
  </div>

  <!-- Account Info (read-only) -->
  <div class="settings-section">
    <h4><i class="bi bi-person-circle" style="color:var(--red);"></i> Account Information</h4>
    <div class="section-desc">Your login account details.</div>
    <div class="form-row">
      <div class="form-group">
        <label>Full Name</label>
        <input type="text" value="<?= htmlspecialchars($officer['full_name'] ?? '') ?>" disabled style="background:#fafafa;cursor:not-allowed;">
      </div>
      <div class="form-group">
        <label>Email Address</label>
        <input type="email" value="<?= htmlspecialchars($officer['email'] ?? '') ?>" disabled style="background:#fafafa;cursor:not-allowed;">
      </div>
    </div>
    <div class="form-group">
      <label>Account Role</label>
      <input type="text" value="Organizer" disabled style="background:#fafafa;cursor:not-allowed;">
    </div>
    <small style="font-size:12px;color:var(--text-muted);">
      <i class="bi bi-info-circle"></i> To change your name or email, go to <a href="org_profile.php" style="color:var(--red);">Org Profile</a>.
    </small>
  </div>

  <!-- Change Password -->
  <div class="settings-section">
    <h4><i class="bi bi-lock" style="color:var(--red);"></i> Change Password</h4>
    <div class="section-desc">Update your account password. Choose a strong, unique password.</div>
    <form method="POST" action="actions/update_settings.php" id="pwForm">
      <div class="form-group">
        <label>Current Password *</label>
        <div class="password-toggle">
          <input type="password" name="current_password" id="cur_pw" placeholder="Enter current password" required>
          <button type="button" class="eye-btn" onclick="togglePw('cur_pw', this)">
            <i class="bi bi-eye"></i>
          </button>
        </div>
      </div>
      <div class="form-row">
        <div class="form-group">
          <label>New Password *</label>
          <div class="password-toggle">
            <input type="password" name="new_password" id="new_pw" placeholder="Min 6 characters" required minlength="6">
            <button type="button" class="eye-btn" onclick="togglePw('new_pw', this)">
              <i class="bi bi-eye"></i>
            </button>
          </div>
        </div>
        <div class="form-group">
          <label>Confirm New Password *</label>
          <div class="password-toggle">
            <input type="password" name="confirm_password" id="conf_pw" placeholder="Repeat new password" required>
            <button type="button" class="eye-btn" onclick="togglePw('conf_pw', this)">
              <i class="bi bi-eye"></i>
            </button>
          </div>
        </div>
      </div>
      <div id="pwMismatch" style="display:none;" class="alert alert-error" style="margin-bottom:14px;">
        <i class="bi bi-exclamation-circle"></i> Passwords do not match.
      </div>
      <button type="submit" class="btn-primary">
        <i class="bi bi-check-lg"></i> Update Password
      </button>
    </form>
  </div>

  <!-- Danger Zone -->
  <div class="settings-section danger-zone">
    <h4><i class="bi bi-exclamation-triangle"></i> Danger Zone</h4>
    <div class="section-desc">Irreversible actions. Please be certain before proceeding.</div>
    <div style="display:flex;align-items:center;justify-content:space-between;padding:14px;background:#fef2f2;border-radius:8px;border:1px solid #fecaca;">
      <div>
        <div style="font-size:13px;font-weight:500;color:var(--text-primary);">Sign out of all sessions</div>
        <div style="font-size:12px;color:var(--text-muted);">This will log you out from all devices.</div>
      </div>
      <a href="../logout.php" class="btn-danger">
        <i class="bi bi-box-arrow-right"></i> Sign Out
      </a>
    </div>
  </div>

</main>
</div>

<?php include 'footer.php'; ?>
<script>
function togglePw(inputId, btn) {
  var input = document.getElementById(inputId);
  var icon  = btn.querySelector('i');
  if (input.type === 'password') {
    input.type = 'text';
    icon.className = 'bi bi-eye-slash';
  } else {
    input.type = 'password';
    icon.className = 'bi bi-eye';
  }
}

document.getElementById('pwForm').addEventListener('submit', function(e) {
  var np = document.getElementById('new_pw').value;
  var cp = document.getElementById('conf_pw').value;
  var msg = document.getElementById('pwMismatch');
  if (np !== cp) {
    e.preventDefault();
    msg.style.display = 'flex';
  } else {
    msg.style.display = 'none';
  }
});
</script>
</body>
</html>
