<?php
session_start();
require_once '../config.php';
require_once '../db_functions.php';
require_login('organizer');
header('Location: dashboard.php');
exit;
