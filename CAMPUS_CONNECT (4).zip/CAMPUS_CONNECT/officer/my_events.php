<?php
session_start();
require_once '../config.php';
require_once '../db_functions.php';
require_login('organizer');

$user_id     = $_SESSION['user_id'];
$active_page = 'events';

$stmt = $pdo->prepare("SELECT * FROM events WHERE organizer_id = ? ORDER BY event_date ASC");
$stmt->execute([$user_id]);
$eventsArr = $stmt->fetchAll(PDO::FETCH_ASSOC);

$flash = $_SESSION['flash'] ?? null;
unset($_SESSION['flash']);

// Fetch event to edit (if edit_id in query string)
$editEvent = null;
if (!empty($_GET['edit'])) {
  $es = $pdo->prepare("SELECT * FROM events WHERE id = ? AND organizer_id = ?");
  $es->execute([(int)$_GET['edit'], $user_id]);
  $editEvent = $es->fetch(PDO::FETCH_ASSOC);
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>My Events – CampusConnect</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="css/officer.css">
</head>
<body>

<?php include 'header.php'; ?>

<div class="layout">
<?php include 'sidebar.php'; ?>

<main class="main">
  <?php if ($flash): ?>
  <div class="alert alert-<?= $flash['type'] === 'success' ? 'success' : 'error' ?>" style="margin-bottom:20px;">
    <i class="bi bi-<?= $flash['type'] === 'success' ? 'check-circle' : 'exclamation-circle' ?>"></i>
    <?= htmlspecialchars($flash['msg']) ?>
  </div>
  <?php endif; ?>

  <div class="page-header">
    <div>
      <div class="page-title">My Events</div>
      <div class="page-sub"><?= $total_events = count($eventsArr) ?> total events</div>
    </div>
    <button class="btn-primary" onclick="openModal('createModal')">
      <i class="bi bi-plus-lg"></i> New Event
    </button>
  </div>

  <div class="page-toolbar">
    <div class="search-box">
      <i class="bi bi-search"></i>
      <input type="text" id="eventSearch" placeholder="Search events..." oninput="filterEvents()">
    </div>
    <select class="filter-select" id="statusFilter" onchange="filterEvents()">
      <option value="">All Status</option>
      <option value="draft">Draft</option>
      <option value="pending">Pending</option>
      <option value="approved">Approved</option>
      <option value="ongoing">Ongoing</option>
      <option value="completed">Completed</option>
      <option value="rejected">Rejected</option>
    </select>
  </div>

  <div class="card">
    <table class="data-table" id="eventsTable">
      <thead>
        <tr>
          <th>Event Name</th>
          <th>Date &amp; Time</th>
          <th>Location</th>
          <th>Registrations</th>
          <th>Status</th>
          <th>Actions</th>
        </tr>
      </thead>
      <tbody>
        <?php if (empty($eventsArr)): ?>
        <tr>
          <td colspan="6">
            <div class="empty-state">
              <i class="bi bi-calendar-x"></i>
              <p>No events yet. Create your first event above!</p>
            </div>
          </td>
        </tr>
        <?php else: ?>
        <?php foreach ($eventsArr as $e):
          $rs = $pdo->prepare("SELECT COUNT(*) FROM registrations WHERE event_id = ?");
          $rs->execute([(int)$e['id']]);
          $reg_count = (int)$rs->fetchColumn();
          $cap       = (int)($e['capacity'] ?? 100);
          $pct       = $cap > 0 ? min(100, round($reg_count / $cap * 100)) : 0;
          $bar_class = $pct >= 80 ? 'red' : ($pct >= 40 ? 'yellow' : 'gray');
          $status    = $e['status'] ?? 'draft';
          $badgeMap  = [
            'draft'     => 'badge-draft',
            'pending'   => 'badge-pending',
            'approved'  => 'badge-approved',
            'ongoing'   => 'badge-ongoing',
            'completed' => 'badge-completed',
            'rejected'  => 'badge-rejected',
          ];
          $badge = $badgeMap[$status] ?? 'badge-draft';
        ?>
        <tr data-title="<?= strtolower(htmlspecialchars($e['title'])) ?>" data-status="<?= $status ?>">
          <td><strong><?= htmlspecialchars($e['title']) ?></strong>
            <?php if (!empty($e['description'])): ?>
            <div style="font-size:11.5px;color:var(--text-muted);margin-top:2px;max-width:220px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">
              <?= htmlspecialchars($e['description']) ?>
            </div>
            <?php endif; ?>
          </td>
          <td>
            <?= isset($e['event_date']) ? date('M j, Y', strtotime($e['event_date'])) : '—' ?>
            <?php if (!empty($e['event_time'])): ?>
            <br><span style="font-size:12px;color:var(--text-muted);"><?= htmlspecialchars($e['event_time']) ?></span>
            <?php endif; ?>
          </td>
          <td><?= htmlspecialchars($e['location'] ?? '—') ?></td>
          <td>
            <div class="reg-bar-wrap">
              <div class="reg-bar-track">
                <div class="reg-bar-fill <?= $bar_class ?>" style="width:<?= $pct ?>%"></div>
              </div>
              <span class="reg-count"><?= $reg_count ?> / <?= $cap ?></span>
            </div>
            <?php if (!empty($e['registration_deadline'])): ?>
            <div style="font-size:10.5px;color:var(--text-muted);margin-top:3px;">
              <i class="bi bi-calendar-x" style="color:#f59e0b;"></i>
              Deadline: <?= date('M j, Y', strtotime($e['registration_deadline'])) ?>
              <?php if (strtotime($e['registration_deadline'] . ' 23:59:59') < time()): ?>
                <span style="color:#ef4444;font-weight:600;"> (Closed)</span>
              <?php endif; ?>
            </div>
            <?php endif; ?>
          </td>
          <td><span class="badge <?= $badge ?>"><?= ucfirst($status) ?></span></td>
          <td>
            <div class="table-actions">
              <?php if ($status === 'draft'): ?>
              <form method="POST" action="actions/update_event_status.php" style="display:inline;" title="Submit for Approval">
                <input type="hidden" name="event_id" value="<?= $e['id'] ?>">
                <input type="hidden" name="status" value="pending">
                <button type="submit" class="action-btn approve" title="Submit for Approval"><i class="bi bi-send"></i></button>
              </form>
              <?php endif; ?>
              <?php if ($status === 'pending'): ?>
              <form method="POST" action="actions/update_event_status.php" style="display:inline;" onsubmit="return confirm('Pull back to Draft?')" title="Back to Draft">
                <input type="hidden" name="event_id" value="<?= $e['id'] ?>">
                <input type="hidden" name="status" value="draft">
                <button type="submit" class="action-btn" style="background:#94a3b8;color:#fff;" title="Back to Draft"><i class="bi bi-arrow-counterclockwise"></i></button>
              </form>
              <?php endif; ?>
              <?php if (in_array($status, ['approved','ongoing'])): ?>
              <form method="POST" action="actions/update_event_status.php" style="display:inline;" onsubmit="return confirm('Mark this event as Completed?')">
                <input type="hidden" name="event_id" value="<?= $e['id'] ?>">
                <input type="hidden" name="status" value="completed">
                <button type="submit" class="action-btn" style="background:#6366f1;color:#fff;" title="Mark Completed"><i class="bi bi-flag-fill"></i></button>
              </form>
              <?php endif; ?>
              <?php if (!in_array($status, ['ongoing','completed'])): ?>
              <button class="action-btn" title="Edit" onclick="openEditModal(<?= htmlspecialchars(json_encode($e)) ?>)">
                <i class="bi bi-pencil"></i>
              </button>
              <?php endif; ?>
              <button class="action-btn danger" title="Delete"
                onclick="openDeleteModal(<?= $e['id'] ?>, '<?= addslashes(htmlspecialchars($e['title'])) ?>', <?= $reg_count ?>)">
                <i class="bi bi-trash"></i>
              </button>
            </div>
          </td>
        </tr>
        <?php endforeach; ?>

        <?php endif; ?>
      </tbody>
    </table>
  </div>
</main>
</div>

<?php include 'create_event_modal.php'; ?>
<?php include 'delete_event_modal.php'; ?>

<?php include 'delete_event_modal.php'; ?>
<input type="hidden" id="delete_event_id">
</xai:function_call name="create_file">
<parameter name="absolute_path">c:/xampp/htdocs/CAMPUS_CONNECT/officer/js/modals.js

<!-- EDIT EVENT MODAL -->
<div id="editModal" class="modal-overlay">
  <div class="modal-box">
    <div class="modal-header">
      <h4><i class="bi bi-pencil-square" style="color:var(--red);margin-right:8px;"></i>Edit Event</h4>
      <button class="modal-close" onclick="closeModal('editModal')">&times;</button>
    </div>
    <form method="POST" action="actions/edit_event.php">
      <input type="hidden" name="event_id" id="edit_event_id">
      <div class="form-group">
        <label>Event Title *</label>
        <input type="text" name="title" id="edit_title" required>
      </div>
      <div class="form-group">
        <label>Description</label>
        <textarea name="description" id="edit_description"></textarea>
      </div>
      <div class="form-row">
        <div class="form-group">
          <label>Date *</label>
          <input type="date" name="event_date" id="edit_date" required>
        </div>
        <div class="form-group">
          <label>Time</label>
          <input type="time" name="event_time" id="edit_time">
        </div>
      </div>
      <div class="form-group">
        <label>Location</label>
        <input type="text" name="location" id="edit_location">
      </div>
      <div class="form-row">
        <div class="form-group">
          <label>Max Participants</label>
          <input type="number" name="max_attendees" id="edit_max_attendees" min="1">
          <small style="font-size:11px;color:var(--text-muted);">Registration closes when full</small>
        </div>
        <div class="form-group">
          <label>Registration Deadline</label>
          <input type="date" name="registration_deadline" id="edit_registration_deadline">
          <small style="font-size:11px;color:var(--text-muted);">Optional — cuts off sign-ups on this date</small>
        </div>
      </div>
      <div class="form-row">
        <div class="form-group">
          <label>Category</label>
          <select name="category" id="edit_category">
            <option value="general">General</option>
            <option value="academic">Academic</option>
            <option value="social">Social</option>
            <option value="sports">Sports</option>
            <option value="org">Organization</option>
          </select>
        </div>
      </div>
      <div class="modal-actions">
        <button type="submit" class="btn-save"><i class="bi bi-check-lg"></i> Update Event</button>
        <button type="button" class="btn-cancel" onclick="closeModal('editModal')">Cancel</button>
      </div>
    </form>
  </div>
</div>

<?php include 'footer.php'; ?>
<script>
function openModal(id) {
  document.querySelectorAll('.modal-overlay').forEach(m => m.style.display = 'none');
  document.getElementById(id).style.display = 'flex';
}

function closeModal(id) {
  document.getElementById(id).style.display = 'none';
}

function openEditModal(event) {
  document.getElementById('edit_event_id').value  = event.id;
  document.getElementById('edit_title').value      = event.title || '';
  document.getElementById('edit_description').value = event.description || '';
  document.getElementById('edit_date').value        = event.event_date ? event.event_date.substr(0,10) : '';
  document.getElementById('edit_time').value        = event.event_time || '';
  document.getElementById('edit_location').value   = event.location || '';
  document.getElementById('edit_max_attendees').value = event.max_attendees || event.capacity || 100;
  document.getElementById('edit_registration_deadline').value = event.registration_deadline ? event.registration_deadline.substr(0,10) : '';
  const cat = document.getElementById('edit_category');
  for (var i = 0; i < cat.options.length; i++) {
    if (cat.options[i].value === (event.category || 'general')) { cat.selectedIndex = i; break; }
  }
  openModal('editModal');
}


function openDeleteModal(id, title, regCount) {
  document.getElementById('deleteEventTitle').textContent = title;
  const regEl = document.getElementById('deleteRegCount');
  if (regCount > 0) {
    regEl.textContent = regCount + ' student(s) registered';
    regEl.style.display = 'block';
    document.getElementById('reasonGroup').style.display = 'block';
    document.getElementById('deleteReason').required = true;
  } else {
    regEl.style.display = 'none';
    document.getElementById('reasonGroup').style.display = 'none';
    document.getElementById('deleteReason').required = false;
  }
  document.getElementById('delete_event_id').value = id;
  document.getElementById('deleteConfirmBtn').dataset.id = id;
  document.getElementById('deleteReason').value = '';
  toggleDeleteBtn();
  openModal('deleteModal');
}

function toggleDeleteBtn() {
  const reasonGroup = document.getElementById('reasonGroup');
  const btn = document.getElementById('deleteConfirmBtn');
  const reason = document.getElementById('deleteReason').value.trim();
  if (reasonGroup.style.display === 'none' || reason.length > 0) {
    btn.disabled = false;
  } else {
    btn.disabled = true;
  }
}


function submitDeletionRequest() {
  const reason = document.getElementById('deleteReason').value.trim();
  if (reason || document.getElementById('reasonGroup').style.display === 'none') {
    const id = document.getElementById('deleteConfirmBtn').dataset.id;
    const fd = new FormData();
    fd.append('event_id', id);
    fd.append('reason', reason);
    fetch('actions/request_event_deletion.php', { method: 'POST', body: fd })
      .then(() => location.reload())
      .catch(() => alert('Error'));
  } else {
    alert('Reason required when students registered');
  }
}


function filterEvents() {
  const q      = document.getElementById('eventSearch').value.toLowerCase();
  const status = document.getElementById('statusFilter').value;
  document.querySelectorAll('#eventsTable tbody tr').forEach(function(tr) {
    const title   = tr.dataset.title   || '';
    const tStatus = tr.dataset.status  || '';
    const matchQ  = title.includes(q);
    const matchS  = !status || tStatus === status;
    tr.style.display = matchQ && matchS ? '' : 'none';
  });
}
</script>

</body>
</html>
