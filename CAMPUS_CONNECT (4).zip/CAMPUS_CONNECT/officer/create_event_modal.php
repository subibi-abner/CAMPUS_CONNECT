<!-- CREATE EVENT MODAL -->
<div id="createModal" class="modal-overlay">
  <div class="modal-box">
    <div class="modal-header">
      <h4><i class="bi bi-calendar-plus" style="color:var(--red);margin-right:8px;"></i>Create New Event</h4>
      <button class="modal-close" onclick="closeModal('createModal')">&times;</button>
    </div>
    <form method="POST" action="actions/create_event.php">
      <div class="form-group">
        <label>Event Title *</label>
        <input type="text" name="title" placeholder="Enter event title" required>
      </div>
      <div class="form-group">
        <label>Description</label>
        <textarea name="description" placeholder="Brief description of the event..."></textarea>
      </div>
      <div class="form-row">
        <div class="form-group">
          <label>Date *</label>
          <input type="date" name="event_date" required>
        </div>
        <div class="form-group">
          <label>Time</label>
          <input type="time" name="event_time">
        </div>
      </div>
      <div class="form-group">
        <label>Location</label>
        <input type="text" name="location" placeholder="Venue or room number">
      </div>
      <div class="form-row">
        <div class="form-group">
          <label>Max Participants</label>
          <input type="number" name="max_attendees" placeholder="e.g. 100" min="1" value="100">
          <small style="font-size:11px;color:var(--text-muted);">Registration closes when full</small>
        </div>
        <div class="form-group">
          <label>Registration Deadline</label>
          <input type="date" name="registration_deadline">
          <small style="font-size:11px;color:var(--text-muted);">Optional — cuts off sign-ups on this date</small>
        </div>
      </div>
      <div class="form-row">
        <div class="form-group">
          <label>Category</label>
          <select name="category">
            <option value="general">General</option>
            <option value="academic">Academic</option>
            <option value="social">Social</option>
            <option value="sports">Sports</option>
            <option value="org">Organization</option>
          </select>
        </div>
        <div class="form-group">
          <label>Department Restriction (Optional)</label>
          <select name="department_id">
            <option value="">Open to all departments</option>
            <?php
              $depts = $pdo->query("SELECT id, name FROM departments ORDER BY name")->fetchAll(PDO::FETCH_ASSOC);
              foreach ($depts as $d): ?>
            <option value="<?= $d['id'] ?>"><?= htmlspecialchars($d['name']) ?></option>
            <?php endforeach; ?>
          </select>
        </div>
      </div>
      <div class="modal-actions">
        <button type="submit" class="btn-save"><i class="bi bi-check-lg"></i> Save Event</button>
        <button type="button" class="btn-cancel" onclick="closeModal('createModal')">Cancel</button>
      </div>
    </form>
  </div>
</div>
