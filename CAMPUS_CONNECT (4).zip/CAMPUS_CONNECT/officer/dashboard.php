<?php
session_start();
require_once '../config.php';
require_once '../db_functions.php';
require_login('organizer');

$user_id     = $_SESSION['user_id'];
$active_page = 'dashboard';

// Fetch events
$stmt = $pdo->prepare("SELECT * FROM events WHERE organizer_id = ? ORDER BY event_date ASC");
$stmt->execute([$user_id]);
$eventsArr = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Stats
$total_events = count($eventsArr);
$pending = 0; $approved = 0;
foreach ($eventsArr as $e) {
  if (($e['status'] ?? 'pending') === 'approved') $approved++;
  else $pending++;
}

$stmt = $pdo->prepare("SELECT COUNT(*) FROM registrations r JOIN events e ON r.event_id = e.id WHERE e.organizer_id = ?");
$stmt->execute([$user_id]);
$total_reg = $stmt->fetchColumn();

$recentEvents = array_slice($eventsArr, 0, 4);

// Flash message
$flash = $_SESSION['flash'] ?? null;
unset($_SESSION['flash']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Dashboard – CampusConnect</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="css/officer.css">
</head>
<body>

<?php include 'header.php'; ?>

<div class="layout">
<?php include 'sidebar.php'; ?>

<main class="main">
  <?php if ($flash): ?>
  <div class="alert alert-<?= $flash['type'] === 'success' ? 'success' : 'error' ?>" style="margin-bottom:20px;">
    <i class="bi bi-<?= $flash['type'] === 'success' ? 'check-circle' : 'exclamation-circle' ?>"></i>
    <?= htmlspecialchars($flash['msg']) ?>
  </div>
  <?php endif; ?>

  <div class="page-header">
    <div>
      <div class="page-title">Dashboard</div>
      <div class="page-sub"><?= date('l, F j, Y') ?> &bull; Welcome back, <?= htmlspecialchars($_SESSION['full_name'] ?? 'Officer') ?>!</div>
    </div>
    <button class="btn-primary" onclick="openModal('createModal')">
      <i class="bi bi-plus-lg"></i> New Event
    </button>
  </div>

  <!-- Stats -->
  <div class="stats-row">
    <div class="stat-card">
      <div class="stat-icon red"><i class="bi bi-calendar3"></i></div>
      <div class="stat-info">
        <div class="stat-value"><?= $total_events ?></div>
        <div class="stat-label">Total Events</div>
      </div>
    </div>
    <div class="stat-card">
      <div class="stat-icon yellow"><i class="bi bi-clock-history"></i></div>
      <div class="stat-info">
        <div class="stat-value"><?= $pending ?></div>
        <div class="stat-label">Pending Approval</div>
      </div>
    </div>
    <div class="stat-card">
      <div class="stat-icon green"><i class="bi bi-check-circle"></i></div>
      <div class="stat-info">
        <div class="stat-value"><?= $approved ?></div>
        <div class="stat-label">Approved Events</div>
      </div>
    </div>
    <div class="stat-card">
      <div class="stat-icon blue"><i class="bi bi-people"></i></div>
      <div class="stat-info">
        <div class="stat-value"><?= $total_reg ?></div>
        <div class="stat-label">Total Registrations</div>
      </div>
    </div>
  </div>

  <!-- Two-col grid -->
  <div class="two-col">
    <!-- Events Overview -->
    <div class="card">
      <div class="card-header">
        <h4>My Events Overview</h4>
        <a href="my_events.php">All Events &rarr;</a>
      </div>
      <table class="data-table">
        <thead>
          <tr>
            <th>Event</th>
            <th>Date</th>
            <th>Registrations</th>
            <th>Status</th>
          </tr>
        </thead>
        <tbody>
          <?php if (empty($eventsArr)): ?>
          <tr>
            <td colspan="4">
              <div class="empty-state" style="padding:40px 20px;">
                <i class="bi bi-calendar-x"></i>
                <p>No events yet. Create your first event!</p>
              </div>
            </td>
          </tr>
          <?php else: ?>
          <?php foreach ($eventsArr as $e):
            $rs = $pdo->prepare("SELECT COUNT(*) FROM registrations WHERE event_id = ?");
            $rs->execute([(int)$e['id']]);
            $reg_count = (int)$rs->fetchColumn();
            $cap       = (int)($e['capacity'] ?? 100);
            $pct       = $cap > 0 ? min(100, round($reg_count / $cap * 100)) : 0;
            $bar_class = $pct >= 80 ? 'red' : ($pct >= 40 ? 'yellow' : 'gray');
            $status    = $e['status'] ?? 'pending';
            $badge     = $status === 'approved' ? 'badge-approved' : 'badge-pending';
          ?>
          <tr>
            <td><strong><?= htmlspecialchars($e['title']) ?></strong></td>
            <td><?= isset($e['event_date']) ? date('M j, Y', strtotime($e['event_date'])) : '—' ?></td>
            <td>
              <div class="reg-bar-wrap">
                <div class="reg-bar-track">
                  <div class="reg-bar-fill <?= $bar_class ?>" style="width:<?= $pct ?>%"></div>
                </div>
                <span class="reg-count"><?= $reg_count ?> / <?= $cap ?></span>
              </div>
            </td>
            <td><span class="badge <?= $badge ?>"><?= ucfirst($status) ?></span></td>
          </tr>
          <?php endforeach; ?>
          <?php endif; ?>
        </tbody>
      </table>
    </div>

    <!-- Right column -->
    <div class="right-col">
      <!-- Quick Actions -->
      <div class="card">
        <div class="card-header"><h4>Quick Actions</h4></div>
        <div class="quick-actions">
          <button class="btn-primary" style="width:100%;justify-content:center;" onclick="openModal('createModal')">
            <i class="bi bi-plus-lg"></i> Create New Event
          </button>
          <a href="registrations.php" class="btn-outline" style="width:100%;justify-content:center;text-align:center;">
            <i class="bi bi-list-ul"></i> View Registrations
          </a>
          <a href="my_events.php" class="btn-outline" style="width:100%;justify-content:center;text-align:center;">
            <i class="bi bi-calendar3"></i> Manage Events
          </a>
        </div>
      </div>

      <!-- Recent Activity -->
      <div class="card">
        <div class="card-header"><h4>Recent Activity</h4></div>
        <?php if (empty($recentEvents)): ?>
        <div class="empty-state" style="padding:30px;">
          <i class="bi bi-activity"></i>
          <p>No recent activity</p>
        </div>
        <?php else: ?>
        <ul class="activity-list">
          <?php foreach ($recentEvents as $e):
            $status = $e['status'] ?? 'pending';
            $cls = $status === 'approved' ? 'green' : 'yellow';
            $icon = $status === 'approved' ? 'bi-check-lg' : 'bi-clock';
          ?>
          <li>
            <div class="act-dot <?= $cls ?>"><i class="bi <?= $icon ?>"></i></div>
            <div class="act-text">
              <strong><?= htmlspecialchars($e['title']) ?></strong>
              <?= $status === 'approved' ? 'was approved' : 'submitted for approval' ?>
              <div class="act-time"><?= isset($e['created_at']) ? date('M j, Y', strtotime($e['created_at'])) : 'Recently' ?></div>
            </div>
          </li>
          <?php endforeach; ?>
        </ul>
        <?php endif; ?>
      </div>
    </div>
  </div>
</main>
</div>

<?php include 'create_event_modal.php'; ?>
<?php include 'footer.php'; ?>
</body>
</html>
