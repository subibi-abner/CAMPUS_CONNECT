<?php
/**
 * header.php — Officer topbar with Profile & Settings as modals (same design as student)
 * Requires: session started, $pdo available
 */
$officer_name    = $_SESSION['full_name'] ?? 'Officer';
$officer_initial = strtoupper(substr($officer_name, 0, 1));
$officer_email   = $_SESSION['email']    ?? '';
$officer_role    = 'Organizer';

// Fetch fresh data for modal pre-fill
$_officer_row = null;
try {
  $s = $pdo->prepare("SELECT u.*, d.name AS department_name, d.code AS dept_code, d.id AS cid FROM users u LEFT JOIN departments d ON u.department_id=d.id WHERE u.id=?");
  $s->execute([$_SESSION['user_id'] ?? 0]);
  $_officer_row = $s->fetch(PDO::FETCH_ASSOC);
  if ($_officer_row) {
    $officer_name    = $_officer_row['full_name'] ?? $officer_name;
    $officer_initial = strtoupper(substr($officer_name,0,1));
    $officer_email   = $_officer_row['email'] ?? $officer_email;
  }
} catch (Exception $e) {}

// Pre-load departments for modal
$_modal_depts = [];
try {
  $sc = $pdo->query("SELECT id, name FROM departments ORDER BY name ASC");
  $_modal_depts = $sc->fetchAll(PDO::FETCH_ASSOC);
} catch (Exception $e) {}
?>

<header class="topbar">
  <div class="topbar-left">
    <div class="logo-wrap">
      <div class="logo-circle">C</div>
      <div>
        <div class="logo-text">CampusConnect</div>
        <div class="logo-sub">Organizer Portal</div>
      </div>
    </div>
    <div class="topbar-search">
      <i class="bi bi-search"></i>
      <input type="text" placeholder="Search events, registrations...">
    </div>
  </div>
  <div class="topbar-right">
    <button class="icon-btn" title="Notifications">
      <i class="bi bi-bell"></i>
      <span class="notif-dot"></span>
    </button>
    <div class="dropdown">
      <button class="avatar-btn" onclick="toggleDropdown(this)">
        <div class="avatar"><?= $officer_initial ?></div>
        <div>
          <div class="avatar-name"><?= htmlspecialchars($officer_name) ?></div>
          <div class="avatar-role">Organizer</div>
        </div>
        <i class="bi bi-chevron-down" style="font-size:11px;color:var(--text-muted);margin-left:4px;"></i>
      </button>
      <div class="dropdown-menu" id="avatarDropdown">
        <a href="#" class="dropdown-item" onclick="openOfficerProfile();closeDropdown();return false;">
          <i class="bi bi-person"></i> My Profile
        </a>
        <a href="#" class="dropdown-item" onclick="openOfficerSettings();closeDropdown();return false;">
          <i class="bi bi-gear"></i> Settings
        </a>
        <div class="dropdown-divider"></div>
        <a href="../logout.php" class="dropdown-item danger"><i class="bi bi-box-arrow-right"></i> Sign Out</a>
      </div>
    </div>
  </div>
</header>


<!-- ══ OFFICER PROFILE MODAL ══ -->
<div class="modal-overlay" id="officerProfileModal" onclick="if(event.target===this)closeOfficerProfile()">
  <div class="modal-box" style="max-width:520px;">
    <div class="modal-banner-wrap">
      <div class="modal-banner" style="background:linear-gradient(135deg,#1a0a0b,#3a1a1d);">
        <div style="width:72px;height:72px;border-radius:50%;background:var(--red);color:#fff;font-size:30px;font-weight:700;display:flex;align-items:center;justify-content:center;" id="officerModalAvatar">
          <?= $officer_initial ?>
        </div>
      </div>
      <button class="btn-modal-close" onclick="closeOfficerProfile()"><i class="bi bi-x"></i></button>
    </div>
    <div class="modal-body">
      <div class="modal-title" style="margin-bottom:4px;">Officer Profile</div>
      <div style="font-size:12px;color:var(--text-muted);margin-bottom:20px;">Update your organization and personal details</div>

      <div style="display:grid;gap:14px;">

        <div>
          <label class="modal-field-label">Organization / Officer Name *</label>
          <input id="officerName" type="text" class="modal-input" placeholder="e.g. CSS Society – Juan dela Cruz"
            value="<?= htmlspecialchars($_officer_row['full_name'] ?? '') ?>">
        </div>

        <div>
          <label class="modal-field-label">Email Address</label>
          <input type="email" class="modal-input" value="<?= htmlspecialchars($_officer_row['email'] ?? '') ?>"
            disabled style="background:#fafafa;cursor:not-allowed;color:var(--text-muted);">
          <div style="font-size:11px;color:var(--text-muted);margin-top:4px;"><i class="bi bi-info-circle"></i> Email cannot be changed here.</div>
        </div>

        <div>
          <label class="modal-field-label">Department</label>
          <select id="officerCollege" class="modal-input">
            <option value="">— Select Department —</option>
            <?php foreach ($_modal_depts as $col): ?>
            <option value="<?= $col['id'] ?>" <?= (($_officer_row['department_id'] ?? null) == $col['id']) ? 'selected' : '' ?>>
              <?= htmlspecialchars($col['name']) ?>
            </option>
            <?php endforeach; ?>
          </select>
        </div>

        <div>
          <label class="modal-field-label">Description / Bio</label>
          <textarea id="officerBio" class="modal-input" rows="3" placeholder="Tell students about your organization..."
            style="resize:vertical;"><?= htmlspecialchars($_officer_row['bio'] ?? '') ?></textarea>
        </div>

        <div>
          <label class="modal-field-label">Contact / Facebook / Website</label>
          <input id="officerContact" type="text" class="modal-input"
            value="<?= htmlspecialchars($_officer_row['contact'] ?? '') ?>"
            placeholder="e.g. fb.com/csssociety or email@wmsu.edu.ph">
        </div>

      </div>

      <div class="modal-footer" style="margin-top:22px;">
        <button type="button" class="btn-join" onclick="saveOfficerProfile()">
          <i class="bi bi-person-check me-1"></i>Save Profile
        </button>
        <button type="button" class="btn-modal-save" onclick="closeOfficerProfile()">Cancel</button>
      </div>
    </div>
  </div>
</div>


<!-- ══ OFFICER SETTINGS MODAL ══ -->
<div class="modal-overlay" id="officerSettingsModal" onclick="if(event.target===this)closeOfficerSettings()">
  <div class="modal-box" style="max-width:460px;">
    <div class="modal-banner-wrap">
      <div class="modal-banner" style="background:linear-gradient(135deg,#1a0a0b,#3a1a1d);font-size:44px;">⚙️</div>
      <button class="btn-modal-close" onclick="closeOfficerSettings()"><i class="bi bi-x"></i></button>
    </div>
    <div class="modal-body">
      <div class="modal-title" style="margin-bottom:4px;">Settings</div>
      <div style="font-size:12px;color:var(--text-muted);margin-bottom:20px;">Manage your account and security</div>

      <!-- Change Password -->
      <div style="margin-bottom:22px;">
        <div class="modal-section-label"><i class="bi bi-lock me-1"></i>Change Password</div>
        <div style="display:grid;gap:10px;">
          <div>
            <label class="modal-field-label">Current Password</label>
            <div style="position:relative;">
              <input type="password" id="offCurPw" class="modal-input" placeholder="Current password" style="padding-right:40px;">
              <button type="button" class="pw-eye-btn" onclick="togglePwVisOff('offCurPw',this)"><i class="bi bi-eye"></i></button>
            </div>
          </div>
          <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px;">
            <div>
              <label class="modal-field-label">New Password</label>
              <div style="position:relative;">
                <input type="password" id="offNewPw" class="modal-input" placeholder="Min 6 characters" style="padding-right:40px;">
                <button type="button" class="pw-eye-btn" onclick="togglePwVisOff('offNewPw',this)"><i class="bi bi-eye"></i></button>
              </div>
            </div>
            <div>
              <label class="modal-field-label">Confirm Password</label>
              <div style="position:relative;">
                <input type="password" id="offConfPw" class="modal-input" placeholder="Repeat password" style="padding-right:40px;">
                <button type="button" class="pw-eye-btn" onclick="togglePwVisOff('offConfPw',this)"><i class="bi bi-eye"></i></button>
              </div>
            </div>
          </div>
          <div id="offPwMismatch" style="display:none;font-size:12px;color:#dc2626;padding:8px 12px;background:#fee2e2;border-radius:7px;">
            <i class="bi bi-exclamation-circle me-1"></i>Passwords do not match.
          </div>
          <button type="button" class="btn-primary" onclick="saveOfficerPassword()">
            <i class="bi bi-check-lg"></i> Update Password
          </button>
        </div>
      </div>

      <!-- Account Info (read-only) -->
      <div style="margin-bottom:20px;">
        <div class="modal-section-label"><i class="bi bi-person-circle me-1"></i>Account Information</div>
        <div style="padding:12px 14px;background:#fafafa;border:1px solid var(--border);border-radius:9px;font-size:13px;">
          <div style="margin-bottom:6px;"><span style="color:var(--text-muted);font-size:11px;">Name</span><br><?= htmlspecialchars($officer_name) ?></div>
          <div style="margin-bottom:6px;"><span style="color:var(--text-muted);font-size:11px;">Email</span><br><?= htmlspecialchars($officer_email) ?></div>
          <div><span style="color:var(--text-muted);font-size:11px;">Role</span><br>Organizer</div>
        </div>
      </div>

      <!-- Sign Out -->
      <div style="background:#fef2f2;border:1.5px solid #fecaca;border-radius:10px;padding:14px;display:flex;align-items:center;justify-content:space-between;">
        <div>
          <div style="font-size:13px;font-weight:600;color:#b91c1c;">Sign Out</div>
          <div style="font-size:12px;color:var(--text-muted);">End your current session</div>
        </div>
        <a href="../logout.php" style="background:#ef4444;color:#fff;border:none;padding:8px 16px;border-radius:8px;font-size:13px;font-weight:500;text-decoration:none;display:flex;align-items:center;gap:6px;">
          <i class="bi bi-box-arrow-right"></i> Sign Out
        </a>
      </div>

    </div>
  </div>
</div>


<style>
/* ── Shared modal field styles (officer) ── */
.modal-overlay {
  position:fixed;inset:0;background:rgba(0,0,0,0.45);
  z-index:300;display:none;align-items:center;justify-content:center;
}
.modal-overlay.open { display:flex; }
.modal-box {
  background:#fff;border-radius:16px;width:100%;max-width:500px;
  max-height:90vh;overflow-y:auto;margin:20px;
  animation:popIn .2s ease;
}
@keyframes popIn { from{transform:scale(.95);opacity:0} to{transform:scale(1);opacity:1} }
.modal-banner-wrap { position:relative; }
.modal-banner {
  height:120px;display:flex;align-items:center;justify-content:center;
  border-radius:16px 16px 0 0;
}
.modal-body { padding:22px 24px 28px; }
.modal-title { font-size:20px;font-weight:700;color:var(--text-primary); }
.modal-footer { display:flex;gap:10px;margin-top:20px; }
.btn-join {
  flex:1;padding:11px;border-radius:9px;background:var(--red);color:#fff;
  border:none;font-size:14px;font-weight:600;cursor:pointer;transition:background .15s;
}
.btn-join:hover { background:var(--red-dark); }
.btn-modal-save {
  padding:11px 18px;border-radius:9px;border:1.5px solid var(--border);
  background:none;color:var(--text-secondary);font-size:14px;font-weight:500;
  cursor:pointer;transition:all .15s;
}
.btn-modal-save:hover { border-color:var(--red);color:var(--red); }
.btn-modal-close {
  position:absolute;top:12px;right:12px;width:32px;height:32px;border-radius:50%;
  background:rgba(0,0,0,0.35);border:none;color:#fff;font-size:16px;cursor:pointer;
  display:flex;align-items:center;justify-content:center;
}
.modal-field-label {
  font-size:12px;font-weight:600;color:var(--text-secondary);
  display:block;margin-bottom:5px;
}
.modal-input {
  width:100%;padding:9px 12px;border:1.5px solid var(--border);
  border-radius:8px;font-size:13px;outline:none;
  font-family:Poppins,sans-serif;background:#fff;
  transition:border-color .15s;
}
.modal-input:focus { border-color:var(--red); }
.modal-section-label {
  font-size:11px;font-weight:700;color:var(--text-muted);
  text-transform:uppercase;letter-spacing:.08em;margin-bottom:12px;
}
.pw-eye-btn {
  position:absolute;right:10px;top:50%;transform:translateY(-50%);
  background:none;border:none;cursor:pointer;color:var(--text-muted);font-size:15px;padding:0;
}
.pw-eye-btn:hover { color:var(--text-primary); }
</style>

<script>
/* ── Dropdown ── */
function toggleDropdown(btn) {
  var menu = document.getElementById('avatarDropdown');
  var open = menu.classList.contains('show');
  document.querySelectorAll('.dropdown-menu.show').forEach(m => m.classList.remove('show'));
  if (!open) menu.classList.add('show');
}
function closeDropdown() {
  document.querySelectorAll('.dropdown-menu.show').forEach(m => m.classList.remove('show'));
}
document.addEventListener('click', function(e) {
  if (!e.target.closest('.dropdown')) closeDropdown();
});

/* ── Officer Profile Modal ── */
function openOfficerProfile()  { document.getElementById('officerProfileModal').classList.add('open'); }
function closeOfficerProfile() { document.getElementById('officerProfileModal').classList.remove('open'); }

function saveOfficerProfile() {
  var name    = document.getElementById('officerName').value.trim();
  var college = document.getElementById('officerCollege').value;
  var bio     = document.getElementById('officerBio').value.trim();
  var contact = document.getElementById('officerContact').value.trim();
  if (!name) { alert('Name is required'); return; }

  var fd = new FormData();
  fd.append('org_name',   name);
  fd.append('department_id', college);
  fd.append('bio',        bio);
  fd.append('contact',    contact);

  fetch('actions/update_profile.php', { method:'POST', body:fd })
    .then(r => r.json()).then(res => {
      if (res.success) {
        document.querySelectorAll('.avatar-name').forEach(el => el.textContent = res.full_name || name);
        document.querySelectorAll('.avatar').forEach(el => el.textContent = (res.full_name||name).charAt(0).toUpperCase());
        document.getElementById('officerModalAvatar').textContent = (res.full_name||name).charAt(0).toUpperCase();
        closeOfficerProfile();
        showFlash('Profile updated successfully!', 'success');
      } else {
        showFlash(res.msg || 'Update failed', 'error');
      }
    }).catch(() => showFlash('Network error','error'));
}

/* ── Officer Settings Modal ── */
function openOfficerSettings()  { document.getElementById('officerSettingsModal').classList.add('open'); }
function closeOfficerSettings() { document.getElementById('officerSettingsModal').classList.remove('open'); }

function saveOfficerPassword() {
  var cur   = document.getElementById('offCurPw').value;
  var np    = document.getElementById('offNewPw').value;
  var conf  = document.getElementById('offConfPw').value;
  var alert = document.getElementById('offPwMismatch');
  if (!cur || !np || !conf) { showFlash('Fill all password fields','error'); return; }
  if (np !== conf) { alert.style.display='block'; return; }
  alert.style.display = 'none';
  if (np.length < 6) { showFlash('Password must be at least 6 characters','error'); return; }

  var fd = new FormData();
  fd.append('current_password', cur);
  fd.append('new_password', np);
  fd.append('confirm_password', conf);

  fetch('actions/update_settings.php', { method:'POST', body:fd })
    .then(r => r.json()).then(res => {
      if (res && res.success) {
        document.getElementById('offCurPw').value = '';
        document.getElementById('offNewPw').value = '';
        document.getElementById('offConfPw').value = '';
        showFlash('Password updated!','success');
      } else {
        showFlash((res&&res.msg) || 'Failed to update password','error');
      }
    }).catch(() => { showFlash('Network error','error'); });
}

function togglePwVisOff(id, btn) {
  var input = document.getElementById(id);
  var icon  = btn.querySelector('i');
  if (input.type === 'password') {
    input.type = 'text'; icon.className = 'bi bi-eye-slash';
  } else {
    input.type = 'password'; icon.className = 'bi bi-eye';
  }
}

/* ── Flash message (officer uses simple alert-style) ── */
function showFlash(msg, type) {
  var el = document.createElement('div');
  el.className = 'alert alert-' + (type==='success'?'success':'error');
  el.innerHTML = '<i class="bi bi-' + (type==='success'?'check-circle':'exclamation-circle') + '"></i> ' + msg;
  el.style.cssText = 'position:fixed;top:70px;right:20px;z-index:9999;padding:12px 18px;border-radius:10px;font-size:13px;font-weight:500;box-shadow:0 4px 16px rgba(0,0,0,.15);display:flex;align-items:center;gap:8px;min-width:200px;';
  if (type==='success') { el.style.background='#ecfdf5';el.style.color='#065f46';el.style.border='1px solid #6ee7b7'; }
  else { el.style.background='#fef2f2';el.style.color='#991b1b';el.style.border='1px solid #fca5a5'; }
  document.body.appendChild(el);
  setTimeout(function(){ el.remove(); }, 3500);
}
</script>
