<!-- SHARED JS for all officer pages -->
<script>
// Modal open/close
function openModal(id) {
  document.getElementById(id).classList.add('open');
}
function closeModal(id) {
  document.getElementById(id).classList.remove('open');
}

// Close modal by clicking backdrop
document.querySelectorAll('.modal-overlay').forEach(function(m) {
  m.addEventListener('click', function(e) {
    if (e.target === this) this.classList.remove('open');
  });
});

// Avatar dropdown
function toggleDropdown(btn) {
  const menu = btn.parentElement.querySelector('.dropdown-menu');
  menu.classList.toggle('open');
}

// Close dropdown when clicking outside
document.addEventListener('click', function(e) {
  if (!e.target.closest('.dropdown')) {
    document.querySelectorAll('.dropdown-menu.open').forEach(function(m) {
      m.classList.remove('open');
    });
  }
});

// Toast notification
function showToast(msg, type) {
  type = type || 'success';
  const t = document.getElementById('toast');
  if (!t) return;
  t.textContent = msg;
  t.className = 'toast show ' + type;
  setTimeout(function() { t.className = 'toast'; }, 3000);
}

// Confirm delete
function confirmDelete(url, msg) {
  if (confirm(msg || 'Are you sure you want to delete this?')) {
    window.location.href = url;
  }
}
</script>

<!-- TOAST -->
<div id="toast" class="toast"></div>
