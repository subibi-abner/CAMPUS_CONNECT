<?php
session_start();
require_once '../../config.php';
require_once '../../db_functions.php';
require_login('organizer');

$organizer_id = $_SESSION['user_id'];
$action       = $_POST['action'] ?? '';
$event_id     = (int)($_POST['event_id'] ?? 0);
$staff_id     = (int)($_POST['staff_id']  ?? 0);

if (!$event_id || !$staff_id) {
  $_SESSION['flash'] = ['type' => 'error', 'msg' => 'Missing required fields.'];
  header('Location: ../manage_staff.php'); exit;
}

// Confirm this event belongs to this organizer
$stmt = $pdo->prepare("SELECT id FROM events WHERE id = ? AND organizer_id = ?");
$stmt->execute([$event_id, $organizer_id]);
if (!$stmt->fetch()) {
  $_SESSION['flash'] = ['type' => 'error', 'msg' => 'You do not have permission to manage this event.'];
  header('Location: ../manage_staff.php'); exit;
}

if ($action === 'assign') {
  // Confirm the target user is staff role
  $stmt = $pdo->prepare("SELECT id FROM users WHERE id = ? AND role = 'staff'");
  $stmt->execute([$staff_id]);
  if (!$stmt->fetch()) {
    $_SESSION['flash'] = ['type' => 'error', 'msg' => 'The selected user is not a staff account.'];
    header('Location: ../manage_staff.php'); exit;
  }

  // Insert or update assignment
  $stmt = $pdo->prepare("
    INSERT INTO event_staff (event_id, staff_id, assigned_by)
    VALUES (?, ?, ?)
    ON DUPLICATE KEY UPDATE assigned_by = VALUES(assigned_by), assigned_at = NOW()
  ");
  $stmt->execute([$event_id, $staff_id, $organizer_id]);

  $_SESSION['flash'] = ['type' => 'success', 'msg' => 'Staff assigned successfully.'];

} elseif ($action === 'remove') {
  $stmt = $pdo->prepare("DELETE FROM event_staff WHERE event_id = ? AND staff_id = ?");
  $stmt->execute([$event_id, $staff_id]);

  $_SESSION['flash'] = ['type' => 'success', 'msg' => 'Staff assignment removed.'];

} else {
  $_SESSION['flash'] = ['type' => 'error', 'msg' => 'Unknown action.'];
}

header('Location: ../manage_staff.php'); exit;
