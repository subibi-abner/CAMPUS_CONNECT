<?php
session_start();
require_once '../../config.php';
require_once '../../db_functions.php';
require_login('organizer');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
  header('Location: ../my_events.php');
  exit;
}

$user_id              = $_SESSION['user_id'];
$title                = trim($_POST['title']       ?? '');
$description          = trim($_POST['description'] ?? '');
$event_date           = trim($_POST['event_date']  ?? '');
$event_time           = trim($_POST['event_time']  ?? '00:00:00');
$full_datetime        = $event_date . ' ' . $event_time;
$location             = trim($_POST['location']    ?? '');
$max_attendees        = max(1, (int)($_POST['max_attendees'] ?? 100));
$registration_deadline = trim($_POST['registration_deadline'] ?? '') ?: null;
$category             = trim($_POST['category']    ?? 'general');
$department_id        = (int)($_POST['department_id'] ?? 0);

if (!$title || !$event_date) {
  $_SESSION['flash'] = ['type'=>'error','msg'=>'Title and date are required.'];
  header('Location: ../my_events.php');
  exit;
}

// Validate deadline is before event date
if ($registration_deadline && $registration_deadline >= $event_date) {
  $_SESSION['flash'] = ['type'=>'error','msg'=>'Registration deadline must be before the event date.'];
  header('Location: ../my_events.php');
  exit;
}

$stmt = $pdo->prepare("
  INSERT INTO events
    (organizer_id, title, description, event_date, location, max_attendees, capacity,
     registration_deadline, category, department_id, status, created_at)
  VALUES (?,?,?,?,?,?,?,?,?,?,?,NOW())
");
$stmt->execute([
  $user_id, $title, $description, $full_datetime, $location,
  $max_attendees, $max_attendees,  // keep both columns in sync
  $registration_deadline, $category,
  $department_id ?: null, 'draft'
]);

$_SESSION['flash'] = ['type'=>'success','msg'=>'Event saved as Draft. Submit it for admin approval when ready.'];
header('Location: ../my_events.php');
exit;
