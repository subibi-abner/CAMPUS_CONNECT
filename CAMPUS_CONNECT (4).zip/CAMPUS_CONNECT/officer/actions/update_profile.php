<?php
session_start();
require_once '../../config.php';
require_once '../../db_functions.php';
require_login('organizer');
header('Content-Type: application/json');

$user_id       = (int)$_SESSION['user_id'];
$org_name      = trim($_POST['org_name']      ?? '');
$bio           = trim($_POST['bio']           ?? $_POST['description'] ?? '');
$contact       = trim($_POST['contact']       ?? '');
$course        = trim($_POST['course']        ?? '');
$department_id = (int)($_POST['department_id'] ?? 0);

if (!$org_name) {
  echo json_encode(['success'=>false,'msg'=>'Name is required.']); exit;
}

$upd = $pdo->prepare("UPDATE users SET full_name=?, bio=?, contact=?, course=?, department_id=? WHERE id=?");
if ($upd->execute([$org_name, $bio ?: null, $contact ?: null, $course ?: null, $department_id ?: null, $user_id])) {
  $_SESSION['full_name'] = $org_name;
  echo json_encode(['success'=>true,'msg'=>'Profile updated.','full_name'=>$org_name]);
} else {
  echo json_encode(['success'=>false,'msg'=>'Update failed.']);
}
