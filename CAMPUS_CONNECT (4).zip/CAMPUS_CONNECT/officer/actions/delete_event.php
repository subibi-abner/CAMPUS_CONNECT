<?php
session_start();
require_once '../../config.php';
require_once '../../db_functions.php';
require_login('organizer');

$user_id  = $_SESSION['user_id'];
$event_id = (int)($_GET['id'] ?? 0);

if (!$event_id) {
  header('Location: ../my_events.php');
  exit;
}

// Verify ownership
$stmt = $pdo->prepare("SELECT id FROM events WHERE id = ? AND organizer_id = ?");
$stmt->execute([$event_id, $user_id]);
if (!$stmt->fetch()) {
  $_SESSION['flash'] = ['type'=>'error','msg'=>'Event not found or access denied.'];
  header('Location: ../my_events.php');
  exit;
}

// Delete registrations first
$pdo->prepare("DELETE FROM registrations WHERE event_id = ?")->execute([$event_id]);
// Delete event
$pdo->prepare("DELETE FROM events WHERE id = ? AND organizer_id = ?")->execute([$event_id, $user_id]);

$_SESSION['flash'] = ['type'=>'success','msg'=>'Event deleted.'];
header('Location: ../my_events.php');
exit;
