<?php
session_start();
require_once '../../config.php';
require_once '../../db_functions.php';
require_login('organizer');
header('Content-Type: application/json');

$user_id      = (int)$_SESSION['user_id'];
$current_pass = $_POST['current_password'] ?? '';
$new_pass     = $_POST['new_password']     ?? '';
$confirm_pass = $_POST['confirm_password'] ?? '';

if (!$current_pass || !$new_pass || !$confirm_pass) {
  echo json_encode(['success'=>false,'msg'=>'All fields are required.']); exit;
}

$stmt = $pdo->prepare("SELECT password FROM users WHERE id=?");
$stmt->execute([$user_id]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$user || !password_verify($current_pass, $user['password'])) {
  echo json_encode(['success'=>false,'msg'=>'Current password is incorrect.']); exit;
}
if ($new_pass !== $confirm_pass) {
  echo json_encode(['success'=>false,'msg'=>'New passwords do not match.']); exit;
}
if (strlen($new_pass) < 6) {
  echo json_encode(['success'=>false,'msg'=>'Password must be at least 6 characters.']); exit;
}

$hash = password_hash($new_pass, PASSWORD_DEFAULT);
$pdo->prepare("UPDATE users SET password=? WHERE id=?")->execute([$hash, $user_id]);
echo json_encode(['success'=>true,'msg'=>'Password changed successfully.']);
