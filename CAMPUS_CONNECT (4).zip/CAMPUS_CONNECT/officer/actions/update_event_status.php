<?php
session_start();
require_once '../../config.php';
require_once '../../db_functions.php';
require_login('organizer');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
  header('Location: ../my_events.php');
  exit;
}

$user_id  = $_SESSION['user_id'];
$event_id = (int)($_POST['event_id'] ?? 0);
$new_status = trim($_POST['status'] ?? '');

$allowed = ['draft', 'pending', 'completed'];

if (!$event_id || !in_array($new_status, $allowed)) {
  $_SESSION['flash'] = ['type' => 'error', 'msg' => 'Invalid request.'];
  header('Location: ../my_events.php');
  exit;
}

// Verify ownership
$stmt = $pdo->prepare("SELECT id, status FROM events WHERE id = ? AND organizer_id = ?");
$stmt->execute([$event_id, $user_id]);
$event = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$event) {
  $_SESSION['flash'] = ['type' => 'error', 'msg' => 'Access denied.'];
  header('Location: ../my_events.php');
  exit;
}

// Status transition rules for organizers:
// draft → pending (submit for approval)
// approved → completed (mark as done)
// approved → ongoing  (mark as started) - admin sets approved→ongoing too
// organizer can only: draft↔pending, approved→completed
$current = $event['status'];

$valid_transitions = [
  'draft'    => ['pending'],   // submit for review
  'pending'  => ['draft'],     // pull back to draft
  'approved' => ['completed'], // organizer marks done (admin can set ongoing)
  'ongoing'  => ['completed'], // mark done once running
];

if (!isset($valid_transitions[$current]) || !in_array($new_status, $valid_transitions[$current])) {
  $_SESSION['flash'] = ['type' => 'error', 'msg' => "Cannot change status from '$current' to '$new_status'."];
  header('Location: ../my_events.php');
  exit;
}

$pdo->prepare("UPDATE events SET status = ?, updated_at = NOW() WHERE id = ? AND organizer_id = ?")
    ->execute([$new_status, $event_id, $user_id]);

$labels = [
  'pending'   => 'submitted for admin review',
  'draft'     => 'moved back to draft',
  'completed' => 'marked as completed',
];
$label = $labels[$new_status] ?? $new_status;

$_SESSION['flash'] = ['type' => 'success', 'msg' => "Event $label successfully."];
header('Location: ../my_events.php');
exit;
