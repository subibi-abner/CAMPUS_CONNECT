<?php
session_start();
require_once '../../config.php';
require_once '../../db_functions.php';
require_login('organizer');

$user_id  = $_SESSION['user_id'];
$event_id = (int)($_GET['event_id'] ?? 0);
$filter   = trim($_GET['filter'] ?? 'all'); // all, approved, pending, rejected

// Verify event ownership if filtering by event
if ($event_id > 0) {
  $chk = $pdo->prepare("SELECT id, title FROM events WHERE id = ? AND organizer_id = ?");
  $chk->execute([$event_id, $user_id]);
  $eventRow = $chk->fetch(PDO::FETCH_ASSOC);
  if (!$eventRow) {
    http_response_code(403);
    exit('Access denied.');
  }
  $filename = 'participants_' . preg_replace('/[^a-z0-9]+/', '_', strtolower($eventRow['title'])) . '_' . date('Ymd') . '.csv';
} else {
  $filename = 'all_participants_' . date('Ymd') . '.csv';
}

// Build query
$where_parts = ["e.organizer_id = ?"];
$params      = [$user_id];

if ($event_id > 0) {
  $where_parts[] = "r.event_id = ?";
  $params[]       = $event_id;
}

$approval_map = ['approved' => 'approved', 'pending' => 'pending', 'rejected' => 'rejected'];
if ($filter !== 'all' && isset($approval_map[$filter])) {
  $where_parts[] = "r.approval_status = ?";
  $params[]       = $approval_map[$filter];
}

$where_sql = implode(' AND ', $where_parts);

$stmt = $pdo->prepare("
  SELECT
    u.full_name        AS 'Full Name',
    u.email            AS 'Email',
    u.username         AS 'Username',
    d.name             AS 'Department',
    d.code             AS 'Dept Code',
    u.course           AS 'Course',
    u.year_level       AS 'Year Level',
    e.title            AS 'Event',
    DATE_FORMAT(e.event_date, '%M %d, %Y %h:%i %p') AS 'Event Date',
    r.approval_status  AS 'Status',
    r.approval_note    AS 'Approval Note',
    DATE_FORMAT(r.registered_at, '%M %d, %Y %h:%i %p') AS 'Registered At'
  FROM registrations r
  JOIN users  u ON r.user_id  = u.id
  JOIN events e ON r.event_id = e.id
  LEFT JOIN departments d ON u.department_id = d.id
  WHERE $where_sql
  ORDER BY e.event_date ASC, u.full_name ASC
");
$stmt->execute($params);
$rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Output CSV
header('Content-Type: text/csv; charset=utf-8');
header('Content-Disposition: attachment; filename="' . $filename . '"');
header('Cache-Control: no-cache, no-store, must-revalidate');

$out = fopen('php://output', 'w');

if (!empty($rows)) {
  // Header row
  fputcsv($out, array_keys($rows[0]));
  foreach ($rows as $row) {
    // Replace null approval_status with default label
    if (empty($row['Status'])) $row['Status'] = 'approved';
    fputcsv($out, array_values($row));
  }
} else {
  fputcsv($out, ['No participants found matching the selected filters.']);
}

fclose($out);
exit;
