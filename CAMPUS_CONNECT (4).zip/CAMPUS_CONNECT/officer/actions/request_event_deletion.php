<?php
session_start();
require_once '../../config.php';
require_once '../../db_functions.php';
require_login('organizer');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
  header('Location: ../my_events.php');
  exit;
}

$user_id  = $_SESSION['user_id'];
$event_id = (int)($_POST['event_id'] ?? 0);
$reason   = trim($_POST['reason'] ?? '');

if (!$event_id || !$reason) {
  $_SESSION['flash'] = ['type'=>'error','msg'=>'Invalid request'];
  header('Location: ../my_events.php');
  exit;
}

// Check ownership + no pending request
$stmt = $pdo->prepare("
  SELECT e.title FROM events e 
  LEFT JOIN deletion_requests r ON e.id = r.event_id AND r.status = 'pending'
  WHERE e.id = ? AND e.organizer_id = ? AND r.id IS NULL AND e.status != 'deleted'
");
$stmt->execute([$event_id, $user_id]);
$event = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$event) {
  $_SESSION['flash'] = ['type'=>'error','msg'=>'Cannot request deletion: Event not yours, already requested, or deleted'];
  header('Location: ../my_events.php');
  exit;
}

// Create request
$stmt = $pdo->prepare("INSERT INTO deletion_requests (event_id, organizer_id, reason) VALUES (?, ?, ?)");
if ($stmt->execute([$event_id, $user_id, $reason])) {
  $_SESSION['flash'] = ['type'=>'success','msg'=>'Deletion request submitted to admin. Students will be notified when approved.'];
} else {
  $_SESSION['flash'] = ['type'=>'error','msg'=>'Request failed - try again'];
}

header('Location: ../my_events.php');
exit;
?>

