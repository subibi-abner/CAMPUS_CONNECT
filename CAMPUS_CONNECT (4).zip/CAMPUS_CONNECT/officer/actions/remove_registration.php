<?php
session_start();
require_once '../../config.php';
require_once '../../db_functions.php';
require_login('organizer');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
  header('Location: ../registrations.php');
  exit;
}

$user_id      = $_SESSION['user_id'];
$reg_id       = (int)($_POST['registration_id'] ?? 0);
$message      = trim($_POST['message'] ?? '');

if (!$reg_id) {
  $_SESSION['flash'] = ['type' => 'error', 'msg' => 'Invalid registration'];
  header('Location: ../registrations.php');
  exit;
}

// Verify ownership
$stmt = $pdo->prepare("SELECT r.*, e.organizer_id FROM registrations r JOIN events e ON r.event_id = e.id WHERE r.id = ?");
$stmt->execute([$reg_id]);
$reg = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$reg || $reg['organizer_id'] != $user_id) {
  $_SESSION['flash'] = ['type' => 'error', 'msg' => 'Not authorized'];
  header('Location: ../registrations.php');
  exit;
}

// Remove registration
$stmt = $pdo->prepare("DELETE FROM registrations WHERE id = ?");
$stmt->execute([$reg_id]);

// Optional: Send email notification
if (!empty($message)) {
  // Use PHPMailer or mail() here
  $to = $reg['user_email'];
  $subject = 'Registration Removed - ' . $reg['event_title'];
  $body = "Hi " . $reg['user_name'] . ",\n\n" .
          "Your registration for '" . $reg['event_title'] . "' has been removed.\n\n" .
          "Reason: " . $message . "\n\n" .
          "Thank you.";
  // mail($to, $subject, $body);
}

$_SESSION['flash'] = ['type' => 'success', 'msg' => 'Registration removed successfully'];
header('Location: ../registrations.php');
exit;
?>

