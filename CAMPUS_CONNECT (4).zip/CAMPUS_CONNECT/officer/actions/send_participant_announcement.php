<?php
session_start();
require_once '../../config.php';
require_once '../../db_functions.php';
require_login('organizer');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
  header('Location: ../registrations.php');
  exit;
}

$user_id    = $_SESSION['user_id'];
$event_id   = (int)($_POST['event_id'] ?? 0);
$subject    = trim($_POST['subject'] ?? '');
$message    = trim($_POST['message'] ?? '');
$target     = trim($_POST['target'] ?? 'all'); // all, approved, pending

if (!$event_id || !$subject || !$message) {
  $_SESSION['flash'] = ['type' => 'error', 'msg' => 'Event, subject, and message are required.'];
  header('Location: ../registrations.php');
  exit;
}

// Verify organizer owns this event
$chk = $pdo->prepare("SELECT id, title FROM events WHERE id = ? AND organizer_id = ?");
$chk->execute([$event_id, $user_id]);
$event = $chk->fetch(PDO::FETCH_ASSOC);

if (!$event) {
  $_SESSION['flash'] = ['type' => 'error', 'msg' => 'Access denied.'];
  header('Location: ../registrations.php');
  exit;
}

// Get target participants
$where_approval = '';
if ($target === 'approved') {
  $where_approval = "AND (r.approval_status = 'approved' OR r.approval_status IS NULL)";
} elseif ($target === 'pending') {
  $where_approval = "AND r.approval_status = 'pending'";
}

$stmt = $pdo->prepare("
  SELECT DISTINCT r.user_id, u.full_name, u.email
  FROM registrations r
  JOIN users u ON r.user_id = u.id
  WHERE r.event_id = ? $where_approval
");
$stmt->execute([$event_id]);
$participants = $stmt->fetchAll(PDO::FETCH_ASSOC);

if (empty($participants)) {
  $_SESSION['flash'] = ['type' => 'error', 'msg' => 'No participants found for the selected filter.'];
  header('Location: ../registrations.php');
  exit;
}

// Insert in-app notifications for each participant
$notif_stmt = $pdo->prepare(
  "INSERT INTO notifications (user_id, message, type) VALUES (?, ?, 'announcement')"
);

$full_message = "📢 [{$event['title']}] {$subject}: {$message}";
$count = 0;
foreach ($participants as $p) {
  $notif_stmt->execute([$p['user_id'], $full_message]);
  $count++;
}

// Log the announcement
$pdo->prepare("
  INSERT INTO event_announcements (event_id, sender_id, subject, message, recipient_count)
  VALUES (?, ?, ?, ?, ?)
")->execute([$event_id, $user_id, $subject, $message, $count]);

$_SESSION['flash'] = ['type' => 'success', 'msg' => "Announcement sent to $count participant(s) successfully."];
header('Location: ../registrations.php');
exit;
