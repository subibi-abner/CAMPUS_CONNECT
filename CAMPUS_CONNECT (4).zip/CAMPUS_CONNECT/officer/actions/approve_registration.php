<?php
session_start();
require_once '../../config.php';
require_once '../../db_functions.php';
require_login('organizer');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
  header('Location: ../registrations.php');
  exit;
}

$user_id    = $_SESSION['user_id'];
$reg_id     = (int)($_POST['registration_id'] ?? 0);
$action     = trim($_POST['action'] ?? '');  // 'approve' or 'reject'
$note       = trim($_POST['note'] ?? '');

if (!$reg_id || !in_array($action, ['approve', 'reject'])) {
  $_SESSION['flash'] = ['type' => 'error', 'msg' => 'Invalid request.'];
  header('Location: ../registrations.php');
  exit;
}

// Verify organizer owns the event this registration belongs to
$stmt = $pdo->prepare("
  SELECT r.*, e.organizer_id, e.title AS event_title, u.full_name AS student_name, u.email AS student_email
  FROM registrations r
  JOIN events e ON r.event_id = e.id
  JOIN users u  ON r.user_id  = u.id
  WHERE r.id = ?
");
$stmt->execute([$reg_id]);
$reg = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$reg || $reg['organizer_id'] != $user_id) {
  $_SESSION['flash'] = ['type' => 'error', 'msg' => 'Access denied.'];
  header('Location: ../registrations.php');
  exit;
}

$approval_status = ($action === 'approve') ? 'approved' : 'rejected';

$upd = $pdo->prepare("
  UPDATE registrations
  SET approval_status = ?, approval_note = ?, approved_by = ?, approved_at = NOW()
  WHERE id = ?
");
$upd->execute([$approval_status, $note ?: null, $user_id, $reg_id]);

// Insert in-app notification to the student
$msg = $action === 'approve'
  ? "Your registration for \"{$reg['event_title']}\" has been approved! 🎉"
  : "Your registration for \"{$reg['event_title']}\" was not approved." . ($note ? " Reason: $note" : '');

$pdo->prepare("INSERT INTO notifications (user_id, message, type) VALUES (?, ?, 'event')")
    ->execute([$reg['user_id'], $msg]);

$label = $action === 'approve' ? 'approved' : 'rejected';
$_SESSION['flash'] = ['type' => 'success', 'msg' => "Registration {$label} for {$reg['student_name']}."];
header('Location: ../registrations.php');
exit;
