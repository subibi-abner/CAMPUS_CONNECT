<?php
session_start();
require_once '../../config.php';
require_once '../../db_functions.php';
require_login('organizer');

$user_id  = $_SESSION['user_id'];
$event_id = (int)($_POST['event_id'] ?? 0);

// Verify ownership
$stmt = $pdo->prepare("SELECT id FROM events WHERE id = ? AND organizer_id = ?");
$stmt->execute([$event_id, $user_id]);
if (!$stmt->fetch()) {
  $_SESSION['flash'] = ['type'=>'error','msg'=>'Access denied.'];
  header('Location: ../my_events.php');
  exit;
}

$title                = trim($_POST['title']       ?? '');
$description          = trim($_POST['description'] ?? '');
$event_date           = trim($_POST['event_date']  ?? '');
$event_time           = trim($_POST['event_time']  ?? '00:00:00');
$full_datetime        = $event_date . ' ' . $event_time;
$location             = trim($_POST['location']    ?? '');
$max_attendees        = max(1, (int)($_POST['max_attendees'] ?? 100));
$registration_deadline = trim($_POST['registration_deadline'] ?? '') ?: null;
$category             = trim($_POST['category']    ?? 'general');

// Validate deadline
if ($registration_deadline && $event_date && $registration_deadline >= $event_date) {
  $_SESSION['flash'] = ['type'=>'error','msg'=>'Registration deadline must be before the event date.'];
  header('Location: ../my_events.php');
  exit;
}

$upd = $pdo->prepare("
  UPDATE events
  SET title=?, description=?, event_date=?, location=?,
      max_attendees=?, capacity=?, registration_deadline=?, category=?
  WHERE id=? AND organizer_id=?
");
$upd->execute([
  $title, $description, $full_datetime, $location,
  $max_attendees, $max_attendees,  // keep both columns in sync
  $registration_deadline, $category,
  $event_id, $user_id
]);

$_SESSION['flash'] = ['type'=>'success','msg'=>'Event updated successfully.'];
header('Location: ../my_events.php');
exit;
