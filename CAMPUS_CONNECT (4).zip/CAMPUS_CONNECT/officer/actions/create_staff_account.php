<?php
session_start();
require_once '../../config.php';
require_once '../../db_functions.php';
require_login('organizer');

$full_name = trim($_POST['full_name'] ?? '');
$email     = trim($_POST['email']     ?? '');
$username  = trim($_POST['username']  ?? '');

if (!$full_name || !$email || !$username) {
  $_SESSION['flash'] = ['type' => 'error', 'msg' => 'All fields are required.'];
  header('Location: ../manage_staff.php'); exit;
}

// Generate a random password
$raw_password  = substr(str_shuffle('abcdefghjkmnpqrstuvwxyzABCDEFGHJKMNPQRSTUVWXYZ23456789@#!'), 0, 10);
$hashed        = password_hash($raw_password, PASSWORD_DEFAULT);

try {
  $stmt = $pdo->prepare("
    INSERT INTO users (username, email, password, role, full_name)
    VALUES (?, ?, ?, 'staff', ?)
  ");
  $stmt->execute([$username, $email, $hashed, $full_name]);
} catch (PDOException $e) {
  $_SESSION['flash'] = ['type' => 'error', 'msg' => 'Username or email already exists. Please choose different ones.'];
  header('Location: ../manage_staff.php'); exit;
}

// Email credentials to the new staff user
$subject = "Your CampusConnect Staff Account";
$message = "Dear {$full_name},\r\n\r\n" .
  "A staff account has been created for you on CampusConnect WMSU.\r\n\r\n" .
  "  Login URL : http://yourdomain.com/CAMPUS_CONNECT/login.php\r\n" .
  "  Email     : {$email}\r\n" .
  "  Password  : {$raw_password}\r\n\r\n" .
  "Please log in and change your password after your first login.\r\n\r\n" .
  "— CampusConnect\r\n   Western Mindanao State University";

$headers = "From: no-reply@wmsu.edu.ph\r\nContent-Type: text/plain; charset=utf-8";
@mail($email, $subject, $message, $headers);

$_SESSION['flash'] = ['type' => 'success', 'msg' => "Staff account created for {$full_name}. Login credentials sent to {$email}."];
header('Location: ../manage_staff.php'); exit;
