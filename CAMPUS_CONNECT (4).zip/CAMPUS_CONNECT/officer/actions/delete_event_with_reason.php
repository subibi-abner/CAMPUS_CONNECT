<?php
session_start();
require_once '../../config.php';
require_once '../../db_functions.php';
require_login('organizer');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
  header('Location: ../my_events.php');
  exit;
}

$user_id   = $_SESSION['user_id'];
$event_id  = (int)($_POST['event_id'] ?? 0);
$reason    = trim($_POST['reason'] ?? '');

if (!$event_id) {
  $_SESSION['flash'] = ['type'=>'error','msg'=>'Invalid event'];
  header('Location: ../my_events.php');
  exit;
}

// Check ownership & registrations
$stmt = $pdo->prepare("SELECT title, COUNT(r.id) as reg_count FROM events e LEFT JOIN registrations r ON e.id = r.event_id WHERE e.id = ? AND e.organizer_id = ? GROUP BY e.id");
$stmt->execute([$event_id, $user_id]);
$event = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$event) {
  $_SESSION['flash'] = ['type'=>'error','msg'=>'Event not found or access denied'];
  header('Location: ../my_events.php');
  exit;
}

if ($event['reg_count'] > 0 && !$reason) {
  $_SESSION['flash'] = ['type'=>'error','msg'=>'Reason required when students are registered'];
  header('Location: ../my_events.php');
  exit;
}

// Save reason & soft-delete (add deleted_at)
$stmt = $pdo->prepare("UPDATE events SET status='deleted', delete_reason=?, updated_at=NOW() WHERE id=? AND organizer_id=?");
$stmt->execute([$reason, $event_id, $user_id]);

if ($event['reg_count'] > 0) {
  // Get students for email
  $students = $pdo->prepare("SELECT u.email, u.full_name FROM registrations r JOIN users u ON r.user_id=u.id WHERE r.event_id=?");
  $students->execute([$event_id]);
  foreach ($students->fetchAll() as $s) {
    $msg = "Hi " . $s['full_name'] . ",\n\n";
    $msg .= "The event you registered for ('" . $event['title'] . "') has been cancelled.\n\n";
    $msg .= "Reason: " . $reason . "\n\n";
    $msg .= "Thank you for your understanding.\nCampusConnect";
    // mail($s['email'], 'Event Cancelled: ' . $event['title'], $msg);
  }
}

// Delete registrations
$pdo->prepare("DELETE FROM registrations WHERE event_id=?")->execute([$event_id]);

$_SESSION['flash'] = ['type'=>'success','msg'=>'Event deleted. Registered students notified.'];
header('Location: ../my_events.php');
exit;
?>

